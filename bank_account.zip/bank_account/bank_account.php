<?php
/*
Plugin Name: Bank Account
*/

//-----------------------------------------------------------------------------------------
// Activación del plugin
function my_plugin_activation() {
    // Incluye archivo de instalación/activación
    require_once(plugin_dir_path(__FILE__) . '/install_db/install_db.php');
}

register_activation_hook(__FILE__, 'my_plugin_activation');

//------------------------------------------------------------------------------------------
// Desinstalación del plugin
function my_plugin_uninstallation() {
    // Incluye archivo de desinstalación
    require_once(plugin_dir_path(__FILE__) . '/uninstall_db/uninstall_db.php');
}

register_uninstall_hook(__FILE__, 'my_plugin_uninstallation');

//--------------------------------------------------------------------------------------------
// Menú del plugin en el área de administración
function myplugin_register_menu() {
    add_menu_page(
        'Bank Account',
        'Bank Account',
        'manage_options',
        'bank_account',
        'bank_account_admin_page',
        'dashicons-admin-generic',
        20
    );

    // Submenús valores general
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'Valores General',          // Título de la página
        'Valores General',          // Título del submenú
        'manage_options',
        'values',           // Slug de la página
        'values'            // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús valores pago único
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'Valores Único',          // Título de la página
        'Valores Único',          // Título del submenú
        'manage_options',
        'values_unique',           // Slug de la página
        'values_unique'            // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús valores pago mensual
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'Valores Mensual',          // Título de la página
        'Valores Mensual',          // Título del submenú
        'manage_options',
        'values_monthly',           // Slug de la página
        'values_monthly'            // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús cuentas de banco guardadas
    add_submenu_page(
        'bank_account',         // Slug del menú padre
        'Cuentas Guardadas',    // Título de la página
        'Cuentas Guardadas',    // Título del submenú
        'manage_options',
        'saved_accounts',       // Slug de la página
        'saved_accounts'        // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús Configuración Payu
    add_submenu_page(
        'bank_account',         // Slug del menú padre
        'Configuración Payu',   // Título de la página
        'Configuración Payu',   // Título del submenú
        'manage_options',
        'payu_settings',        // Slug de la página
        'payu_settings'         // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús Configuración Payu
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'URLs',             // Título de la página
        'URLs',        // Título del submenú
        'manage_options',
        'urls',             // Slug de la página
        'urls'              // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús Configuración Payu
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'Tokens',             // Título de la página
        'Tokens',        // Título del submenú
        'manage_options',
        'tokens',             // Slug de la página
        'tokens'              // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús Log system
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'LOGS',             // Título de la página
        'LOGS',        // Título del submenú
        'manage_options',
        'logs',             // Slug de la página
        'logs'              // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús Configuración Store
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'URLs Tienda',             // Título de la página
        'URLs Tienda',        // Título del submenú
        'manage_options',
        'urls_store',             // Slug de la página
        'urls_store'              // Función que muestra el formulario de Tipo Aplicación
    );

    // Submenús Configuración Store
    add_submenu_page(
        'bank_account',     // Slug del menú padre
        'Ordenes',             // Título de la página
        'Ordenes',        // Título del submenú
        'manage_options',
        'saved_orders',             // Slug de la página
        'saved_orders'              // Función que muestra el formulario de Tipo Aplicación
    );
    
}
add_action('admin_menu', 'myplugin_register_menu');

//--------------------------------------------------------------------------------------------
// Página de configuración del plugin
function bank_account_admin_page() {
    ?>
    <h1>Bank Account</h1>
    <br>
    <section>
        <div>
            <h2>Shortcode general 1:</h2>
        </div>
        <div>
            <h3>[bank_account]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode general 2:</h2>
        </div>
        <div>
            <h3>[bank_account_option_1]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode general 3:</h2>
        </div>
        <div>
            <h3>[bank_account_option_2]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode general 4:</h2>
        </div>
        <div>
            <h3>[bank_account_option_3]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode general 5:</h2>
        </div>
        <div>
            <h3>[bank_account_option_4]</h3>
        </div>
    </section>
    <br>
    <h1>-------------------------------</h1>
    <section>
        <div>
            <h2>Shortcode pago único 1:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_1]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 2:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_2]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 3:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_3]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 4:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_4]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 5:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_5]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 6:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_6]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 7:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_7]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 8:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_8]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 9:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_9]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago único 10:</h2>
        </div>
        <div>
            <h3>[bank_account_unique_option_10]</h3>
        </div>
    </section>
    <br>
    <h1>-------------------------------</h1>
    <section>
        <div>
            <h2>Shortcode pago mensual 1:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_1]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 2:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_2]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 3:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_3]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 4:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_4]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 5:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_5]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 6:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_6]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 7:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_7]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 8:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_8]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 9:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_9]</h3>
        </div>
    </section>
    <br>
    <section>
        <div>
            <h2>Shortcode pago mensual 10:</h2>
        </div>
        <div>
            <h3>[bank_account_monthly_option_10]</h3>
        </div>
    </section>
    <br>
    <h1>-------------------------------</h1>
    <section>
        <div>
            <h2>Shortcode Tienda 1:</h2>
        </div>
        <div>
            <h3>[bank_account_payment_option_1]</h3>
        </div>
    </section>
    <br>
    <h1>-------------------------------</h1>
    <section>
        <div>
            <label>Valores</label>
        </div>
        <div>
            <a href="<?php echo admin_url('admin.php?page=values'); ?>" class="button button-primary">Administrar</a>
        </div>
    </section>
    <br>
    <section>
        <div>
            <label>Cuentas guardadas</label>
        </div>
        <div>
            <a href="<?php echo admin_url('admin.php?page=saved_accounts'); ?>" class="button button-primary">Administrar</a>
        </div>
    </section>
    <br>
    <section>
        <div>
            <label>Configuración Payu</label>
        </div>
        <div>
            <a href="<?php echo admin_url('admin.php?page=payu_settings'); ?>" class="button button-primary">Administrar</a>
        </div>
    </section>
    <br>
    <section>
        <div>
            <label>Configuración URLs</label>
        </div>
        <div>
            <a href="<?php echo admin_url('admin.php?page=urls'); ?>" class="button button-primary">Administrar</a>
        </div>
    </section>
    <br>
    <section>
        <div>
            <label>Tokens Guardados</label>
        </div>
        <div>
            <a href="<?php echo admin_url('admin.php?page=tokens'); ?>" class="button button-primary">Administrar</a>
        </div>
    </section>
    <br>
    <?php
}
//---------------------------------------------------------------------------------
// Página de configuración de valores del plugin
function values() {
    global $wpdb;

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'values';

    if (isset($_POST['values'])) {
        $value1 = intval(sanitize_text_field($_POST['value1']));
        $value2 = intval(sanitize_text_field($_POST['value2']));
        $value3 = intval(sanitize_text_field($_POST['value3']));
        $value4 = intval(sanitize_text_field($_POST['value4']));
        $value5 = intval(sanitize_text_field($_POST['value5']));
        $value6 = intval(sanitize_text_field($_POST['value6']));
    
        $registry_1 = 1;
        $registry_2 = 2;
        $registry_3 = 3;
        $registry_4 = 4;
        $registry_5 = 5;
        $registry_6 = 6;
    
        //$datos = array('nombre_tipo' => $nombre_app); // Cambio aquí
        $format = array('%s');
        //Value 1--------------------------------------------------------
        $condition = array(
            'id' => $registry_1,
        );
    
        $data = array(
            'value' => $value1,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //Value 2--------------------------------------------------------
        $condition = array(
            'id' => $registry_2,
        );
    
        $data = array(
            'value' => $value2,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //Value 3--------------------------------------------------------
        $condition = array(
            'id' => $registry_3,
        );
    
        $data = array(
            'value' => $value3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //Value 4--------------------------------------------------------
        $condition = array(
            'id' => $registry_4,
        );
    
        $data = array(
            'value' => $value4,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //Value 5--------------------------------------------------------
        $condition = array(
            'id' => $registry_5,
        );
    
        $data = array(
            'value' => $value5,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //Value 6--------------------------------------------------------
        $condition = array(
            'id' => $registry_6,
        );
    
        $data = array(
            'value' => $value6,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        echo '<script>alert("Datos Guardados");</script>';
    }

    // Consulta SQL para obtener los valores de las filas 1, 2 y 3
    $sql = "SELECT id, value FROM $table_name WHERE id IN (1, 2, 3, 4, 5, 6)";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Crear un array asociativo para almacenar los resultados
    $values = array();

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $values[$result->id] = $result->value;
    }
    // Contenido de la página de configuración
    ?>
    <h1>Bank Account</h1>
    <form method="post" action="">
        <h3>Valores de las donaciones</h3>
        <section>
            <div>
                <h3>Valores pago mensual</h3>
            </div>
            <div>
                <label for="value1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value1" id="value1" required value="<?php echo esc_attr($values[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value2" id="value2" required value="<?php echo esc_attr($values[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value3" id="value3" required value="<?php echo esc_attr($values[3]); ?>">
            </div>
            <br>
            <div>
                <h3>Valores pago único</h3>
            </div>
            <div>
                <label for="value4">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value4" id="value4" required value="<?php echo esc_attr($values[4]); ?>">
            </div>
            <br>
            <div>
                <label for="value5">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value5" id="value5" required value="<?php echo esc_attr($values[5]); ?>">
            </div>
            <br>
            <div>
                <label for="value6">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value6" id="value6" required value="<?php echo esc_attr($values[6]); ?>">
            </div>
            <br>
            <div>
                <button type="submit" name="values" class="button button-primary">Guardar</button>
            </div>
        </section>
    </form>
    <?php
}
//---------------------------------------------------------------------------------
// Página de configuración de valores del plugin
function values_unique() {
    global $wpdb;

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'values_unique';

    if (isset($_POST['values'])) {
        //--------------------------------------------------------------------
        $value_1_1 = intval(sanitize_text_field($_POST['value_1_1']));
        $value_1_2 = intval(sanitize_text_field($_POST['value_1_2']));
        $value_1_3 = intval(sanitize_text_field($_POST['value_1_3']));
        //--------------------------------------------------------------------
        $value_2_1 = intval(sanitize_text_field($_POST['value_2_1']));
        $value_2_2 = intval(sanitize_text_field($_POST['value_2_2']));
        $value_2_3 = intval(sanitize_text_field($_POST['value_2_3']));
        //--------------------------------------------------------------------
        $value_3_1 = intval(sanitize_text_field($_POST['value_3_1']));
        $value_3_2 = intval(sanitize_text_field($_POST['value_3_2']));
        $value_3_3 = intval(sanitize_text_field($_POST['value_3_3']));
        //--------------------------------------------------------------------
        $value_4_1 = intval(sanitize_text_field($_POST['value_4_1']));
        $value_4_2 = intval(sanitize_text_field($_POST['value_4_2']));
        $value_4_3 = intval(sanitize_text_field($_POST['value_4_3']));
        //--------------------------------------------------------------------
        $value_5_1 = intval(sanitize_text_field($_POST['value_5_1']));
        $value_5_2 = intval(sanitize_text_field($_POST['value_5_2']));
        $value_5_3 = intval(sanitize_text_field($_POST['value_5_3']));
        //--------------------------------------------------------------------
        $value_6_1 = intval(sanitize_text_field($_POST['value_6_1']));
        $value_6_2 = intval(sanitize_text_field($_POST['value_6_2']));
        $value_6_3 = intval(sanitize_text_field($_POST['value_6_3']));
        //--------------------------------------------------------------------
        $value_7_1 = intval(sanitize_text_field($_POST['value_7_1']));
        $value_7_2 = intval(sanitize_text_field($_POST['value_7_2']));
        $value_7_3 = intval(sanitize_text_field($_POST['value_7_3']));
        //--------------------------------------------------------------------
        $value_8_1 = intval(sanitize_text_field($_POST['value_8_1']));
        $value_8_2 = intval(sanitize_text_field($_POST['value_8_2']));
        $value_8_3 = intval(sanitize_text_field($_POST['value_8_3']));
        //--------------------------------------------------------------------
        $value_9_1 = intval(sanitize_text_field($_POST['value_9_1']));
        $value_9_2 = intval(sanitize_text_field($_POST['value_9_2']));
        $value_9_3 = intval(sanitize_text_field($_POST['value_9_3']));
        //--------------------------------------------------------------------
        $value_10_1 = intval(sanitize_text_field($_POST['value_10_1']));
        $value_10_2 = intval(sanitize_text_field($_POST['value_10_2']));
        $value_10_3 = intval(sanitize_text_field($_POST['value_10_3']));

        $value1 = intval(sanitize_text_field($_POST['value1']));
        $value2 = intval(sanitize_text_field($_POST['value2']));
        $value3 = intval(sanitize_text_field($_POST['value3']));
        $value4 = intval(sanitize_text_field($_POST['value4']));
        $value5 = intval(sanitize_text_field($_POST['value5']));
        $value6 = intval(sanitize_text_field($_POST['value6']));
    
        $registry_1 = 1;
        $registry_2 = 2;
        $registry_3 = 3;
        $registry_4 = 4;
        $registry_5 = 5;
        $registry_6 = 6;
        $registry_7 = 7;
        $registry_8 = 8;
        $registry_9 = 9;
        $registry_10 = 10;
    
        $format = array('%s');
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_1,
        );
    
        $data = array(
            'value_1' => $value_1_1,
            'value_2' => $value_1_2,
            'value_3' => $value_1_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_2,
        );
    
        $data = array(
            'value_1' => $value_2_1,
            'value_2' => $value_2_2,
            'value_3' => $value_2_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_3,
        );
    
        $data = array(
            'value_1' => $value_3_1,
            'value_2' => $value_3_2,
            'value_3' => $value_3_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_4,
        );
    
        $data = array(
            'value_1' => $value_4_1,
            'value_2' => $value_4_2,
            'value_3' => $value_4_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_5,
        );
    
        $data = array(
            'value_1' => $value_5_1,
            'value_2' => $value_5_2,
            'value_3' => $value_5_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_6,
        );
    
        $data = array(
            'value_1' => $value_6_1,
            'value_2' => $value_6_2,
            'value_3' => $value_6_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_7,
        );
    
        $data = array(
            'value_1' => $value_7_1,
            'value_2' => $value_7_2,
            'value_3' => $value_7_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_8,
        );
    
        $data = array(
            'value_1' => $value_8_1,
            'value_2' => $value_8_2,
            'value_3' => $value_8_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_9,
        );
    
        $data = array(
            'value_1' => $value_9_1,
            'value_2' => $value_9_2,
            'value_3' => $value_9_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_10,
        );
    
        $data = array(
            'value_1' => $value_10_1,
            'value_2' => $value_10_2,
            'value_3' => $value_10_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        echo '<script>alert("Datos Guardados");</script>';
    }

    // Consulta SQL para obtener los valores de las filas 1, 2 y 3
    $sql = "SELECT id, value_1, value_2, value_3 FROM $table_name WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Crear un array asociativo para almacenar los resultados
    $values_1 = array();
    $values_2 = array();
    $values_3 = array();
    $values_4 = array();
    $values_5 = array();
    $values_6 = array();
    $values_7 = array();
    $values_8 = array();
    $values_9 = array();
    $values_10 = array();

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        if ($result->id == 1){
            $values_1[1] = $result->value_1;
            $values_1[2] = $result->value_2;
            $values_1[3] = $result->value_3;
        }
        elseif ($result->id == 2){
            $values_2[1] = $result->value_1;
            $values_2[2] = $result->value_2;
            $values_2[3] = $result->value_3;
        }
        elseif ($result->id == 3){
            $values_3[1] = $result->value_1;
            $values_3[2] = $result->value_2;
            $values_3[3] = $result->value_3;
        }
        elseif ($result->id == 4){
            $values_4[1] = $result->value_1;
            $values_4[2] = $result->value_2;
            $values_4[3] = $result->value_3;
        }
        elseif ($result->id == 5){
            $values_5[1] = $result->value_1;
            $values_5[2] = $result->value_2;
            $values_5[3] = $result->value_3;
        }
        elseif ($result->id == 6){
            $values_6[1] = $result->value_1;
            $values_6[2] = $result->value_2;
            $values_6[3] = $result->value_3;
        }
        elseif ($result->id == 7){
            $values_7[1] = $result->value_1;
            $values_7[2] = $result->value_2;
            $values_7[3] = $result->value_3;
        }
        elseif ($result->id == 8){
            $values_8[1] = $result->value_1;
            $values_8[2] = $result->value_2;
            $values_8[3] = $result->value_3;
        }
        elseif ($result->id == 9){
            $values_9[1] = $result->value_1;
            $values_9[2] = $result->value_2;
            $values_9[3] = $result->value_3;
        }
        elseif ($result->id == 10){
            $values_10[1] = $result->value_1;
            $values_10[2] = $result->value_2;
            $values_10[3] = $result->value_3;
        }
    }
    // Contenido de la página de configuración
    ?>
    <h1>Bank Account</h1>
    <form method="post" action="">
        <h3>Valores de las donaciones únicas</h3>
        <section>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 1</h3>
            </div>
            <div>
                <label for="value_1_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_1_1" id="value_1_1" required value="<?php echo esc_attr($values_1[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_1_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_1_2" id="value_1_2" required value="<?php echo esc_attr($values_1[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_1_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_1_3" id="value_1_3" required value="<?php echo esc_attr($values_1[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 2</h3>
            </div>
            <div>
                <label for="value_2_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_2_1" id="value_2_1" required value="<?php echo esc_attr($values_2[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_2_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_2_2" id="value_2_2" required value="<?php echo esc_attr($values_2[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_2_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_2_3" id="value_2_3" required value="<?php echo esc_attr($values_2[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 3</h3>
            </div>
            <div>
                <label for="value_3_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_3_1" id="value_3_1" required value="<?php echo esc_attr($values_3[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_3_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_3_2" id="value_3_2" required value="<?php echo esc_attr($values_3[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_3_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_3_3" id="value_3_3" required value="<?php echo esc_attr($values_3[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 4</h3>
            </div>
            <div>
                <label for="value_4_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_4_1" id="value_4_1" required value="<?php echo esc_attr($values_4[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_4_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_4_2" id="value_4_2" required value="<?php echo esc_attr($values_4[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_4_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_4_3" id="value_4_3" required value="<?php echo esc_attr($values_4[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 5</h3>
            </div>
            <div>
                <label for="value_5_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_5_1" id="value_5_1" required value="<?php echo esc_attr($values_5[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_5_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_5_2" id="value_5_2" required value="<?php echo esc_attr($values_5[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_5_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_5_3" id="value_5_3" required value="<?php echo esc_attr($values_5[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 6</h3>
            </div>
            <div>
                <label for="value_6_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_6_1" id="value_6_1" required value="<?php echo esc_attr($values_6[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_6_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_6_2" id="value_6_2" required value="<?php echo esc_attr($values_6[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_6_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_6_3" id="value_6_3" required value="<?php echo esc_attr($values_6[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 7</h3>
            </div>
            <div>
                <label for="value_7_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_7_1" id="value_7_1" required value="<?php echo esc_attr($values_7[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_7_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_7_2" id="value_7_2" required value="<?php echo esc_attr($values_7[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_7_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_7_3" id="value_7_3" required value="<?php echo esc_attr($values_7[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 8</h3>
            </div>
            <div>
                <label for="value_8_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_8_1" id="value_8_1" required value="<?php echo esc_attr($values_8[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_8_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_8_2" id="value_8_2" required value="<?php echo esc_attr($values_8[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_8_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_8_3" id="value_8_3" required value="<?php echo esc_attr($values_8[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 9</h3>
            </div>
            <div>
                <label for="value_9_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_9_1" id="value_9_1" required value="<?php echo esc_attr($values_9[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_9_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_9_2" id="value_9_2" required value="<?php echo esc_attr($values_9[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_9_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_9_3" id="value_9_3" required value="<?php echo esc_attr($values_9[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago único - 10</h3>
            </div>
            <div>
                <label for="value_10_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_10_1" id="value_10_1" required value="<?php echo esc_attr($values_10[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_10_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_10_2" id="value_10_2" required value="<?php echo esc_attr($values_10[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_10_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_10_3" id="value_10_3" required value="<?php echo esc_attr($values_10[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <button type="submit" name="values" class="button button-primary">Guardar</button>
            </div>
        </section>
    </form>
    <?php
}
//---------------------------------------------------------------------------------
// Página de configuración de valores del plugin
function values_monthly() {
    global $wpdb;

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'values_monthly';

    if (isset($_POST['values'])) {
        //--------------------------------------------------------------------
        $value_1_1 = intval(sanitize_text_field($_POST['value_1_1']));
        $value_1_2 = intval(sanitize_text_field($_POST['value_1_2']));
        $value_1_3 = intval(sanitize_text_field($_POST['value_1_3']));
        //--------------------------------------------------------------------
        $value_2_1 = intval(sanitize_text_field($_POST['value_2_1']));
        $value_2_2 = intval(sanitize_text_field($_POST['value_2_2']));
        $value_2_3 = intval(sanitize_text_field($_POST['value_2_3']));
        //--------------------------------------------------------------------
        $value_3_1 = intval(sanitize_text_field($_POST['value_3_1']));
        $value_3_2 = intval(sanitize_text_field($_POST['value_3_2']));
        $value_3_3 = intval(sanitize_text_field($_POST['value_3_3']));
        //--------------------------------------------------------------------
        $value_4_1 = intval(sanitize_text_field($_POST['value_4_1']));
        $value_4_2 = intval(sanitize_text_field($_POST['value_4_2']));
        $value_4_3 = intval(sanitize_text_field($_POST['value_4_3']));
        //--------------------------------------------------------------------
        $value_5_1 = intval(sanitize_text_field($_POST['value_5_1']));
        $value_5_2 = intval(sanitize_text_field($_POST['value_5_2']));
        $value_5_3 = intval(sanitize_text_field($_POST['value_5_3']));
        //--------------------------------------------------------------------
        $value_6_1 = intval(sanitize_text_field($_POST['value_6_1']));
        $value_6_2 = intval(sanitize_text_field($_POST['value_6_2']));
        $value_6_3 = intval(sanitize_text_field($_POST['value_6_3']));
        //--------------------------------------------------------------------
        $value_7_1 = intval(sanitize_text_field($_POST['value_7_1']));
        $value_7_2 = intval(sanitize_text_field($_POST['value_7_2']));
        $value_7_3 = intval(sanitize_text_field($_POST['value_7_3']));
        //--------------------------------------------------------------------
        $value_8_1 = intval(sanitize_text_field($_POST['value_8_1']));
        $value_8_2 = intval(sanitize_text_field($_POST['value_8_2']));
        $value_8_3 = intval(sanitize_text_field($_POST['value_8_3']));
        //--------------------------------------------------------------------
        $value_9_1 = intval(sanitize_text_field($_POST['value_9_1']));
        $value_9_2 = intval(sanitize_text_field($_POST['value_9_2']));
        $value_9_3 = intval(sanitize_text_field($_POST['value_9_3']));
        //--------------------------------------------------------------------
        $value_10_1 = intval(sanitize_text_field($_POST['value_10_1']));
        $value_10_2 = intval(sanitize_text_field($_POST['value_10_2']));
        $value_10_3 = intval(sanitize_text_field($_POST['value_10_3']));

        $value1 = intval(sanitize_text_field($_POST['value1']));
        $value2 = intval(sanitize_text_field($_POST['value2']));
        $value3 = intval(sanitize_text_field($_POST['value3']));
        $value4 = intval(sanitize_text_field($_POST['value4']));
        $value5 = intval(sanitize_text_field($_POST['value5']));
        $value6 = intval(sanitize_text_field($_POST['value6']));
    
        $registry_1 = 1;
        $registry_2 = 2;
        $registry_3 = 3;
        $registry_4 = 4;
        $registry_5 = 5;
        $registry_6 = 6;
        $registry_7 = 7;
        $registry_8 = 8;
        $registry_9 = 9;
        $registry_10 = 10;
    
        $format = array('%s');
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_1,
        );
    
        $data = array(
            'value_1' => $value_1_1,
            'value_2' => $value_1_2,
            'value_3' => $value_1_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_2,
        );
    
        $data = array(
            'value_1' => $value_2_1,
            'value_2' => $value_2_2,
            'value_3' => $value_2_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_3,
        );
    
        $data = array(
            'value_1' => $value_3_1,
            'value_2' => $value_3_2,
            'value_3' => $value_3_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_4,
        );
    
        $data = array(
            'value_1' => $value_4_1,
            'value_2' => $value_4_2,
            'value_3' => $value_4_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_5,
        );
    
        $data = array(
            'value_1' => $value_5_1,
            'value_2' => $value_5_2,
            'value_3' => $value_5_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_6,
        );
    
        $data = array(
            'value_1' => $value_6_1,
            'value_2' => $value_6_2,
            'value_3' => $value_6_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_7,
        );
    
        $data = array(
            'value_1' => $value_7_1,
            'value_2' => $value_7_2,
            'value_3' => $value_7_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_8,
        );
    
        $data = array(
            'value_1' => $value_8_1,
            'value_2' => $value_8_2,
            'value_3' => $value_8_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_9,
        );
    
        $data = array(
            'value_1' => $value_9_1,
            'value_2' => $value_9_2,
            'value_3' => $value_9_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        $condition = array(
            'id' => $registry_10,
        );
    
        $data = array(
            'value_1' => $value_10_1,
            'value_2' => $value_10_2,
            'value_3' => $value_10_3,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);
        //--------------------------------------------------------
        echo '<script>alert("Datos Guardados");</script>';
    }

    // Consulta SQL para obtener los valores de las filas 1, 2 y 3
    $sql = "SELECT id, value_1, value_2, value_3 FROM $table_name WHERE id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Crear un array asociativo para almacenar los resultados
    $values_1 = array();
    $values_2 = array();
    $values_3 = array();
    $values_4 = array();
    $values_5 = array();
    $values_6 = array();
    $values_7 = array();
    $values_8 = array();
    $values_9 = array();
    $values_10 = array();

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        if ($result->id == 1){
            $values_1[1] = $result->value_1;
            $values_1[2] = $result->value_2;
            $values_1[3] = $result->value_3;
        }
        elseif ($result->id == 2){
            $values_2[1] = $result->value_1;
            $values_2[2] = $result->value_2;
            $values_2[3] = $result->value_3;
        }
        elseif ($result->id == 3){
            $values_3[1] = $result->value_1;
            $values_3[2] = $result->value_2;
            $values_3[3] = $result->value_3;
        }
        elseif ($result->id == 4){
            $values_4[1] = $result->value_1;
            $values_4[2] = $result->value_2;
            $values_4[3] = $result->value_3;
        }
        elseif ($result->id == 5){
            $values_5[1] = $result->value_1;
            $values_5[2] = $result->value_2;
            $values_5[3] = $result->value_3;
        }
        elseif ($result->id == 6){
            $values_6[1] = $result->value_1;
            $values_6[2] = $result->value_2;
            $values_6[3] = $result->value_3;
        }
        elseif ($result->id == 7){
            $values_7[1] = $result->value_1;
            $values_7[2] = $result->value_2;
            $values_7[3] = $result->value_3;
        }
        elseif ($result->id == 8){
            $values_8[1] = $result->value_1;
            $values_8[2] = $result->value_2;
            $values_8[3] = $result->value_3;
        }
        elseif ($result->id == 9){
            $values_9[1] = $result->value_1;
            $values_9[2] = $result->value_2;
            $values_9[3] = $result->value_3;
        }
        elseif ($result->id == 10){
            $values_10[1] = $result->value_1;
            $values_10[2] = $result->value_2;
            $values_10[3] = $result->value_3;
        }
    }
    // Contenido de la página de configuración
    ?>
    <h1>Bank Account</h1>
    <form method="post" action="">
        <h3>Valores de las donaciones mensuales</h3>
        <section>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 1</h3>
            </div>
            <div>
                <label for="value_1_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_1_1" id="value_1_1" required value="<?php echo esc_attr($values_1[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_1_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_1_2" id="value_1_2" required value="<?php echo esc_attr($values_1[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_1_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_1_3" id="value_1_3" required value="<?php echo esc_attr($values_1[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 2</h3>
            </div>
            <div>
                <label for="value_2_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_2_1" id="value_2_1" required value="<?php echo esc_attr($values_2[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_2_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_2_2" id="value_2_2" required value="<?php echo esc_attr($values_2[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_2_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_2_3" id="value_2_3" required value="<?php echo esc_attr($values_2[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 3</h3>
            </div>
            <div>
                <label for="value_3_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_3_1" id="value_3_1" required value="<?php echo esc_attr($values_3[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_3_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_3_2" id="value_3_2" required value="<?php echo esc_attr($values_3[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_3_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_3_3" id="value_3_3" required value="<?php echo esc_attr($values_3[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 4</h3>
            </div>
            <div>
                <label for="value_4_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_4_1" id="value_4_1" required value="<?php echo esc_attr($values_4[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_4_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_4_2" id="value_4_2" required value="<?php echo esc_attr($values_4[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_4_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_4_3" id="value_4_3" required value="<?php echo esc_attr($values_4[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 5</h3>
            </div>
            <div>
                <label for="value_5_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_5_1" id="value_5_1" required value="<?php echo esc_attr($values_5[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_5_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_5_2" id="value_5_2" required value="<?php echo esc_attr($values_5[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_5_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_5_3" id="value_5_3" required value="<?php echo esc_attr($values_5[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 6</h3>
            </div>
            <div>
                <label for="value_6_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_6_1" id="value_6_1" required value="<?php echo esc_attr($values_6[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_6_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_6_2" id="value_6_2" required value="<?php echo esc_attr($values_6[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_6_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_6_3" id="value_6_3" required value="<?php echo esc_attr($values_6[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 7</h3>
            </div>
            <div>
                <label for="value_7_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_7_1" id="value_7_1" required value="<?php echo esc_attr($values_7[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_7_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_7_2" id="value_7_2" required value="<?php echo esc_attr($values_7[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_7_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_7_3" id="value_7_3" required value="<?php echo esc_attr($values_7[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 8</h3>
            </div>
            <div>
                <label for="value_8_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_8_1" id="value_8_1" required value="<?php echo esc_attr($values_8[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_8_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_8_2" id="value_8_2" required value="<?php echo esc_attr($values_8[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_8_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_8_3" id="value_8_3" required value="<?php echo esc_attr($values_8[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 9</h3>
            </div>
            <div>
                <label for="value_9_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_9_1" id="value_9_1" required value="<?php echo esc_attr($values_9[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_9_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_9_2" id="value_9_2" required value="<?php echo esc_attr($values_9[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_9_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_9_3" id="value_9_3" required value="<?php echo esc_attr($values_9[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <h3>Valores pago mensual - 10</h3>
            </div>
            <div>
                <label for="value_10_1">Valor 1</label>
            </div>
            <div>
                <input type="text" name="value_10_1" id="value_10_1" required value="<?php echo esc_attr($values_10[1]); ?>">
            </div>
            <br>
            <div>
                <label for="value_10_2">Valor 2</label>
            </div>
            <div>
                <input type="text" name="value_10_2" id="value_10_2" required value="<?php echo esc_attr($values_10[2]); ?>">
            </div>
            <br>
            <div>
                <label for="value_10_3">Valor 3</label>
            </div>
            <div>
                <input type="text" name="value_10_3" id="value_10_3" required value="<?php echo esc_attr($values_10[3]); ?>">
            </div>
            <br>
            <!------------------------------------------------------->
            <div>
                <button type="submit" name="values" class="button button-primary">Guardar</button>
            </div>
        </section>
    </form>
    <?php
}
//---------------------------------------------------------------------------------
// Página de configuración de valores del plugin
function saved_accounts() {
    global $wpdb;

    echo '<h1>Bank Account</h1>';
    echo '<h2>Cuentas de banco guardadas</h2>';

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'bank_accounts';

    $results = array();

    if (isset($_POST['saves_data'])) {
        $payer_id = sanitize_text_field($_POST['payer_id']);
        $table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
        $sql = $wpdb->prepare("UPDATE $table_name_bank_accounts SET payment_made = 1 WHERE id = %d", $payer_id);
        $wpdb->query($sql);

        $id_type = sanitize_text_field($_POST['id_type']);
        $id_number = sanitize_text_field($_POST['id_number']);

        $sql = "SELECT * FROM ".$table_name." WHERE id = ".$payer_id;

        $results = $wpdb->get_results($sql);

        $slug = "";
        foreach ($results as $result) {
            $description = $result->payment_description;
            if($description == "DELFIN DE RIO"){
                $slug = 'delfin';
            }
            else if($description == "ELEFANTES"){
                $slug = 'elefantes';
            }
            else if($description == "JAGUAR"){
                $slug = 'jaguar';
            }        
            else if($description == "OSO DE ANTEOJOS"){
                $slug = 'oso-de-anteojos';
            }
            else if($description == "OSO PANDA"){
                $slug = 'oso-panda';
            }
            else if($description == "TORTUGA MARINA"){
                $slug = 'tortuga-marina';
            }
            else if($description == "DONACION GENERAL"){
                $slug = 'gracias';
            }
            else if($description == "FONDO DE INCENDIOS"){
                $slug = 'fondo-incendios';
            }

            include_once(plugin_dir_path(__FILE__) . '/functions_option/functions.php');

            // Obtener la fecha actual en la zona horaria -5
            $option_2_timezone = new DateTimeZone('America/Bogota');
            $option_2_date = new DateTime('now', $option_2_timezone);
            $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

            $option_2_day = $option_2_date->format('d');
            $option_2_month = $option_2_date->format('m');
            $option_2_year = $option_2_date->format('Y');

            $option_2_total_date = $option_2_day . '-' . $option_2_month . '-' . $option_2_year;

            $inserted_id = '';

            $option_2_donation_data = [$result->monthly, $result->amount, $inserted_id, $option_2_total_date, $result->id_type . ': ' . $result->id_number];

            enviar_correo($result->email, $slug, $result->name, "", "","",false, "false", $option_2_donation_data);
        }
    }

    if (isset($_POST['search_accounts'])) {
        $start_date = sanitize_text_field($_POST['start_date']);
        $end_date = sanitize_text_field($_POST['end_date']);
    
        $start_date_formatted = date("Y-m-d 00:00:00", strtotime($start_date));
        $end_date_formatted = date("Y-m-d 23:59:59", strtotime($end_date));

        $sql = "SELECT * FROM ".$table_name." WHERE date_in BETWEEN '".$start_date_formatted."' AND '".$end_date_formatted."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos dentro del rango de fecha seleccionado</h3>';
            return;
        }
    }
    else if (isset($_POST['search_accounts_by_id'])) {
        $id_type = sanitize_text_field($_POST['id_type']);
        $id_number = sanitize_text_field($_POST['id_number']);

        $sql = "SELECT * FROM ".$table_name." WHERE id_type = '".$id_type."' AND id_number = '".$id_number."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos con el documento proporcionado</h3>';
            echo '<h3>---------------------------------------------------</h3>';
            //return;
        }
    }
    else{
        $sql = "SELECT * FROM ".$table_name;

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>-------------------------</h3>';
            echo '<h3>No hay datos para mostrar</h3>';
            return;
        }
    }

    // Contenido de la página de configuración
    ?>
    <form method="post" action="">
        <section>
            <h2>Filtrar por fecha</h2>
            <div>
                <label for="start_date">Fecha de inicio</label>
            </div>
            <div>
                <input type="date" name="start_date" id="start_date">
            </div>
            <br>
            <div>
                <label for="end_date">Fecha de fin</label>
            </div>
            <div>
                <input type="date" name="end_date" id="end_date">
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts" class="button button-primary">Buscar</button>
            </div>
        </section>
        <section>
            <h2>Filtrar por número de documento</h2>
            <div>
                <label for="id_type">Tipo de docuemtno</label>
            </div>
            <div>
                <select id="id_type" name="id_type" >
                    <option value="CC">Cédula de ciudadanía</option>
                    <option value="CE">Cédula de extranjería</option>
                    <option value="NIT">NIT</option>
                    <option value="TI">Tarjeta de identidad</option>
                    <option value="PP">Pasaporte</option>
                    <option value="RC">Registro civil de nacimiento</option>
                    <option value="DE">Documento de identificación extranjero</option>
                </select>
            </div>
            <br>
            <div>
                <label for="id_number">Número de documento</label>
            </div>
            <div>
                <input type="text" name="id_number" id="id_number" >
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts_by_id" class="button button-primary">Buscar</button>
            </div>
        </section>
        <?php if (!empty($results)) : ?>
        <section>
            <h3>Resultados de la búsqueda</h3>
            <table border="1" id="data_table">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo de Cuenta</th>
                    <th>Número de Cuenta</th>
                    <th>Nombre del Banco</th>
                    <th>Tipo de ID</th>
                    <th>Número de ID</th>
                    <th>Número de Teléfono</th>
                    <th>Email</th>
                    <th>Monto</th>
                    <th>Descripción</th>
                    <th>Día de ingreso</th>
                    <th>Donación mensual</th>
                    <th>Cobro efectuado</th>
                </tr>
                <?php
                // Iterar sobre los resultados y mostrar cada fila en la tabla
                foreach ($results as $result) {
                    echo "<tr>";
                    echo "<td>{$result->id}</td>";
                    echo "<td>{$result->name}</td>";
                    echo "<td>{$result->account_type}</td>";
                    echo "<td>{$result->account_number}</td>";
                    echo "<td>{$result->bank_name}</td>";
                    echo "<td>{$result->id_type}</td>";
                    echo "<td>{$result->id_number}</td>";
                    echo "<td>{$result->phone_number}</td>";
                    echo "<td>{$result->email}</td>";
                    echo "<td>{$result->amount}</td>";
                    echo "<td>{$result->payment_description}</td>";
                    echo "<td>{".date('d-m-Y', strtotime($result->date_in))."}</td>";
                    echo "<td>{$result->monthly}</td>";
                    if($result->payment_made == 1){
                        echo "<td><input type=\"checkbox\" name=\"{$result->id}\" id=\"{$result->id}\" checked disabled></td>";
                    }
                    else{
                        echo "<td><input type=\"checkbox\" name=\"{$result->id}\" id=\"{$result->id}\"></td>";
                    }
                    echo "</tr>";
                }
                ?>
            </table>
            <input type="hidden" id="payer_id" name="payer_id">
            <button id="saves_data" name="saves_data" style="display: none;"></button>
        </section>
        
        <section>
            <div>
                <label for="export_button">Exportar</label>
            </div>
            <div>
                <button type="button" onclick="exportToCSV()" class="button button-primary">Exportar</button>
            </div>
        </section>
        <?php endif; ?>
    </form>
    <script>

        document.getElementById('data_table').onclick = function(event) {
            var elemento = event.target;
            if (elemento.type === 'checkbox' && elemento.checked) {
                var confirmacion = confirm('¿El pago se efectuó exitosamente?');
                if (confirmacion) {
                    // El usuario hizo clic en "Aceptar"
                    document.getElementById('payer_id').value = elemento.id;
                    document.getElementById('saves_data').click();
                    console.log('Aceptado');
                } else {
                    // El usuario hizo clic en "Cancelar"
                    console.log('Cancelado');
                    elemento.checked = false; // Desmarca el checkbox si el usuario cancela
                }
            }
        };

        // Convierte los resultados de PHP a una variable JavaScript
        var resultsData = <?php echo json_encode($results); ?>;

        // Función para exportar a CSV desde JavaScript
        function exportToCSV() {
            // Crea un objeto Blob con los datos CSV
            var blob = new Blob([convertToCSV(resultsData)], { type: 'text/csv;charset=utf-8;' });

            // Crea un enlace para descargar el archivo CSV
            var link = document.createElement("a");
            if (link.download !== undefined) {
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", "bank_accounts_export.csv");
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }

        // Función para convertir datos a formato CSV
        function convertToCSV(objArray) {
            var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
            var str = '';

            // Encabezados
            for (var key in array[0]) {
                if (str != '') str += ';';
                str += key;
            }
            str += '\r\n';

            // Datos
            for (var i = 0; i < array.length; i++) {
                var line = '';
                for (var key in array[i]) {
                    if (line != '') line += ';';
                    line += array[i][key];
                }
                str += line + '\r\n';
            }

            return str;
        }
    </script>
    <?php
}
//-----------------------------------------------------------------------------------------
// Página de configuración de valores del plugin
function saved_orders() {
    global $wpdb;

    //--------------------------------------------------------------------------
    $table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';

    // Verificar si la tabla ya existe
    if($wpdb->get_var("SHOW TABLES LIKE '$table_name_bank_accounts_logs'") == $table_name_bank_accounts_logs) {
        // Preparar las instrucciones SQL para actualizar la tabla
        $sql_alter = array();
        $row = $wpdb->get_row("DESCRIBE $table_name_bank_accounts_logs 'signature_payu'");
        if (!$row) {
            $sql_alter[] = "ALTER TABLE $table_name_bank_accounts_logs ADD signature_payu VARCHAR(255)";
        }
        $row = $wpdb->get_row("DESCRIBE $table_name_bank_accounts_logs 'is_gift'");
        if (!$row) {
            $sql_alter[] = "ALTER TABLE $table_name_bank_accounts_logs ADD is_gift BOOLEAN";
        }

        // Ejecutar las instrucciones SQL si son necesarias
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        foreach($sql_alter as $sql) {
            $wpdb->query($sql);
        }
        // Asegúrate de usar dbDelta para cualquier otra estructura de tabla necesaria, aunque no es necesario para simples ALTER TABLE
    }

    //--------------------------------------------------------------------------
    $table_name_orders_data = $wpdb->prefix . 'orders_data';

    // Verificar si la tabla ya existe
    if($wpdb->get_var("SHOW TABLES LIKE '$table_name_orders_data'") == $table_name_orders_data) {
        // La tabla ya existe, verificar si el nuevo campo también existe
        $row = $wpdb->get_row("DESCRIBE $table_name_orders_data 'signature_payu'");
        
        // Si no existe el campo 'signature_payu', lo añadimos
        if (!$row) {
            $sql_alter = "ALTER TABLE $table_name_orders_data ADD signature_payu VARCHAR(255)";
            $wpdb->query($sql_alter);
        }
        // Actualiza el valor AUTO_INCREMENT si es necesario
        $wpdb->query("ALTER TABLE $table_name_orders_data AUTO_INCREMENT = 2000;");
    }
    //--------------------------------------------------------------------------
    // Crea la tabla "gift_table"
    $table_gift_table = $wpdb->prefix . 'gift_table';
    if($wpdb->get_var("SHOW TABLES LIKE '$table_gift_table'") != $table_gift_table) {
        $sql = "CREATE TABLE $table_gift_table (
            id INT(11) NOT NULL AUTO_INCREMENT,
            signature_payu VARCHAR(255),
            gift_email VARCHAR(255) NOT NULL,
            gift_name VARCHAR(255) NOT NULL,
            gift_message VARCHAR(255) NOT NULL,
            PRIMARY KEY  (id)
        );";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    //--------------------------------------------------------------------------

    echo '<h1>Bank Account</h1>';
    echo '<h2>Ordenes</h2>';

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'orders_data';

    $results = array();

    if (isset($_POST['saves_data'])) {
        $payer_id = sanitize_text_field($_POST['payer_id']);
        $class_name = sanitize_text_field($_POST['class_name']);
        $table_name_bank_accounts = $wpdb->prefix . 'orders_data';

        $sql = "";
        if($class_name === "payment_made"){
            $sql = $wpdb->prepare("UPDATE $table_name_bank_accounts SET payment_made = 1 WHERE id = %d", $payer_id);
        }
        else{
            $sql = $wpdb->prepare("UPDATE $table_name_bank_accounts SET order_shipped = 1 WHERE id = %d", $payer_id);
        }

        $wpdb->query($sql);



        $id_type = sanitize_text_field($_POST['id_type']);
        $id_number = sanitize_text_field($_POST['id_number']);

        $sql = "SELECT * FROM ".$table_name." WHERE id = ".$payer_id;

        $results = $wpdb->get_results($sql);

        $product_name = "";
        $phone_number = "";
        $product_departmentname = "";
        $city = "";
        $address = "";
        foreach ($results as $result) {
            $product_name = str_replace('Producto: ', "", $result->payment_description);
            $phone_number = $result->phone_number;
            $product_departmentname = $result->department;
            $city = $result->city;
            $address = $result->address_1 . '. ' . $result->address_2;
        }

        include_once(plugin_dir_path(__FILE__) . '/store_function/functions_store.php');

        // Obtener la fecha actual en la zona horaria -5
        $option_2_timezone = new DateTimeZone('America/Bogota');
        $option_2_date = new DateTime('now', $option_2_timezone);
        $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

        $option_2_day = $option_2_date->format('d');
        $option_2_month = $option_2_date->format('m');
        $option_2_year = $option_2_date->format('Y');

        $option_2_total_date = $option_2_day . '-' . $option_2_month . '-' . $option_2_year;

        $inserted_id = $payer_id;

        $option_2_donation_data = [$result->monthly, $result->amount, $inserted_id, $option_2_total_date, $result->id_type . ': ' . $result->id_number, $phone_number, $product_departmentname, $city, $address];

        enviar_correo_store($result->email, $product_name, $result->name, "", "","",false, "false", $option_2_donation_data);
    }

    if (isset($_POST['search_accounts'])) {
        $start_date = sanitize_text_field($_POST['start_date']);
        $end_date = sanitize_text_field($_POST['end_date']);
    
        $start_date_formatted = date("Y-m-d 00:00:00", strtotime($start_date));
        $end_date_formatted = date("Y-m-d 23:59:59", strtotime($end_date));

        $sql = "SELECT * FROM ".$table_name." WHERE date_in BETWEEN '".$start_date_formatted."' AND '".$end_date_formatted."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos dentro del rango de fecha seleccionado</h3>';
            //return;
        }
    }
    else if (isset($_POST['search_accounts_by_id'])) {
        $id_type = sanitize_text_field($_POST['id_type']);
        $id_number = sanitize_text_field($_POST['id_number']);

        $sql = "SELECT * FROM ".$table_name." WHERE id_type = '".$id_type."' AND id_number = '".$id_number."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos con el documento proporcionado</h3>';
            echo '<h3>---------------------------------------------------</h3>';
            //return;
        }
    }
    else if (isset($_POST['search_accounts_by_order_id'])) {
        $order_id = sanitize_text_field($_POST['order_id']);

        $sql = "SELECT * FROM ".$table_name." WHERE id = '".$order_id."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos con el número de orden proporcionado</h3>';
            echo '<h3>---------------------------------------------------</h3>';
            //return;
        }
    }
    else if (isset($_POST['search_accounts_by_no_shipped'])) {

        $sql = "SELECT * FROM ".$table_name." WHERE order_shipped = 0";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No se han encontrados productos no enviados</h3>';
            echo '<h3>---------------------------------------------------</h3>';
            //return;
        }
    }
    else{
        $sql = "SELECT * FROM ".$table_name;

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>-------------------------</h3>';
            echo '<h3>No hay datos para mostrar</h3>';
            return;
        }
    }

    // Contenido de la página de configuración
    ?>
    <form method="post" action="">
    <head>
        <meta charset="UTF-8">
    </head>
        <section>
            <h2>Filtrar por fecha</h2>
            <div>
                <label for="start_date">Fecha de inicio</label>
            </div>
            <div>
                <input type="date" name="start_date" id="start_date">
            </div>
            <br>
            <div>
                <label for="end_date">Fecha de fin</label>
            </div>
            <div>
                <input type="date" name="end_date" id="end_date">
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts" class="button button-primary">Buscar</button>
            </div>
        </section>
        <section>
            <h2>Filtrar por número de documento</h2>
            <div>
                <label for="id_type">Tipo de docuemtno</label>
            </div>
            <div>
                <select id="id_type" name="id_type" >
                    <option value="CC">Cédula de ciudadanía</option>
                    <option value="CE">Cédula de extranjería</option>
                    <option value="NIT">NIT</option>
                    <option value="TI">Tarjeta de identidad</option>
                    <option value="PP">Pasaporte</option>
                    <option value="RC">Registro civil de nacimiento</option>
                    <option value="DE">Documento de identificación extranjero</option>
                </select>
            </div>
            <br>
            <div>
                <label for="id_number">Número de documento</label>
            </div>
            <div>
                <input type="text" name="id_number" id="id_number" >
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts_by_id" class="button button-primary">Buscar</button>
            </div>
        </section>
        <section>
            <h2>Filtrar por número orden</h2>
            <div>
                <label for="order_id">Número de orden</label>
            </div>
            <div>
                <input type="text" name="order_id" id="order_id" >
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts_by_order_id" class="button button-primary">Buscar</button>
            </div>
        </section>
        <section>
            <h2>Filtrar por ordenes no enviadas</h2>
            <br>
            <div>
                <button type="submit" name="search_accounts_by_no_shipped" class="button button-primary">Buscar</button>
            </div>
        </section>
        <?php if (!empty($results)) : ?>
        <section>
            <h3>Resultados de la búsqueda</h3>
            <table border="1" id="data_table">
                <tr>
                    <th>N° orden</th>
                    <th>Nombre</th>
                    <th>Quien recibe</th>
                    <th>Método de pago</th>
                    <th>Tipo de ID</th>
                    <th>Número de ID</th>
                    <th>Número de Teléfono</th>
                    <th>Email</th>
                    <th>Monto</th>
                    <th>Descripción</th>
                    <th>Día de compra</th>
                    <th>Departamento</th>
                    <th>Ciudad</th>
                    <th>Dirección 1</th>
                    <th>Dirección 2</th>
                    <th>Pago efectuado</th>
                    <th>Orden enviada</th>
                </tr>
                <?php
                // Iterar sobre los resultados y mostrar cada fila en la tabla
                foreach ($results as $result) {
                    echo "<tr>";
                    echo "<td>{$result->id}</td>";
                    echo "<td>{$result->name}</td>";
                    echo "<td>{$result->who_receive}</td>";
                    echo "<td>{$result->payment_method}</td>";
                    echo "<td>{$result->id_type}</td>";
                    echo "<td>{$result->id_number}</td>";
                    echo "<td>{$result->phone_number}</td>";
                    echo "<td>{$result->email}</td>";
                    echo "<td>{$result->amount}</td>";
                    echo "<td>{$result->payment_description}</td>";
                    echo "<td>{".date('d-m-Y', strtotime($result->date_in))."}</td>";
                    echo "<td>{$result->department}</td>";
                    echo "<td>{$result->city}</td>";
                    echo "<td>{$result->address_1}</td>";
                    echo "<td>{$result->address_2}</td>";
                    if($result->payment_made == 1 || $result->payment_made == true){
                        echo "<td><input type=\"checkbox\" class=\"payment_made\" name=\"{$result->id}\" id=\"payment_made_{$result->id}\" checked disabled></td>";
                    }
                    else{
                        echo "<td><input type=\"checkbox\" class=\"payment_made\" name=\"{$result->id}\" id=\"payment_made_{$result->id}\"></td>";
                    }
                    if($result->order_shipped == 1 || $result->order_shipped == true){
                        echo "<td><input type=\"checkbox\" class=\"order_shipped\" name=\"{$result->id}\" id=\"order_shipped_{$result->id}\" checked disabled></td>";
                    }
                    else{
                        echo "<td><input type=\"checkbox\" class=\"order_shipped\" name=\"{$result->id}\" id=\"order_shipped_{$result->id}\"></td>";
                    }
                    echo "</tr>";
                }
                ?>
            </table>
            <input type="hidden" id="payer_id" name="payer_id">
            <input type="hidden" id="class_name" name="class_name">
            <button id="saves_data" name="saves_data" style="display: none;"></button>
        </section>
        
        <section>
            <div>
                <label for="export_button">Exportar</label>
            </div>
            <div>
                <button type="button" onclick="exportToXLS()" class="button button-primary">Exportar</button>
            </div>
        </section>
        <?php endif; ?>
    </form>
    <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
    <script>

        document.getElementById('data_table').onclick = function(event) {
            var elemento = event.target;
            if (elemento.type === 'checkbox' && elemento.checked) {
                if (elemento.className === 'payment_made') {
                    var confirmacion = confirm('¿El pago se efectuó exitosamente?');
                    if (confirmacion) {
                        // El usuario hizo clic en "Aceptar"
                        document.getElementById('payer_id').value = elemento.name;
                        document.getElementById('class_name').value = elemento.className;
                        document.getElementById('saves_data').click();
                        console.log('Pago aceptado');
                    } else {
                        // El usuario hizo clic en "Cancelar"
                        console.log('Pago cancelado');
                        elemento.checked = false; // Desmarca el checkbox si el usuario cancela
                    }
                } else if (elemento.className === 'order_shipped') {
                    var confirmacion = confirm('¿La orden se envió exitosamente?');
                    if (confirmacion) {
                        // Agrega tu código aquí para manejar la confirmación de envío
                        document.getElementById('payer_id').value = elemento.name;
                        document.getElementById('class_name').value = elemento.className;
                        document.getElementById('saves_data').click();
                        console.log('Orden enviada');
                    } else {
                        // Agrega tu código aquí para manejar la cancelación de envío
                        console.log('Envío cancelado');
                        elemento.checked = false; // Desmarca el checkbox si el usuario cancela
                    }
                }
            }
        };

        // Convierte los resultados de PHP a una variable JavaScript
        var resultsData = <?php echo json_encode($results); ?>;

        // Función para modificar las claves
        function modifyKeys(obj) {
            const modifiedObj = {};
            var modifiedKey;
            for (let key in obj) {
                if (obj.hasOwnProperty(key)) {
                    if (key == "id"){
                        modifiedKey = "N° orden";
                    }
                    else if (key == "name"){
                        modifiedKey = "Nombre";
                    }
                    else if (key == "payment_method"){
                        modifiedKey = "Método de pago";
                    }
                    else if (key == "id_type"){
                        modifiedKey = "Tipo de ID";
                    }
                    else if (key == "id_number"){
                        modifiedKey = "Número de ID";
                    }
                    else if (key == "phone_number"){
                        modifiedKey = "Número de Teléfono";
                    }
                    else if (key == "email"){
                        modifiedKey = "Email";
                    }
                    else if (key == "amount"){
                        modifiedKey = "Monto";
                    }
                    else if (key == "payment_description"){
                        modifiedKey = "Descripción";
                    }
                    else if (key == "date_in"){
                        modifiedKey = "Día de compra";
                    }
                    else if (key == "department"){
                        modifiedKey = "Departamento";
                    }
                    else if (key == "city"){
                        modifiedKey = "Ciudad";
                    }
                    else if (key == "address_1"){
                        modifiedKey = "Dirección 1";
                    }
                    else if (key == "address_2"){
                        modifiedKey = "Dirección 2";
                    }
                    else if (key == "payment_made"){
                        modifiedKey = "Pago efectuado";
                    }
                    else if (key == "order_shipped"){
                        modifiedKey = "Orden enviada";
                    }
                    else if (key == "who_receive"){
                        modifiedKey = "Quien recibe";
                    }

                    if (key == "payment_made" || key == "order_shipped"){
                        if (obj[key] == "0"){
                            modifiedObj[modifiedKey] = "NO";
                        }
                        else{
                            modifiedObj[modifiedKey] = "SI";
                        }
                    }
                    else{
                        modifiedObj[modifiedKey] = obj[key];
                    }
                }
            }
            return modifiedObj;
        }

        var modifiedData = resultsData.map(modifyKeys);

        function exportToXLS() {
            var worksheet = XLSX.utils.json_to_sheet(modifiedData);
            var workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
            var excelData = XLSX.write(workbook, { bookType: "xlsx", type: "array" });

            var blob = new Blob([excelData], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });

            var link = document.createElement("a");
            if (link.download !== undefined) {
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", "bank_accounts_export.xlsx");
                link.style.visibility = "hidden";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }

    </script>
    <?php
}
//-----------------------------------------------------------------------------------------
// Página de configuración de payu
function payu_settings() {
    global $wpdb;

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'payu_settings';

    if (isset($_POST['payu_settings'])) {
        $merchantId = sanitize_text_field($_POST['merchantId']);
        $accountId = sanitize_text_field($_POST['accountId']);
        $ApiKey = sanitize_text_field($_POST['ApiKey']);
        $ApiLogin = sanitize_text_field($_POST['ApiLogin']);
        $testMode = isset($_POST["testMode"]) ? true : false;
    
        $registry = 1;
    
        //$datos = array('nombre_tipo' => $nombre_app); // Cambio aquí
        $format = array('%s');
        //Value 1--------------------------------------------------------
        $condition = array(
            'id' => $registry,
        );
    
        $data = array(
            'merchantId' => $merchantId,
            'accountId' => $accountId,
            'apiKey' => $ApiKey,
            'apiLogin' => $ApiLogin,
            'testMode' => $testMode,
        );
    
        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);

        echo '<script>alert("Datos Guardados");</script>';
    }

    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_name WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Crear un array asociativo para almacenar los resultados
    $merchantId = "";
    $accountId = "";
    $ApiKey = "";
    $ApiLogin = "";
    $testMode = false;

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $merchantId = $result->merchantId;
        $accountId = $result->accountId;
        $ApiKey = $result->apiKey;
        $ApiLogin = $result->apiLogin;
        $testMode = $result->testMode;
    }

    $checked = '';

    if($testMode == true){
        $checked = 'checked';
    }

    // Contenido de la página de configuración
    ?>
    <h1>Bank Account</h1>
    <form method="post" action="">
        <h3>Configuraciones de Payu</h3>
        <section>
            <div>
                <label for="merchantId">merchantId (ID de tu comercio en PayU Latam)</label>
            </div>
            <div>
                <input type="text" name="merchantId" id="merchantId" required value="<?php echo esc_attr($merchantId); ?>">
            </div>
            <br>
            <div>
                <label for="accountId">accountId (ID de la cuenta PayU del país donde quieres vender)</label>
            </div>
            <div>
                <input type="text" name="accountId" id="accountId" required value="<?php echo esc_attr($accountId); ?>">
            </div>
            <br>
            <div>
                <label for="ApiKey">ApiKey (Contraseña entregada por PayU)</label>
            </div>
            <div>
                <input type="text" name="ApiKey" id="ApiKey" required value="<?php echo esc_attr($ApiKey); ?>">
            </div>
            <br>
            <div>
                <label for="ApiLogin">ApiLogin (entregado por PayU)</label>
            </div>
            <div>
                <input type="text" name="ApiLogin" id="ApiLogin" required value="<?php echo esc_attr($ApiLogin); ?>">
            </div>
            <br>
            <div>
                <label for="testMode">Activar Modo de Pruebas</label>
            </div>
            <div>
                <input type="checkbox" id="testMode" name="testMode" <?php echo esc_attr($checked); ?>>
            </div>
            <br>
            <div>
                <button type="submit" name="payu_settings" class="button button-primary">Guardar</button>
            </div>
        </section>
    </form>
    <?php
}
//-----------------------------------------------------------------------------------------
// Página de configuración de payu
function urls() {
    global $wpdb;

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'urls';

    if (isset($_POST['urls'])) {
        $aproved = sanitize_text_field($_POST['aproved']);
        $error = sanitize_text_field($_POST['error']);
        $pending = sanitize_text_field($_POST['pending_url']);
        $expired = sanitize_text_field($_POST['expired']);
        $delfin_de_rio = sanitize_text_field($_POST['delfin_de_rio']);
        $elefante = sanitize_text_field($_POST['elefante']);
        $jaguar = sanitize_text_field($_POST['jaguar']);
        $oso = sanitize_text_field($_POST['oso']);
        $oso_panda = sanitize_text_field($_POST['oso_panda']);
        $tortuga = sanitize_text_field($_POST['tortuga']);
        $apoya_la_causa_wwf = sanitize_text_field($_POST['apoya_la_causa_wwf']);
        $fondo_incendios = sanitize_text_field($_POST['fondo_incendios']);
            
        $registry = 1;
    
        //$datos = array('nombre_tipo' => $nombre_app); // Cambio aquí
        $format = array('%s');
        //Value 1--------------------------------------------------------
        $condition = array(
            'id' => $registry,
        );
    
        $data = array(
            'aproved' => $aproved,
            'error' => $error,
            'pending' => $pending,
            'expired' => $expired,
            'delfin_de_rio' => $delfin_de_rio,
            'elefante' => $elefante,
            'jaguar' => $jaguar,
            'oso' => $oso,
            'oso_panda' => $oso_panda,
            'tortuga' => $tortuga,
            'apoya_la_causa_wwf' => $apoya_la_causa_wwf,
            'fondo_incendios' => $fondo_incendios
        );

        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);

        echo '<script>alert("Datos Guardados");</script>';
    }

    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_name WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Crear un array asociativo para almacenar los resultados
    $aproved = "";
    $error = "";
    $pending = "";
    $expired = "";
    $delfin_de_rio = "";
    $elefante = "";
    $jaguar = "";
    $oso = "";
    $oso_panda = "";
    $tortuga = "";
    $apoya_la_causa_wwf = "";
    $fondo_incendios = "";

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $aproved = $result->aproved;
        $error = $result->error;
        $pending = $result->pending;
        $expired = $result->expired;
        $delfin_de_rio = $result->delfin_de_rio;
        $elefante = $result->elefante;
        $jaguar = $result->jaguar;
        $oso = $result->oso;
        $oso_panda = $result->oso_panda;
        $tortuga = $result->tortuga;
        $apoya_la_causa_wwf = $result->apoya_la_causa_wwf;
        $fondo_incendios = $result->fondo_incendios;
    }
    // Contenido de la página de configuración
    ?>
    <h1>Bank Account</h1>
    <form method="post" action="">
        <h3>Configuraciones de Payu</h3>
        <section>
            <div>
                <label for="aproved">URL Aprovado</label>
            </div>
            <div>
                <input type="text" name="aproved" id="aproved" required value="<?php echo esc_attr($aproved); ?>">
            </div>
            <br>
            <div>
                <label for="error">url Error</label>
            </div>
            <div>
                <input type="text" name="error" id="error" required value="<?php echo esc_attr($error); ?>">
            </div>
            <br>
            <div>
                <label for="pending_url">URL Pendiente</label>
            </div>
            <div>
                <input type="text" name="pending_url" id="pending_url" required value="<?php echo esc_attr($pending); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Expirada</label>
            </div>
            <div>
                <input type="text" name="expired" id="expired" required value="<?php echo esc_attr($expired); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Delfin de rio</label>
            </div>
            <div>
                <input type="text" name="delfin_de_rio" id="delfin_de_rio" required value="<?php echo esc_attr($delfin_de_rio); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Elefante</label>
            </div>
            <div>
                <input type="text" name="elefante" id="elefante" required value="<?php echo esc_attr($elefante); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Jaguar</label>
            </div>
            <div>
                <input type="text" name="jaguar" id="jaguar" required value="<?php echo esc_attr($jaguar); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Oso de anteojos</label>
            </div>
            <div>
                <input type="text" name="oso" id="oso" required value="<?php echo esc_attr($oso); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Oso Panda</label>
            </div>
            <div>
                <input type="text" name="oso_panda" id="oso_panda" required value="<?php echo esc_attr($oso_panda); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Tortuga</label>
            </div>
            <div>
                <input type="text" name="tortuga" id="tortuga" required value="<?php echo esc_attr($tortuga); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Apoya la causa wwf</label>
            </div>
            <div>
                <input type="text" name="apoya_la_causa_wwf" id="apoya_la_causa_wwf" required value="<?php echo esc_attr($apoya_la_causa_wwf); ?>">
            </div>
            <br>
            <div>
                <label for="expired">URL Fondo de incendios</label>
            </div>
            <div>
                <input type="text" name="fondo_incendios" id="fondo_incendios" required value="<?php echo esc_attr($fondo_incendios); ?>">
            </div>
            <br>
            <div>
                <button type="submit" name="urls" class="button button-primary">Guardar</button>
            </div>
        </section>
    </form>
    <?php
}
//-----------------------------------------------------------------------------------------
// Página de configuración de payu
function urls_store() {
    global $wpdb;

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'urls_store';

    if (isset($_POST['urls'])) {
        $aproved = sanitize_text_field($_POST['aproved']);
        $error = sanitize_text_field($_POST['error']);

        $registry = 1;
    
        //$datos = array('nombre_tipo' => $nombre_app); // Cambio aquí
        $format = array('%s');
        //Value 1--------------------------------------------------------
        $condition = array(
            'id' => $registry,
        );
    
        $data = array(
            'aproved' => $aproved,
            'error' => $error,
        );

        //$wpdb->insert($tabla, $datos, $formato);
        $wpdb->update($table_name, $data, $condition, $format);

        echo '<script>alert("Datos Guardados");</script>';
    }

    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_name WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Crear un array asociativo para almacenar los resultados
    $aproved = "";
    $error = "";

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $aproved = $result->aproved;
        $error = $result->error;
    }
    // Contenido de la página de configuración

    ?>
    <h1>Bank Account</h1>
    <form method="post" action="">
        <h3>Configuraciones de Tienda</h3>
        <section>
            <div>
                <label for="aproved">URL Aprovado</label>
            </div>
            <div>
                <input type="text" name="aproved" id="aproved" required value="<?php echo esc_attr($aproved); ?>">
            </div>
            <br>
            <div>
                <label for="error">url Error</label>
            </div>
            <div>
                <input type="text" name="error" id="error" required value="<?php echo esc_attr($error); ?>">
            </div>
            <br>
            <div>
                <button type="submit" name="urls" class="button button-primary">Guardar</button>
            </div>
        </section>
    </form>
    <?php
}
//---------------------------------------------------------------------------------
// Página de configuración de valores del plugin
function tokens() {
    global $wpdb;

    echo '<h1>Bank Account</h1>';
    echo '<h3>Tokens Guardados</h3>';

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'tokensCards';

    $results = array();

    $sql = "SELECT * FROM ".$table_name;

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>-------------------------</h3>';
            echo '<h3>No hay datos para mostrar</h3>';
            return;
        }

    // Contenido de la página de configuración
    ?>
    <form method="post" action="">
        <?php if (!empty($results)) : ?>
        <section>
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>Token</th>
                    <th>Nombre</th>
                    <th>Documento</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Método de pago</th>
                    <th>Monto de donación</th>
                    <th>Día de cobro</th>
                </tr>
                <?php
                // Iterar sobre los resultados y mostrar cada fila en la tabla
                foreach ($results as $result) {
                    echo "<tr>";
                    echo "<td>{$result->id}</td>";
                    echo "<td>{$result->token_card}</td>";
                    echo "<td>{$result->payer_name}</td>";
                    echo "<td>{$result->document}</td>";
                    echo "<td>{$result->phone_number}</td>";
                    echo "<td>{$result->payer_email}</td>";
                    echo "<td>{$result->paymentMethod}</td>";
                    echo "<td>{$result->amount_to_discount}</td>";
                    echo "<td>{$result->discount_day}</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </section>
        <?php endif; ?>
    </form>
    <?php
}
//-----------------------------------------------------------------------------------------
function logs() {
    global $wpdb;

    echo '<h1>Bank Account</h1>';
    echo '<h3>LOGS</h3>';

    // Nombre de la tabla
    $table_name = $wpdb->prefix . 'bank_accounts_logs';

    $results = array();

    if (isset($_POST['search_accounts'])) {
        $start_date = sanitize_text_field($_POST['start_date']);
        $end_date = sanitize_text_field($_POST['end_date']);
    
        $start_date_formatted = date("Y-m-d 00:00:00", strtotime($start_date));
        $end_date_formatted = date("Y-m-d 23:59:59", strtotime($end_date));

        $sql = "SELECT * FROM ".$table_name." WHERE date_in BETWEEN '".$start_date_formatted."' AND '".$end_date_formatted."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos dentro del rango de fecha seleccionado</h3>';
            return;
        }
    }
    else if (isset($_POST['search_accounts_by_id'])) {
        $id_type = sanitize_text_field($_POST['id_type']);
        $id_number = sanitize_text_field($_POST['id_number']);

        $sql = "SELECT * FROM ".$table_name." WHERE id_type = '".$id_type."' AND id_number = '".$id_number."'";

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>---------------------------------------------------</h3>';
            echo '<h3>No hay datos con el documento proporcionado</h3>';
            echo '<h3>---------------------------------------------------</h3>';
            //return;
        }
    }
    else{
        $sql = "SELECT * FROM ".$table_name;

        $results = $wpdb->get_results($sql);
        if (empty($results)){
            echo '<h3>-------------------------</h3>';
            echo '<h3>No hay datos para mostrar</h3>';
            return;
        }
    }

    ?>
    <form method="post" action="">
        <section>
            <h2>Filtrar por fecha</h2>
            <div>
                <label for="start_date">Fecha de inicio</label>
            </div>
            <div>
                <input type="date" name="start_date" id="start_date">
            </div>
            <br>
            <div>
                <label for="end_date">Fecha de fin</label>
            </div>
            <div>
                <input type="date" name="end_date" id="end_date">
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts" class="button button-primary">Buscar</button>
            </div>
        </section>
        <section>
            <h2>Filtrar por número de documento</h2>
            <div>
                <label for="id_type">Tipo de docuemtno</label>
            </div>
            <div>
                <select id="id_type" name="id_type" >
                    <option value="CC">Cédula de ciudadanía</option>
                    <option value="CE">Cédula de extranjería</option>
                    <option value="NIT">NIT</option>
                    <option value="TI">Tarjeta de identidad</option>
                    <option value="PP">Pasaporte</option>
                    <option value="RC">Registro civil de nacimiento</option>
                    <option value="DE">Documento de identificación extranjero</option>
                </select>
            </div>
            <br>
            <div>
                <label for="id_number">Número de documento</label>
            </div>
            <div>
                <input type="text" name="id_number" id="id_number" >
            </div>
            <br>
            <div>
                <button type="submit" name="search_accounts_by_id" class="button button-primary">Buscar</button>
            </div>
        </section>
        <?php if (!empty($results)) : ?>
        <section>
            <h3>Resultados de la búsqueda</h3>
            <table border="1" id="data_table">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Método de pago</th>
                    <th>Tipo de ID</th>
                    <th>Número de ID</th>
                    <th>Número de Teléfono</th>
                    <th>Email</th>
                    <th>Monto</th>
                    <th>Descripción</th>
                    <th>Día de ingreso</th>
                    <th>Donación mensual</th>
                    <th>Estado final</th>
                    <th>T&C</th>
                </tr>
                <?php
                // Iterar sobre los resultados y mostrar cada fila en la tabla
                foreach ($results as $result) {
                    echo "<tr>";
                    echo "<td>{$result->id}</td>";
                    echo "<td>{$result->name}</td>";
                    echo "<td>{$result->payment_method}</td>";
                    echo "<td>{$result->id_type}</td>";
                    echo "<td>{$result->id_number}</td>";
                    echo "<td>{$result->phone_number}</td>";
                    echo "<td>{$result->email}</td>";
                    echo "<td>{$result->amount}</td>";
                    echo "<td>{$result->payment_description}</td>";
                    echo "<td>{".date('d-m-Y', strtotime($result->date_in))."}</td>";
                    echo "<td>{$result->monthly}</td>";
                    echo "<td>{$result->final_result}</td>";
                    echo "<td>SI</td>";
                    echo "</tr>";
                }
                ?>
            </table>
            <input type="hidden" id="payer_id" name="payer_id">
            <button id="saves_data" name="saves_data" style="display: none;"></button>
        </section>
        <section>
            <div>
                <label for="export_button">Exportar</label>
            </div>
            <div>
                <button type="button" onclick="exportToCSV()" class="button button-primary">Exportar</button>
            </div>
        </section>
        <?php endif; ?>
    </form>
    <script>

        document.getElementById('data_table').onclick = function(event) {
            var elemento = event.target;
            if (elemento.type === 'checkbox' && elemento.checked) {
                var confirmacion = confirm('¿El pago se efectuó exitosamente?');
                if (confirmacion) {
                    // El usuario hizo clic en "Aceptar"
                    document.getElementById('payer_id').value = elemento.id;
                    document.getElementById('saves_data').click();
                    console.log('Aceptado');
                } else {
                    // El usuario hizo clic en "Cancelar"
                    console.log('Cancelado');
                    elemento.checked = false; // Desmarca el checkbox si el usuario cancela
                }
            }
        };

        // Convierte los resultados de PHP a una variable JavaScript
        var resultsData = <?php echo json_encode($results); ?>;

        // Función para exportar a CSV desde JavaScript
        function exportToCSV() {
            // Crea un objeto Blob con los datos CSV
            var blob = new Blob([convertToCSV(resultsData)], { type: 'text/csv;charset=utf-8;' });

            // Crea un enlace para descargar el archivo CSV
            var link = document.createElement("a");
            if (link.download !== undefined) {
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", "bank_accounts_export.csv");
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }

        // Función para convertir datos a formato CSV
        function convertToCSV(objArray) {
            var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
            var str = '';

            // Encabezados
            for (var key in array[0]) {
                if (str != '') str += ';';
                str += key;
            }
            str += '\r\n';

            // Datos
            for (var i = 0; i < array.length; i++) {
                var line = '';
                for (var key in array[i]) {
                    if (line != '') line += ';';
                    line += array[i][key];
                }
                str += line + '\r\n';
            }

            return str;
        }
    </script>
    <?php

}
//General /////////////////////////////////////////////////////////////////////////////
//-----------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_shortcode() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_admin-page/bank_account_admin-page.php');
    return ob_get_clean();
}
add_shortcode('bank_account', 'bank_account_shortcode');
//-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_shortcode_option_1() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_admin-page/bank_account_admin-page_option_1.php');
    return ob_get_clean();
}
add_shortcode('bank_account_option_1', 'bank_account_shortcode_option_1');
//-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_shortcode_option_2() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_admin-page/bank_account_admin-page_option_2.php');
    return ob_get_clean();
}
add_shortcode('bank_account_option_2', 'bank_account_shortcode_option_2');
//-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_shortcode_option_3() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_admin-page/bank_account_admin-page_option_3.php');
    return ob_get_clean();
}
add_shortcode('bank_account_option_3', 'bank_account_shortcode_option_3');
//-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_shortcode_option_4() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_admin-page/bank_account_admin-page_option_4.php');
    return ob_get_clean();
}
add_shortcode('bank_account_option_4', 'bank_account_shortcode_option_4');
//Unique /////////////////////////////////////////////////////////////////////////////
//-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_unique_shortcode_option_1() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_1.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_1', 'bank_account_unique_shortcode_option_1');
// Shortcode del plugin
function bank_account_unique_shortcode_option_2() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_2.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_2', 'bank_account_unique_shortcode_option_2');
// Shortcode del plugin
function bank_account_unique_shortcode_option_3() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_3.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_3', 'bank_account_unique_shortcode_option_3');
// Shortcode del plugin
function bank_account_unique_shortcode_option_4() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_4.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_4', 'bank_account_unique_shortcode_option_4');
// Shortcode del plugin
function bank_account_unique_shortcode_option_5() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_5.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_5', 'bank_account_unique_shortcode_option_5');
// Shortcode del plugin
function bank_account_unique_shortcode_option_6() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_6.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_6', 'bank_account_unique_shortcode_option_6');
// Shortcode del plugin
function bank_account_unique_shortcode_option_7() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_7.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_7', 'bank_account_unique_shortcode_option_7');
// Shortcode del plugin
function bank_account_unique_shortcode_option_8() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_8.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_8', 'bank_account_unique_shortcode_option_8');
// Shortcode del plugin
function bank_account_unique_shortcode_option_9() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_9.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_9', 'bank_account_unique_shortcode_option_9');
// Shortcode del plugin
function bank_account_unique_shortcode_option_10() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_unique_admin-page/bank_account_unique_admin-page_option_10.php');
    return ob_get_clean();
}
add_shortcode('bank_account_unique_option_10', 'bank_account_unique_shortcode_option_10');
//Monthly /////////////////////////////////////////////////////////////////////////////
//-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_monthly_shortcode_option_1() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_1.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_1', 'bank_account_monthly_shortcode_option_1');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_2() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_2.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_2', 'bank_account_monthly_shortcode_option_2');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_3() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_3.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_3', 'bank_account_monthly_shortcode_option_3');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_4() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_4.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_4', 'bank_account_monthly_shortcode_option_4');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_5() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_5.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_5', 'bank_account_monthly_shortcode_option_5');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_6() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_6.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_6', 'bank_account_monthly_shortcode_option_6');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_7() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_7.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_7', 'bank_account_monthly_shortcode_option_7');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_8() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_8.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_8', 'bank_account_monthly_shortcode_option_8');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_9() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_9.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_9', 'bank_account_monthly_shortcode_option_9');
// Shortcode del plugin
function bank_account_monthly_shortcode_option_10() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_monthly_admin-page/bank_account_monthly_admin-page_option_10.php');
    return ob_get_clean();
}
add_shortcode('bank_account_monthly_option_10', 'bank_account_monthly_shortcode_option_10');
//Payment-------------------------------------------------------------------------------------------------
// Shortcode del plugin
function bank_account_payment_shortcode_option_1() {
    ob_start();
    // Incluye el archivo correspondiente, por ejemplo, 'myplugin-admin-page.php'
    include(plugin_dir_path(__FILE__) . '/bank_account_payment_admin-page/bank_account_payment_admin-page_option_1.php');
    return ob_get_clean();
}
add_shortcode('bank_account_payment_option_1', 'bank_account_payment_shortcode_option_1');