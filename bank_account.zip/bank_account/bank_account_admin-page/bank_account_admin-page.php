<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option/functions.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState'])) {
    $aproved = "";
    $error = "";
    $pending = "";
    $expired = "";
    $delfin_de_rio = "";
    $elefante = "";
    $jaguar = "";
    $oso = "";
    $oso_panda = "";
    $tortuga = "";
    $apoya_la_causa_wwf = "";
    $fondo_incendios = "";

    $table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_urls WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $aproved = $result->aproved;
        $error = $result->error;
        $pending = $result->pending;
        $expired = $result->expired;
        $delfin_de_rio = $result->delfin_de_rio;
        $elefante = $result->elefante;
        $jaguar = $result->jaguar;
        $oso = $result->oso;
        $oso_panda = $result->oso_panda;
        $tortuga = $result->tortuga;
        $apoya_la_causa_wwf = $result->apoya_la_causa_wwf;
        $fondo_incendios = $result->fondo_incendios;
    }

    //--------------------------------------------------------------------------
    $signature = sanitize_text_field($_GET['description']);
    $desired_signature = $signature;
    //--------------------------------------------------------------------------
    $table_name_orders_data = $wpdb->prefix . 'orders_data';

    $query = $wpdb->prepare("SELECT * FROM $table_name_orders_data WHERE signature_payu = %s", $desired_signature);
    $row = null;
    $row = $wpdb->get_row($query);
    //--------------------------------------------------------------------------
    if (empty($row)){
        $table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';

        $query = $wpdb->prepare("SELECT * FROM $table_name_bank_accounts_logs WHERE signature_payu = %s", $desired_signature);

        $row = $wpdb->get_row($query);

        $nombreCookieValue = '';
        $correoCookieValue = '';
        $slugCookieValue = '';
        $monthly_payu_bool = false;
        $amount = '';
        $tipoIdentificacionPayu = '';
        $identification = '';
        $phone_CookieValue = '';
        $is_gift_payu_bool = false;
        
        if (null !== $row){
            $nombreCookieValue = $row->name;
            $correoCookieValue = $row->email;
            $slugCookieValue = $row->payment_description;
            $amount = $row->amount;
            $tipoIdentificacionPayu = $row->id_type;
            $identification = $row->id_number;
            $phone_CookieValue = $row->phone_number;

            if ($row->is_gift == 1) {
                $is_gift_payu_bool = true;
            } else {
                $is_gift_payu_bool = false;
            }
        }
        //--------------------------------------------------------------------------
        $gift_email_payu = '';
        $gift_name_payu = '';
        $gift_message_payu = '';
        if($is_gift_payu_bool){
            $table_name_gift_table = $wpdb->prefix . 'gift_table';

            $query = $wpdb->prepare("SELECT * FROM $table_name_gift_table WHERE signature_payu = %s", $desired_signature);

            $row = $wpdb->get_row($query);

            if (null !== $row){
                $gift_email_payu = $row->gift_email;
                $gift_name_payu = $row->gift_name;
                $gift_message_payu = $row->gift_message;
            }
        }
        //--------------------------------------------------------------------------
        $donation_data = array();
        //--------------------------------------------------------------------------
        $stateValue = sanitize_text_field($_GET['transactionState']);
        //--------------------------------------------------------------------------
        if ($stateValue == "4" || $stateValue == 4) {
            $urlRedirect = $aproved;
            if (strpos($slugCookieValue, 'delfin') !== false) {
                $urlRedirect = $delfin_de_rio;
            } elseif (strpos($slugCookieValue, 'elefantes') !== false) {
                $urlRedirect = $elefante;
            } elseif (strpos($slugCookieValue, 'jaguar') !== false) {
                $urlRedirect = $jaguar;
            } elseif (strpos($slugCookieValue, 'oso-de-anteojos') !== false) {
                $urlRedirect = $oso;
            } elseif (strpos($slugCookieValue, 'oso-panda') !== false) {
                $urlRedirect = $oso_panda;
            } elseif (strpos($slugCookieValue, 'tortuga') !== false) {
                $urlRedirect = $tortuga;
            } elseif (strpos($slugCookieValue, 'apoyanos') !== false) {
                $urlRedirect = $apoya_la_causa_wwf;
            } elseif (strpos($slugCookieValue, 'fondo-incendios') !== false) {
                $urlRedirect = $fondo_incendios;
            }

            // Obtener la fecha actual en la zona horaria -5
            $timezone = new DateTimeZone('America/Bogota');
            $date = new DateTime('now', $timezone);
            $date_formatted = $date->format('Y-m-d H:i:s');

            $day = $date->format('d');
            $month = $date->format('m');
            $year = $date->format('Y');

            $total_date = $day . '-' . $month . '-' . $year;

            $inserted_id = "";

            $donation_data = [
                $monthly_payu_bool,
                $amount,
                $inserted_id,
                $total_date,
                $tipoIdentificacionPayu . ': ' . $identification
            ];

            enviar_correo($correoCookieValue, $slugCookieValue, $nombreCookieValue,         "",            "",          "",   false,        "payu", $donation_data);

            if ($is_gift_payu_bool == true) {
                enviar_correo($gift_email_payu, $slugCookieValue, $gift_name_payu, $gift_name_payu, $gift_message_payu, $gift_email_payu, true, "", false);
            }

            echo "<script>window.location.assign('".$urlRedirect."');</script>";
            //wp_redirect($urlRedirect);
        } else {
            echo "<script>window.location.assign('".$error."');</script>";
            //wp_redirect($error);
        }

        //----------------------------------------------------------------------------------------
        // Obtener la fecha actual en la zona horaria -5
        $timezone = new DateTimeZone('America/Bogota');
        $date = new DateTime('now', $timezone);
        $date_formatted = $date->format('Y-m-d H:i:s');

        $final_status = "No Aprobada";
        if ($stateValue == "4" || $stateValue == 4){
            $final_status = "Aprobada";
        }

        $description = "DONACION GENERAL";
        if (strpos($slugCookieValue, 'delfin') !== false) {
            $description = "DELFIN DE RIO";
        } elseif (strpos($slugCookieValue, 'elefantes') !== false) {
            $description = "ELEFANTES";
        } elseif (strpos($slugCookieValue, 'jaguar') !== false) {
            $description = "JAGUAR";
        } elseif (strpos($slugCookieValue, 'oso-de-anteojos') !== false) {
            $description = "OSO DE ANTEOJOS";
        } elseif (strpos($slugCookieValue, 'oso-panda') !== false) {
            $description = "OSO PANDA";
        } elseif (strpos($slugCookieValue, 'tortuga') !== false) {
            $description = "TORTUGA MARINA";
        } elseif (strpos($slugCookieValue, 'apoyanos') !== false) {
            $description = "DONACION GENERAL";
        } elseif (strpos($slugCookieValue, 'fondo-incendios') !== false) {
            $description = "FONDO DE INCENDIOS";
        } else {
            $description = "DONACION GENERAL";
        }
        //----------------------------------------------------------------------------------------
        $signature_payu_specific = $signature;

        $new_data = array(
            'payment_description' => $description,
            'final_result' => $final_status
        );

        $where = array(
            'signature_payu' => $signature_payu_specific
        );

        $data_format = array('%s');
        $where_format = array('%s');

        $updated = $wpdb->update($table_name_bank_accounts_logs, $new_data, $where, $data_format, $where_format);

        //----------------------------------------------------------------------------------------
        exit;
    }
}
//--------------------------------------------------------------------------------------------
if (isset($_REQUEST['transactionState'])) {
    $aproved = "";
    $error = "";
    $pending = "";
    $expired = "";
    $delfin_de_rio = "";
    $elefante = "";
    $jaguar = "";
    $oso = "";
    $oso_panda = "";
    $tortuga = "";
    $apoya_la_causa_wwf = "";
    $fondo_incendios = "";

    $table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_urls WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $aproved = $result->aproved;
        $error = $result->error;
        $pending = $result->pending;
        $expired = $result->expired;
        $delfin_de_rio = $result->delfin_de_rio;
        $elefante = $result->elefante;
        $jaguar = $result->jaguar;
        $oso = $result->oso;
        $oso_panda = $result->oso_panda;
        $tortuga = $result->tortuga;
        $apoya_la_causa_wwf = $result->apoya_la_causa_wwf;
        $fondo_incendios = $result->fondo_incendios;
    }

    if ($_REQUEST['transactionState']) {

        if ($_REQUEST['transactionState'] == "4") {

            $nombreCookie = "proyecto_donaciones_colombia_nombre";
            $nombreCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$nombreCookie])) {
                // Obtener el valor de la cookie
                $nombreCookieValue = $_COOKIE[$nombreCookie];
            }

            $correoCookie = "proyecto_donaciones_colombia_correo";
            $correoCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$correoCookie])) {
                // Obtener el valor de la cookie
                $correoCookieValue = $_COOKIE[$correoCookie];
            }

            $slugCookie = "proyecto_donaciones_colombia_slug";
            $slugCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$slugCookie])) {
                // Obtener el valor de la cookie
                $slugCookieValue = $_COOKIE[$slugCookie];
            }

            $urlRedirect = $aproved;
            if (strpos($slugCookieValue, 'delfin') !== false) {
                $urlRedirect = $delfin_de_rio;
            } elseif (strpos($slugCookieValue, 'elefantes') !== false) {
                $urlRedirect = $elefante;
            } elseif (strpos($slugCookieValue, 'jaguar') !== false) {
                $urlRedirect = $jaguar;
            } elseif (strpos($slugCookieValue, 'oso-de-anteojos') !== false) {
                $urlRedirect = $oso;
            } elseif (strpos($slugCookieValue, 'oso-panda') !== false) {
                $urlRedirect = $oso_panda;
            } elseif (strpos($slugCookieValue, 'tortuga') !== false) {
                $urlRedirect = $tortuga;
            } elseif (strpos($slugCookieValue, 'apoyanos') !== false) {
                $urlRedirect = $apoya_la_causa_wwf;
            } elseif (strpos($slugCookieValue, 'fondo-incendios') !== false) {
                $urlRedirect = $fondo_incendios;
            }

            enviar_correo($correoCookieValue, $slugCookieValue, $nombreCookieValue, false, false);
            echo $urlRedirect;
            wp_redirect($urlRedirect);
        } else if ($_REQUEST['transactionState'] == "6" || $_REQUEST['transactionState'] == "104") {
            wp_redirect($error);
        }
        if ($_REQUEST['transactionState'] == "5") {
            wp_redirect($expired);
        }
        if ($_REQUEST['transactionState'] == "7") {
            wp_redirect($pending);
        }

        exit;
    }
}

// Nombre de la tabla
$table_name_values = $wpdb->prefix . 'values';

// Consulta SQL para obtener los valores de las filas 1, 2 y 3
$sql = "SELECT id, value FROM $table_name_values WHERE id IN (1, 2, 3, 4, 5, 6)";

// Ejecutar la consulta
$results = $wpdb->get_results($sql);

// Crear un array asociativo para almacenar los resultados
$values = array();

// Recorrer los resultados y asignar los valores al array
foreach ($results as $result) {
    $values[$result->id] = $result->value;
}

// Codificar el array en formato JSON para usarlo en JavaScript
$values_json = json_encode($values);

$timezone = new DateTimeZone('America/Bogota');
$date = new DateTime('now', $timezone);
$reference = $date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$cookie = "";
// Nombre de la cookie
$cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$cookieName])) {
    // Obtiene el valor de la cookie
    $cookie = $_COOKIE[$cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($cookieName, '', time() - 3600, '/'); // Borra la cookie
        $newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($cookieName, $newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $sessionId = session_id();
    setcookie($cookieName, $sessionId, time() + 3600, '/');
    $cookie = $_COOKIE[$cookieName];
}

$deviceSessionId = md5($cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$sql = "SELECT * FROM $table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$results = $wpdb->get_results($sql);

// Crear un array asociativo para almacenar los resultados
$merchantId = "";
$accountId = "";
$ApiKey = "";
$ApiLogin = "";
$testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($results as $result) {
    $merchantId = $result->merchantId;
    $accountId = $result->accountId;
    $ApiKey = $result->apiKey;
    $ApiLogin = $result->apiLogin;
    $testMode = $result->testMode ? "1" : "0";
}

$setTest = "";
$url = "";
$tokenURL = "";
// URL de la API
if ($testMode == "1") {
    $setTest = true;
    $url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $setTest = false;
    $url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $ApiLogin,
        'apiKey' => $ApiKey
    ),
    'test' => $setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$json_data_bank_list = json_encode($data_bank_list);

// Configuración de la solicitud cURL
$ch_bank_list = curl_init($url);
curl_setopt($ch_bank_list, CURLOPT_POST, 1);
curl_setopt($ch_bank_list, CURLOPT_POSTFIELDS, $json_data_bank_list);
curl_setopt($ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$response_bank_list = curl_exec($ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($ch_bank_list);

// Decodificar la respuesta XML
$response_data_bank_list_xml = simplexml_load_string($response_bank_list);

// Convertir SimpleXMLElement a array
$response_data_bank_list_array = json_decode(json_encode($response_data_bank_list_xml), true);

$json_result_bank_list = json_encode($response_data_bank_list_array);

$array_result_bank_list = json_decode($json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($array_result_bank_list['banks']['bank']) && is_array($array_result_bank_list['banks']['bank'])) {
    foreach ($array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['payu'])) {
    $amount = sanitize_text_field($_POST['amount']);
    //$reference = 'abcde475674675';
    $reference = sanitize_text_field($_POST['referenceCode']);
    $description = sanitize_text_field($_POST['description']);
    $notifyUrl = sanitize_text_field($_POST['responseUrl']);
    $fullName = sanitize_text_field($_POST['payerFullName']) . ' ' . sanitize_text_field($_POST['payerLastName']);

    $tipoIdentificacionPayu = sanitize_text_field($_POST['tipoIdentificacionPayu']);

    $emailAddress = sanitize_text_field($_POST['buyerEmail']);
    $contactPhone = sanitize_text_field($_POST['payerPhone']);
    $creditCardNumber = sanitize_text_field($_POST['card_number']);
    $creditCardSecurityCode = sanitize_text_field($_POST['cvv_card']);
    $creditCardExpirationDate = sanitize_text_field($_POST['expiration_year']) . '/' . sanitize_text_field($_POST['expiration_month']);
    $creditCardName = $fullName;
    $paymentMethod = sanitize_text_field($_POST['payment_method_1']);
    $identification = sanitize_text_field($_POST['numeroIdentificacionPayu']);

    $gift_email_payu = sanitize_text_field($_POST['gift_email_payu']);
    $gift_name_payu = sanitize_text_field($_POST['gift_name_payu']);
    $gift_message_payu = sanitize_text_field($_POST['gift_message_payu']);
    $is_gift_payu_string = sanitize_text_field($_POST['is_gift_payu']);

    $monthly_payu_string = sanitize_text_field($_POST['monthly_payu']);

    $monthly_payu_bool = false;
    if ($monthly_payu_string == "1") {
        $monthly_payu_bool = true;
    } else {
        $monthly_payu_bool = false;
    }

    $is_gift_payu_bool = false;
    if ($is_gift_payu_string == "1") {
        $is_gift_payu_bool = true;
    } else {
        $is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($monthly_payu_bool == true) {
        $tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $ApiLogin,
                "apiKey" => $ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $identification,
                "name" => $fullName,
                "identificationNumber" => $identification,
                "paymentMethod" => $paymentMethod,
                "number" => $creditCardNumber,
                "expirationDate" => $creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $json_data = json_encode($tokenData);

        // Configuración de la solicitud cURL
        $ch = curl_init($tokenURL);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $response = curl_exec($ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($ch);
        }

        // Cerrar la conexión cURL
        curl_close($ch);

        // Decodificar la respuesta XML
        $response_data_xml = simplexml_load_string($response);

        // Convertir SimpleXMLElement a array
        $response_data_array = json_decode(json_encode($response_data_xml), true);

        $json_result = json_encode($response_data_array);

        $array_result = json_decode($json_result, true);

        $creditCardToken = "";
        if ($array_result['creditCardToken']['creditCardTokenId']) {
            $creditCardToken = $array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($creditCardToken != "") {

            $format = array('%s');

            $table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $table_name_token,
                array(
                    'document' => $identification,
                    'token_card' => $creditCardToken,
                    'amount_to_discount' => $amount,
                    'discount_day' => date('d'),
                    'payer_name' => $fullName,
                    'phone_number' => $contactPhone,
                    'payer_email' => $emailAddress,
                    'cvv_card' => $creditCardSecurityCode,
                    'paymentMethod' => $paymentMethod
                ),
                $format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $preSignature = $ApiKey . '~' . $merchantId . '~' . $reference . '~' . $amount . '~' . 'COP';

    $signature = sha256($preSignature);

    //----------------------------------------------

    $data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $ApiKey,
            'apiLogin' => $ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $accountId,
                'referenceCode' => $reference,
                'description' => $description,
                'language' => 'es',
                'signature' => $signature,
                'notifyUrl' => $notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $fullName,
                'emailAddress' => $emailAddress,
                'contactPhone' => $contactPhone
            ),
            'creditCard' => array(
                'number' => $creditCardNumber,
                'securityCode' => $creditCardSecurityCode,
                'expirationDate' => $creditCardExpirationDate,
                'name' => $creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $deviceSessionId,
            'ipAddress' => $ipAddress,
            'cookie' => $cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $setTest
    );

    // Convertir datos a formato JSON
    $json_data = json_encode($data);

    // Configuración de la solicitud cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $response = curl_exec($ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($ch);
    }

    // Cerrar la conexión cURL
    curl_close($ch);

    // Decodificar la respuesta XML
    $response_data_xml = simplexml_load_string($response);

    // Convertir SimpleXMLElement a array
    $response_data_array = json_decode(json_encode($response_data_xml), true);

    $json_result = json_encode($response_data_array);

    $array_result = json_decode($json_result, true);

    $stateValue = $array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $aproved = "";
    $error = "";
    $pending = "";
    $expired = "";
    $delfin_de_rio = "";
    $elefante = "";
    $jaguar = "";
    $oso = "";
    $oso_panda = "";
    $tortuga = "";
    $apoya_la_causa_wwf = "";
    $fondo_incendios = "";

    $table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_urls WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $aproved = $result->aproved;
        $error = $result->error;
        $pending = $result->pending;
        $expired = $result->expired;
        $delfin_de_rio = $result->delfin_de_rio;
        $elefante = $result->elefante;
        $jaguar = $result->jaguar;
        $oso = $result->oso;
        $oso_panda = $result->oso_panda;
        $tortuga = $result->tortuga;
        $apoya_la_causa_wwf = $result->apoya_la_causa_wwf;
        $fondo_incendios = $result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $slugCookie = "proyecto_donaciones_colombia_slug";
    $slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$slugCookie])) {
        // Obtener el valor de la cookie
        $slugCookieValue = $_COOKIE[$slugCookie];
    }

    if ($stateValue == "APPROVED") {

        $nombreCookie = "proyecto_donaciones_colombia_nombre";
        $nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$nombreCookie])) {
            // Obtener el valor de la cookie
            $nombreCookieValue = $_COOKIE[$nombreCookie];
        }

        $correoCookie = "proyecto_donaciones_colombia_correo";
        $correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$correoCookie])) {
            // Obtener el valor de la cookie
            $correoCookieValue = $_COOKIE[$correoCookie];
        }

        $urlRedirect = $aproved;
        if (strpos($slugCookieValue, 'delfin') !== false) {
            $urlRedirect = $delfin_de_rio;
        } elseif (strpos($slugCookieValue, 'elefantes') !== false) {
            $urlRedirect = $elefante;
        } elseif (strpos($slugCookieValue, 'jaguar') !== false) {
            $urlRedirect = $jaguar;
        } elseif (strpos($slugCookieValue, 'oso-de-anteojos') !== false) {
            $urlRedirect = $oso;
        } elseif (strpos($slugCookieValue, 'oso-panda') !== false) {
            $urlRedirect = $oso_panda;
        } elseif (strpos($slugCookieValue, 'tortuga') !== false) {
            $urlRedirect = $tortuga;
        } elseif (strpos($slugCookieValue, 'apoyanos') !== false) {
            $urlRedirect = $apoya_la_causa_wwf;
        } elseif (strpos($slugCookieValue, 'fondo-incendios') !== false) {
            $urlRedirect = $fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $timezone = new DateTimeZone('America/Bogota');
        $date = new DateTime('now', $timezone);
        $date_formatted = $date->format('Y-m-d H:i:s');

        $day = $date->format('d');
        $month = $date->format('m');
        $year = $date->format('Y');

        $total_date = $day . '-' . $month . '-' . $year;

        $inserted_id = $wpdb->insert_id;

        $donation_data = [$monthly_payu_bool, $amount, $inserted_id, $total_date, $tipoIdentificacionPayu . ': ' . $identification];

        enviar_correo($emailAddress, $slugCookieValue, $fullName, "", "", "", false, "payu", $donation_data);

        if ($is_gift_payu_bool == true) {
            enviar_correo($gift_email_payu, $slugCookieValue, $gift_name_payu, $gift_name_payu, $gift_message_payu, $gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$urlRedirect."');</script>";
        //wp_redirect($urlRedirect);
    } else {
        echo "<script>window.location.assign('".$error."');</script>";
        //wp_redirect($error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $timezone = new DateTimeZone('America/Bogota');
    $date = new DateTime('now', $timezone);
    $date_formatted = $date->format('Y-m-d H:i:s');

    $monthly = "NO";
    if($monthly_payu_bool){
        $monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($slugCookieValue, 'delfin') !== false) {
        $description = "DELFIN DE RIO";
    } elseif (strpos($slugCookieValue, 'elefantes') !== false) {
        $description = "ELEFANTES";
    } elseif (strpos($slugCookieValue, 'jaguar') !== false) {
        $description = "JAGUAR";
    } elseif (strpos($slugCookieValue, 'oso-de-anteojos') !== false) {
        $description = "OSO DE ANTEOJOS";
    } elseif (strpos($slugCookieValue, 'oso-panda') !== false) {
        $description = "OSO PANDA";
    } elseif (strpos($slugCookieValue, 'tortuga') !== false) {
        $description = "TORTUGA MARINA";
    } elseif (strpos($slugCookieValue, 'apoyanos') !== false) {
        $description = "DONACION GENERAL";
    } elseif (strpos($slugCookieValue, 'fondo-incendios') !== false) {
        $description = "FONDO DE INCENDIOS";
    } else {
        $description = "DONACION GENERAL";
    }

    $format = array('%s');

    $table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $table_logs,
        array(
            'name' => $fullName,
            'payment_method' => "PAYU",
            'id_type' => $tipoIdentificacionPayu,
            'id_number' => $identification,
            'phone_number' => $contactPhone,
            'email' => $emailAddress,
            'amount' => $amount,
            'payment_description' => $description,
            'date_in' => $date_formatted,
            'monthly' => $monthly,
            'final_result' => $final_status
        ),
        $format
    );

    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['payu_pse'])) {
    $person_type_pse = sanitize_text_field($_POST['person_type_pse']);
    $nombreBanco_pse = sanitize_text_field($_POST['nombreBanco_pse']);
    $amount = sanitize_text_field($_POST['amount_pse']);
    //$reference = 'abcde475674675';
    $reference = sanitize_text_field($_POST['referenceCode_pse']);
    $description = sanitize_text_field($_POST['description_pse']);
    $responseUrl = sanitize_text_field($_POST['responseUrl_pse']);
    $fullName = sanitize_text_field($_POST['payerFullName_pse']) . ' ' . sanitize_text_field($_POST['payerLastName_pse']);

    $tipoIdentificacionPayu = sanitize_text_field($_POST['tipoIdentificacionPayu_pse']);

    $emailAddress = sanitize_text_field($_POST['buyerEmail_pse']);
    $contactPhone = sanitize_text_field($_POST['payerPhone_pse']);
    $identification = sanitize_text_field($_POST['numeroIdentificacionPayu_pse']);

    $gift_email_payu = sanitize_text_field($_POST['gift_email_payu_pse']);
    $gift_name_payu = sanitize_text_field($_POST['gift_name_payu_pse']);
    $gift_message_payu = sanitize_text_field($_POST['gift_message_payu_pse']);
    $is_gift_payu_string = sanitize_text_field($_POST['is_gift_payu_pse']);

    $monthly_payu_string = sanitize_text_field($_POST['monthly_payu_pse']);

    $monthly_payu_bool = false;
    if ($monthly_payu_string == "1") {
        $monthly_payu_bool = true;
    } else {
        $monthly_payu_bool = false;
    }

    $is_gift_payu_int = intval($is_gift_payu_string);

    $ipAddress = $_SERVER['REMOTE_ADDR'];

    //--------------------------------------------------------------------------
    $slugCookie = "proyecto_donaciones_colombia_slug";
    $slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$slugCookie])) {
        // Obtener el valor de la cookie
        $slugCookieValue = $_COOKIE[$slugCookie];
    }
    //----------------------------------------------------------------------------------------------

    $preSignature = $ApiKey . '~' . $merchantId . '~' . $reference . '~' . $amount . '~' . 'COP';

    $signature = md5($preSignature);

    //----------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $timezone = new DateTimeZone('America/Bogota');
    $date = new DateTime('now', $timezone);
    $date_formatted = $date->format('Y-m-d H:i:s');
    //----------------------------------------------
    $format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d');
    //----------------------------------------------
    $table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $table_logs,
        array(
            'name' => $fullName,
            'payment_method' => "PSE",
            'id_type' => $tipoIdentificacionPayu,
            'id_number' => $identification,
            'phone_number' => $contactPhone,
            'email' => $emailAddress,
            'amount' => $amount,
            'payment_description' => $slugCookieValue,
            'date_in' => $date_formatted,
            'monthly' => "NO",
            'final_result' => "No Aprobada",
            'signature_payu' => $reference,
            'is_gift' => $is_gift_payu_int
        ),
        $format
    );
    //----------------------------------------------
    $format = array('%s');
    //----------------------------------------------
    $table_logs = $wpdb->prefix . 'gift_table';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $table_logs,
        array(
            'signature_payu' => $reference,
            'gift_email' => $gift_email_payu,
            'gift_name' => $gift_name_payu,
            'gift_message' => $gift_message_payu
        ),
        $format
    );
    //----------------------------------------------
    $data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $ApiKey,
            'apiLogin' => $ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $accountId,
                'referenceCode' => $reference,
                'description' => $reference,
                'language' => 'es',
                'signature' => $signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $fullName,
                'emailAddress' => $emailAddress,
                'contactPhone' => $contactPhone,
                'dniType' => $tipoIdentificacionPayu,
                'dniNumber' => $identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $responseUrl,
                'PSE_REFERENCE1' => $ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $nombreBanco_pse,
                'USER_TYPE' => $person_type_pse,
                'PSE_REFERENCE2' => $tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $deviceSessionId,
            'ipAddress' => $ipAddress,
            'cookie' => $cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $setTest
    );

    // Convertir datos a formato JSON
    $json_data = json_encode($data);

    // Configuración de la solicitud cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $response = curl_exec($ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($ch);
    }

    // Cerrar la conexión cURL
    curl_close($ch);

    // Decodificar la respuesta XML
    $response_data_xml = simplexml_load_string($response);

    // Convertir SimpleXMLElement a array
    $response_data_array = json_decode(json_encode($response_data_xml), true);

    $json_result = json_encode($response_data_array);

    $array_result = json_decode($json_result, true);

    if (isset($array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['guardar'])) {
    // Obtener los valores del formulario
    $monthly_bank = sanitize_text_field($_POST['monthly_bank']);
    $monto_form = sanitize_text_field($_POST['monto_form']);
    $name = sanitize_text_field($_POST['nombre']) . ' ' . sanitize_text_field($_POST['apellido']);
    $account_type = sanitize_text_field($_POST['tipoCuenta']);
    $account_number = sanitize_text_field($_POST['numeroCuenta']);
    $bank_name = sanitize_text_field($_POST['nombreBanco']);
    $id_type = sanitize_text_field($_POST['tipoIdentificacion']);
    $id_number = sanitize_text_field($_POST['numeroIdentificacion']);
    $phone_number = sanitize_text_field($_POST['numeroTelefono']);
    $email = sanitize_text_field($_POST['correoElectronico']);
    $description = sanitize_text_field($_POST['description_bank']);

    $gift_email_bank = sanitize_text_field($_POST['gift_email_bank']);
    $gift_name_bank = sanitize_text_field($_POST['gift_name_bank']);
    $gift_message_bank = sanitize_text_field($_POST['gift_message_bank']);
    $is_gift_bank_string = sanitize_text_field($_POST['is_gift_bank']);

    $is_gift_bank_bool = false;
    if ($is_gift_bank_string == "1") {
        $is_gift_bank_bool = true;
    } else {
        $is_gift_bank_bool = false;
    }

    $monthly = "NO";
    if ($monthly_bank == "1") {
        $monthly = "SI";
    } else {
        $monthly = "NO";
    }

    if (strpos($description, 'delfin') !== false) {
        $description = "DELFIN DE RIO";
    } elseif (strpos($description, 'elefantes') !== false) {
        $description = "ELEFANTES";
    } elseif (strpos($description, 'jaguar') !== false) {
        $description = "JAGUAR";
    } elseif (strpos($description, 'oso-de-anteojos') !== false) {
        $description = "OSO DE ANTEOJOS";
    } elseif (strpos($description, 'oso-panda') !== false) {
        $description = "OSO PANDA";
    } elseif (strpos($description, 'tortuga') !== false) {
        $description = "TORTUGA MARINA";
    } elseif (strpos($description, 'apoyanos') !== false) {
        $description = "DONACION GENERAL";
    } elseif (strpos($description, 'fondo-incendios') !== false) {
        $description = "FONDO DE INCENDIOS";
    } else {
        $description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $timezone = new DateTimeZone('America/Bogota');
    $date = new DateTime('now', $timezone);
    $date_formatted = $date->format('Y-m-d H:i:s');

    $day = $date->format('d');
    $month = $date->format('m');
    $year = $date->format('Y');

    $total_date = $day . '-' . $month . '-' . $year;

    $format = array('%s');

    $table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $table_name_bank_accounts,
        array(
            'name' => $name,
            'account_type' => $account_type,
            'account_number' => $account_number,
            'bank_name' => $bank_name,
            'id_type' => $id_type,
            'id_number' => $id_number,
            'phone_number' => $phone_number,
            'email' => $email,
            'amount' => $monto_form,
            'date_in' => $date_formatted,
            'payment_description' => $description,
            'monthly' => $monthly,
        ),
        $format
    );

    $inserted_id = $wpdb->insert_id;

    $donation_data = [$monthly, $monto_form, $inserted_id, $total_date];

    $nombreCookie = "proyecto_donaciones_colombia_nombre";
    $nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$nombreCookie])) {
        // Obtener el valor de la cookie
        $nombreCookieValue = $_COOKIE[$nombreCookie];
    }

    $correoCookie = "proyecto_donaciones_colombia_correo";
    $correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$correoCookie])) {
        // Obtener el valor de la cookie
        $correoCookieValue = $_COOKIE[$correoCookie];
    }

    $slugCookie = "proyecto_donaciones_colombia_slug";
    $slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$slugCookie])) {
        // Obtener el valor de la cookie
        $slugCookieValue = $_COOKIE[$slugCookie];
    }

    //----------------------------------------------------------------------------
    $aproved = "";
    $error = "";
    $pending = "";
    $expired = "";
    $delfin_de_rio = "";
    $elefante = "";
    $jaguar = "";
    $oso = "";
    $oso_panda = "";
    $tortuga = "";
    $apoya_la_causa_wwf = "";
    $fondo_incendios = "";

    $table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $sql = "SELECT * FROM $table_urls WHERE id = 1";

    // Ejecutar la consulta
    $results = $wpdb->get_results($sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($results as $result) {
        $aproved = $result->aproved;
        $error = $result->error;
        $pending = $result->pending;
        $expired = $result->expired;
        $delfin_de_rio = $result->delfin_de_rio;
        $elefante = $result->elefante;
        $jaguar = $result->jaguar;
        $oso = $result->oso;
        $oso_panda = $result->oso_panda;
        $tortuga = $result->tortuga;
        $apoya_la_causa_wwf = $result->apoya_la_causa_wwf;
        $fondo_incendios = $result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $urlRedirect = $aproved;
    if (strpos($slugCookieValue, 'delfin') !== false) {
        $urlRedirect = $delfin_de_rio;
    } elseif (strpos($slugCookieValue, 'elefantes') !== false) {
        $urlRedirect = $elefante;
    } elseif (strpos($slugCookieValue, 'jaguar') !== false) {
        $urlRedirect = $jaguar;
    } elseif (strpos($slugCookieValue, 'oso-de-anteojos') !== false) {
        $urlRedirect = $oso;
    } elseif (strpos($slugCookieValue, 'oso-panda') !== false) {
        $urlRedirect = $oso_panda;
    } elseif (strpos($slugCookieValue, 'tortuga') !== false) {
        $urlRedirect = $tortuga;
    } elseif (strpos($slugCookieValue, 'apoyanos') !== false) {
        $urlRedirect = $apoya_la_causa_wwf;
    } elseif (strpos($slugCookieValue, 'fondo-incendios') !== false) {
        $urlRedirect = $fondo_incendios;
    }

    enviar_correo($email, $slugCookieValue, $name, "", "", "", false, "bank_account", $donation_data);

    if ($is_gift_bank_bool == true) {
        enviar_correo($gift_email_bank, $slugCookieValue, $gift_name_bank, $gift_name_bank, $gift_message_bank, $gift_email_bank, true, "", false);
    }

    echo "<script>window.location.assign('".$urlRedirect."');</script>";

    //wp_redirect($urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html/html.php');

include(plugin_dir_path(__FILE__) . '../css/css.php');
