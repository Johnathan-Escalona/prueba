<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option/functions_option_4.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState'])) {
    $option_4_aproved = "";
    $option_4_error = "";
    $option_4_pending = "";
    $option_4_expired = "";
    $option_4_delfin_de_rio = "";
    $option_4_elefante = "";
    $option_4_jaguar = "";
    $option_4_oso = "";
    $option_4_oso_panda = "";
    $option_4_tortuga = "";
    $option_4_apoya_la_causa_wwf = "";
    $option_4_fondo_incendios = "";

    $option_4_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_4_sql = "SELECT * FROM $option_4_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_4_results = $wpdb->get_results($option_4_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_4_results as $option_4_result) {
        $option_4_aproved = $option_4_result->aproved;
        $option_4_error = $option_4_result->error;
        $option_4_pending = $option_4_result->pending;
        $option_4_expired = $roption_4_esult->expired;
        $option_4_delfin_de_rio = $option_4_result->delfin_de_rio;
        $option_4_elefante = $option_4_result->elefante;
        $option_4_jaguar = $option_4_result->jaguar;
        $option_4_oso = $option_4_result->oso;
        $option_4_oso_panda = $option_4_result->oso_panda;
        $option_4_tortuga = $option_4_result->tortuga;
        $option_4_apoya_la_causa_wwf = $option_4_result->apoya_la_causa_wwf;
        $option_4_fondo_incendios = $option_4_result->fondo_incendios;
    }

    //--------------------------------------------------------------------------
    $signature = sanitize_text_field($_GET['description']);
    $desired_signature = $signature;
    //--------------------------------------------------------------------------
    $table_name_orders_data = $wpdb->prefix . 'orders_data';

    $query = $wpdb->prepare("SELECT * FROM $table_name_orders_data WHERE signature_payu = %s", $desired_signature);
    $row = null;
    $row = $wpdb->get_row($query);
    //--------------------------------------------------------------------------
    if (empty($row)){
        $table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';

        $query = $wpdb->prepare("SELECT * FROM $table_name_bank_accounts_logs WHERE signature_payu = %s", $desired_signature);

        $row = $wpdb->get_row($query);

        $option_4_nombreCookieValue = '';
        $option_4_correoCookieValue = '';
        $option_4_slugCookieValue = '';
        $option_4_monthly_payu_bool = false;
        $option_4_amount = '';
        $option_4_tipoIdentificacionPayu = '';
        $option_4_identification = '';
        $option_4_phone_CookieValue = '';
        $option_4_is_gift_payu_bool = false;
        
        if (null !== $row){
            $option_4_nombreCookieValue = $row->name;
            $option_4_correoCookieValue = $row->email;
            $option_4_slugCookieValue = $row->payment_description;
            $option_4_amount = $row->amount;
            $option_4_tipoIdentificacionPayu = $row->id_type;
            $option_4_identification = $row->id_number;
            $option_4_phone_CookieValue = $row->phone_number;

            if ($row->is_gift == 1) {
                $option_4_is_gift_payu_bool = true;
            } else {
                $option_4_is_gift_payu_bool = false;
            }
        }
        //--------------------------------------------------------------------------
        $option_4_gift_email_payu = '';
        $option_4_gift_name_payu = '';
        $option_4_gift_message_payu = '';
        if($option_4_is_gift_payu_bool){
            $table_name_gift_table = $wpdb->prefix . 'gift_table';

            $query = $wpdb->prepare("SELECT * FROM $table_name_gift_table WHERE signature_payu = %s", $desired_signature);

            $row = $wpdb->get_row($query);

            if (null !== $row){
                $option_4_gift_email_payu = $row->gift_email;
                $option_4_gift_name_payu = $row->gift_name;
                $option_4_gift_message_payu = $row->gift_message;
            }
        }
        //--------------------------------------------------------------------------
        $option_4_donation_data = array();
        //--------------------------------------------------------------------------
        $option_4_stateValue = sanitize_text_field($_GET['transactionState']);
        //--------------------------------------------------------------------------
        if ($option_4_stateValue == "4" || $option_4_stateValue == 4) {
            $option_4_urlRedirect = $option_4_aproved;
            if (strpos($option_4_slugCookieValue, 'delfin') !== false) {
                $option_4_urlRedirect = $option_4_delfin_de_rio;
            } elseif (strpos($option_4_slugCookieValue, 'elefantes') !== false) {
                $option_4_urlRedirect = $option_4_elefante;
            } elseif (strpos($option_4_slugCookieValue, 'jaguar') !== false) {
                $option_4_urlRedirect = $option_4_jaguar;
            } elseif (strpos($option_4_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_4_urlRedirect = $option_4_oso;
            } elseif (strpos($option_4_slugCookieValue, 'oso-panda') !== false) {
                $option_4_urlRedirect = $option_4_oso_panda;
            } elseif (strpos($option_4_slugCookieValue, 'tortuga') !== false) {
                $option_4_urlRedirect = $option_4_tortuga;
            } elseif (strpos($option_4_slugCookieValue, 'apoyanos') !== false) {
                $option_4_urlRedirect = $option_4_apoya_la_causa_wwf;
            } elseif (strpos($option_4_slugCookieValue, 'fondo-incendios') !== false) {
                $option_4_urlRedirect = $option_4_fondo_incendios;
            }

            // Obtener la fecha actual en la zona horaria -5
            $option_4_timezone = new DateTimeZone('America/Bogota');
            $option_4_date = new DateTime('now', $option_4_timezone);
            $option_4_date_formatted = $option_4_date->format('Y-m-d H:i:s');

            $option_4_day = $option_4_date->format('d');
            $option_4_month = $option_4_date->format('m');
            $option_4_year = $option_4_date->format('Y');

            $option_4_total_date = $option_4_day . '-' . $option_4_month . '-' . $option_4_year;

            $inserted_id = "";

            $option_4_donation_data = [
                $option_4_monthly_payu_bool,
                $option_4_amount,
                $inserted_id,
                $option_4_total_date,
                $option_4_tipoIdentificacionPayu . ': ' . $option_4_identification
            ];

            option_4_enviar_correo($option_4_correoCookieValue, $option_4_slugCookieValue, $option_4_nombreCookieValue,         "",            "",          "",   false,        "payu", $option_4_donation_data);

            if ($option_4_is_gift_payu_bool == true) {
                option_4_enviar_correo($option_4_gift_email_payu, $option_4_slugCookieValue, $option_4_gift_name_payu, $option_4_gift_name_payu, $option_4_gift_message_payu, $option_4_gift_email_payu, true, "", false);
            }

            echo "<script>window.location.assign('".$option_4_urlRedirect."');</script>";
            //wp_redirect($option_4_urlRedirect);
        } else {
            echo "<script>window.location.assign('".$option_4_error."');</script>";
            //wp_redirect($option_4_error);
        }

        //----------------------------------------------------------------------------------------
        // Obtener la fecha actual en la zona horaria -5
        $option_4_timezone = new DateTimeZone('America/Bogota');
        $option_4_date = new DateTime('now', $option_4_timezone);
        $option_4_date_formatted = $option_4_date->format('Y-m-d H:i:s');

        $final_status = "No Aprobada";
        if ($option_4_stateValue == "4" || $option_4_stateValue == 4){
            $final_status = "Aprobada";
        }

        $option_4_description = "DONACION GENERAL";
        if (strpos($option_4_slugCookieValue, 'delfin') !== false) {
            $option_4_description = "DELFIN DE RIO";
        } elseif (strpos($option_4_slugCookieValue, 'elefantes') !== false) {
            $option_4_description = "ELEFANTES";
        } elseif (strpos($option_4_slugCookieValue, 'jaguar') !== false) {
            $option_4_description = "JAGUAR";
        } elseif (strpos($option_4_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_4_description = "OSO DE ANTEOJOS";
        } elseif (strpos($option_4_slugCookieValue, 'oso-panda') !== false) {
            $option_4_description = "OSO PANDA";
        } elseif (strpos($option_4_slugCookieValue, 'tortuga') !== false) {
            $option_4_description = "TORTUGA MARINA";
        } elseif (strpos($option_4_slugCookieValue, 'apoyanos') !== false) {
            $option_4_description = "DONACION GENERAL";
        } elseif (strpos($option_4_slugCookieValue, 'fondo-incendios') !== false) {
            $option_4_description = "FONDO DE INCENDIOS";
        } else {
            $option_4_description = "DONACION GENERAL";
        }
        //----------------------------------------------------------------------------------------
        $signature_payu_specific = $signature;

        $new_data = array(
            'payment_description' => $option_4_description,
            'final_result' => $final_status
        );

        $where = array(
            'signature_payu' => $signature_payu_specific
        );

        $data_format = array('%s');
        $where_format = array('%s');

        $updated = $wpdb->update($table_name_bank_accounts_logs, $new_data, $where, $data_format, $where_format);

        //----------------------------------------------------------------------------------------
        exit;
    }
}
//--------------------------------------------------------------------------------------------
if (isset($_REQUEST['transactionState'])) {
    $option_4_aproved = "";
    $option_4_error = "";
    $option_4_pending = "";
    $option_4_expired = "";
    $option_4_delfin_de_rio = "";
    $option_4_elefante = "";
    $option_4_jaguar = "";
    $option_4_oso = "";
    $option_4_oso_panda = "";
    $option_4_tortuga = "";
    $option_4_apoya_la_causa_wwf = "";
    $option_4_fondo_incendios = "";

    $option_4_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_4_sql = "SELECT * FROM $option_4_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_4_results = $wpdb->get_results($option_4_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_4_results as $option_4_result) {
        $option_4_aproved = $option_4_result->aproved;
        $option_4_error = $option_4_result->error;
        $option_4_pending = $option_4_result->pending;
        $option_4_expired = $option_4_result->expired;
        $option_4_delfin_de_rio = $option_4_result->delfin_de_rio;
        $option_4_elefante = $option_4_result->elefante;
        $option_4_jaguar = $option_4_result->jaguar;
        $option_4_oso = $option_4_result->oso;
        $option_4_oso_panda = $option_4_result->oso_panda;
        $option_4_tortuga = $option_4_result->tortuga;
        $option_4_apoya_la_causa_wwf = $option_4_result->apoya_la_causa_wwf;
        $option_4_fondo_incendios = $option_4_result->fondo_incendios;
    }

    if ($_REQUEST['transactionState']) {

        if ($_REQUEST['transactionState'] == "4") {

            $option_4_nombreCookie = "proyecto_donaciones_colombia_nombre";
            $option_4_nombreCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_4_nombreCookie])) {
                // Obtener el valor de la cookie
                $option_4_nombreCookieValue = $_COOKIE[$option_4_nombreCookie];
            }

            $option_4_correoCookie = "proyecto_donaciones_colombia_correo";
            $option_4_correoCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_4_correoCookie])) {
                // Obtener el valor de la cookie
                $option_4_correoCookieValue = $_COOKIE[$option_4_correoCookie];
            }

            $option_4_slugCookie = "proyecto_donaciones_colombia_slug";
            $option_4_slugCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_4_slugCookie])) {
                // Obtener el valor de la cookie
                $option_4_slugCookieValue = $_COOKIE[$option_4_slugCookie];
            }

            $option_4_urlRedirect = $option_4_aproved;
            if (strpos($option_4_slugCookieValue, 'delfin') !== false) {
                $option_4_urlRedirect = $option_4_delfin_de_rio;
            } elseif (strpos($option_4_slugCookieValue, 'elefantes') !== false) {
                $option_4_urlRedirect = $option_4_elefante;
            } elseif (strpos($option_4_slugCookieValue, 'jaguar') !== false) {
                $option_4_urlRedirect = $option_4_jaguar;
            } elseif (strpos($option_4_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_4_urlRedirect = $option_4_oso;
            } elseif (strpos($option_4_slugCookieValue, 'oso-panda') !== false) {
                $option_4_urlRedirect = $option_4_oso_panda;
            } elseif (strpos($option_4_slugCookieValue, 'tortuga') !== false) {
                $option_4_urlRedirect = $option_4_tortuga;
            } elseif (strpos($option_4_slugCookieValue, 'apoyanos') !== false) {
                $option_4_urlRedirect = $option_4_apoya_la_causa_wwf;
            } elseif (strpos($option_4_slugCookieValue, 'fondo-incendios') !== false) {
                $option_4_urlRedirect = $option_4_fondo_incendios;
            }

            option_4_enviar_correo($option_4_correoCookieValue, $option_4_slugCookieValue, $option_4_nombreCookieValue, false, false);
            echo $option_4_urlRedirect;
            wp_redirect($option_4_urlRedirect);
        } else if ($_REQUEST['transactionState'] == "6" || $_REQUEST['transactionState'] == "104") {
            wp_redirect($option_4_error);
        }
        if ($_REQUEST['transactionState'] == "5") {
            wp_redirect($option_4_expired);
        }
        if ($_REQUEST['transactionState'] == "7") {
            wp_redirect($option_4_pending);
        }

        exit;
    }
}

// Nombre de la tabla
$option_4_table_name_values = $wpdb->prefix . 'values';

// Consulta SQL para obtener los valores de las filas 1, 2 y 3
$option_4_sql = "SELECT id, value FROM $option_4_table_name_values WHERE id IN (1, 2, 3, 4, 5, 6)";

// Ejecutar la consulta
$option_4_results = $wpdb->get_results($option_4_sql);

// Crear un array asociativo para almacenar los resultados
$option_4_values = array();

// Recorrer los resultados y asignar los valores al array
foreach ($option_4_results as $option_4_result) {
    $option_4_values[$option_4_result->id] = $option_4_result->value;
}

// Codificar el array en formato JSON para usarlo en JavaScript
$option_4_values_json = json_encode($option_4_values);

$option_4_timezone = new DateTimeZone('America/Bogota');
$option_4_date = new DateTime('now', $option_4_timezone);
$option_4_reference = $option_4_date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$option_4_cookie = "";
// Nombre de la cookie
$option_4_cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$option_4_cookieName])) {
    // Obtiene el valor de la cookie
    $option_4_cookie = $_COOKIE[$option_4_cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $option_4_cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($option_4_cookieName, '', time() - 3600, '/'); // Borra la cookie
        $option_4_newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($option_4_cookieName, $option_4_newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $option_4_sessionId = session_id();
    setcookie($option_4_cookieName, $option_4_sessionId, time() + 3600, '/');
    $option_4_cookie = $_COOKIE[$option_4_cookieName];
}

$option_4_deviceSessionId = md5($option_4_cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$option_4_table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$option_4_sql = "SELECT * FROM $option_4_table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$option_4_results = $wpdb->get_results($option_4_sql);

// Crear un array asociativo para almacenar los resultados
$option_4_merchantId = "";
$option_4_accountId = "";
$option_4_ApiKey = "";
$option_4_ApiLogin = "";
$option_4_testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($option_4_results as $option_4_result) {
    $option_4_merchantId = $option_4_result->merchantId;
    $option_4_accountId = $option_4_result->accountId;
    $option_4_ApiKey = $option_4_result->apiKey;
    $option_4_ApiLogin = $option_4_result->apiLogin;
    $option_4_testMode = $option_4_result->testMode ? "1" : "0";
}

$option_4_setTest = "";
$option_4_url = "";
$option_4_tokenURL = "";
// URL de la API
if ($option_4_testMode == "1") {
    $option_4_setTest = true;
    $option_4_url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $option_4_tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $option_4_setTest = false;
    $option_4_url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $option_4_tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$option_4_data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $option_4_ApiLogin,
        'apiKey' => $option_4_ApiKey
    ),
    'test' => $option_4_setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$option_4_json_data_bank_list = json_encode($option_4_data_bank_list);

// Configuración de la solicitud cURL
$option_4_ch_bank_list = curl_init($option_4_url);
curl_setopt($option_4_ch_bank_list, CURLOPT_POST, 1);
curl_setopt($option_4_ch_bank_list, CURLOPT_POSTFIELDS, $option_4_json_data_bank_list);
curl_setopt($option_4_ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($option_4_ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$option_4_response_bank_list = curl_exec($option_4_ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($option_4_ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($option_4_ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($option_4_ch_bank_list);

// Decodificar la respuesta XML
$option_4_response_data_bank_list_xml = simplexml_load_string($option_4_response_bank_list);

// Convertir SimpleXMLElement a array
$option_4_response_data_bank_list_array = json_decode(json_encode($option_4_response_data_bank_list_xml), true);

$option_4_json_result_bank_list = json_encode($option_4_response_data_bank_list_array);

$option_4_array_result_bank_list = json_decode($option_4_json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($option_4_array_result_bank_list['banks']['bank']) && is_array($option_4_array_result_bank_list['banks']['bank'])) {
    foreach ($option_4_array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['option_4_payu'])) {
    $option_4_amount = sanitize_text_field($_POST['option_4_amount']);
    //$reference = 'abcde475674675';
    $option_4_reference = sanitize_text_field($_POST['option_4_referenceCode']);
    $option_4_description = sanitize_text_field($_POST['option_4_description']);
    $option_4_notifyUrl = sanitize_text_field($_POST['option_4_responseUrl']);
    $option_4_fullName = sanitize_text_field($_POST['option_4_payerFullName']) . ' ' . sanitize_text_field($_POST['option_4_payerLastName']);

    $option_4_tipoIdentificacionPayu = sanitize_text_field($_POST['option_4_tipoIdentificacionPayu']);

    $option_4_emailAddress = sanitize_text_field($_POST['option_4_buyerEmail']);
    $option_4_contactPhone = sanitize_text_field($_POST['option_4_payerPhone']);
    $option_4_creditCardNumber = sanitize_text_field($_POST['option_4_card_number']);
    $option_4_creditCardSecurityCode = sanitize_text_field($_POST['option_4_cvv_card']);
    $option_4_creditCardExpirationDate = sanitize_text_field($_POST['option_4_expiration_year']) . '/' . sanitize_text_field($_POST['option_4_expiration_month']);
    $option_4_creditCardName = $option_4_fullName;
    $option_4_paymentMethod = sanitize_text_field($_POST['option_4_payment_method_1']);
    $option_4_identification = sanitize_text_field($_POST['option_4_numeroIdentificacionPayu']);

    $option_4_gift_email_payu = sanitize_text_field($_POST['option_4_gift_email_payu']);
    $option_4_gift_name_payu = sanitize_text_field($_POST['option_4_gift_name_payu']);
    $option_4_gift_message_payu = sanitize_text_field($_POST['option_4_gift_message_payu']);
    $option_4_is_gift_payu_string = sanitize_text_field($_POST['option_4_is_gift_payu']);

    $option_4_monthly_payu_string = sanitize_text_field($_POST['option_4_monthly_payu']);

    $option_4_monthly_payu_bool = false;
    if ($option_4_monthly_payu_string == "1") {
        $option_4_monthly_payu_bool = true;
    } else {
        $option_4_monthly_payu_bool = false;
    }

    $option_4_is_gift_payu_bool = false;
    if ($option_4_is_gift_payu_string == "1") {
        $option_4_is_gift_payu_bool = true;
    } else {
        $option_4_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_4_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($option_4_monthly_payu_bool == true) {
        $option_4_tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $option_4_ApiLogin,
                "apiKey" => $option_4_ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $option_4_identification,
                "name" => $option_4_fullName,
                "identificationNumber" => $option_4_identification,
                "paymentMethod" => $option_4_paymentMethod,
                "number" => $option_4_creditCardNumber,
                "expirationDate" => $option_4_creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $option_4_json_data = json_encode($option_4_tokenData);

        // Configuración de la solicitud cURL
        $option_4_ch = curl_init($option_4_tokenURL);
        curl_setopt($option_4_ch, CURLOPT_POST, 1);
        curl_setopt($option_4_ch, CURLOPT_POSTFIELDS, $option_4_json_data);
        curl_setopt($option_4_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($option_4_ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $option_4_response = curl_exec($option_4_ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($option_4_ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($option_4_ch);
        }

        // Cerrar la conexión cURL
        curl_close($option_4_ch);

        // Decodificar la respuesta XML
        $option_4_response_data_xml = simplexml_load_string($option_4_response);

        // Convertir SimpleXMLElement a array
        $option_4_response_data_array = json_decode(json_encode($option_4_response_data_xml), true);

        $option_4_json_result = json_encode($option_4_response_data_array);

        $option_4_array_result = json_decode($option_4_json_result, true);

        $option_4_creditCardToken = "";
        if ($option_4_array_result['creditCardToken']['creditCardTokenId']) {
            $option_4_creditCardToken = $option_4_array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($option_4_creditCardToken != "") {

            $option_4_format = array('%s');

            $option_4_table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $option_4_table_name_token,
                array(
                    'document' => $option_4_identification,
                    'token_card' => $option_4_creditCardToken,
                    'amount_to_discount' => $option_4_amount,
                    'discount_day' => date('d'),
                    'payer_name' => $option_4_fullName,
                    'phone_number' => $option_4_contactPhone,
                    'payer_email' => $option_4_emailAddress,
                    'cvv_card' => $option_4_creditCardSecurityCode,
                    'paymentMethod' => $option_4_paymentMethod
                ),
                $option_4_format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $option_4_preSignature = $option_4_ApiKey . '~' . $option_4_merchantId . '~' . $option_4_reference . '~' . $option_4_amount . '~' . 'COP';

    $option_4_signature = option_4_sha256($option_4_preSignature);

    //----------------------------------------------

    $option_4_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_4_ApiKey,
            'apiLogin' => $option_4_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_4_accountId,
                'referenceCode' => $option_4_reference,
                'description' => $option_4_description,
                'language' => 'es',
                'signature' => $option_4_signature,
                'notifyUrl' => $option_4_notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $option_4_amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_4_fullName,
                'emailAddress' => $option_4_emailAddress,
                'contactPhone' => $option_4_contactPhone
            ),
            'creditCard' => array(
                'number' => $option_4_creditCardNumber,
                'securityCode' => $option_4_creditCardSecurityCode,
                'expirationDate' => $option_4_creditCardExpirationDate,
                'name' => $option_4_creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $option_4_paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_4_deviceSessionId,
            'ipAddress' => $option_4_ipAddress,
            'cookie' => $option_4_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_4_setTest
    );

    // Convertir datos a formato JSON
    $option_4_json_data = json_encode($option_4_data);

    // Configuración de la solicitud cURL
    $option_4_ch = curl_init($option_4_url);
    curl_setopt($option_4_ch, CURLOPT_POST, 1);
    curl_setopt($option_4_ch, CURLOPT_POSTFIELDS, $option_4_json_data);
    curl_setopt($option_4_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_4_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_4_response = curl_exec($option_4_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_4_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_4_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_4_ch);

    // Decodificar la respuesta XML
    $option_4_response_data_xml = simplexml_load_string($option_4_response);

    // Convertir SimpleXMLElement a array
    $option_4_response_data_array = json_decode(json_encode($option_4_response_data_xml), true);

    $option_4_json_result = json_encode($option_4_response_data_array);

    $option_4_array_result = json_decode($option_4_json_result, true);

    $option_4_stateValue = $option_4_array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $option_4_aproved = "";
    $option_4_error = "";
    $option_4_pending = "";
    $option_4_expired = "";
    $option_4_delfin_de_rio = "";
    $option_4_elefante = "";
    $option_4_jaguar = "";
    $option_4_oso = "";
    $option_4_oso_panda = "";
    $option_4_tortuga = "";
    $option_4_apoya_la_causa_wwf = "";
    $option_4_fondo_incendios = "";

    $option_4_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_4_sql = "SELECT * FROM $option_4_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_4_results = $wpdb->get_results($option_4_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_4_results as $option_4_result) {
        $option_4_aproved = $option_4_result->aproved;
        $option_4_error = $option_4_result->error;
        $option_4_pending = $option_4_result->pending;
        $option_4_expired = $roption_4_esult->expired;
        $option_4_delfin_de_rio = $option_4_result->delfin_de_rio;
        $option_4_elefante = $option_4_result->elefante;
        $option_4_jaguar = $option_4_result->jaguar;
        $option_4_oso = $option_4_result->oso;
        $option_4_oso_panda = $option_4_result->oso_panda;
        $option_4_tortuga = $option_4_result->tortuga;
        $option_4_apoya_la_causa_wwf = $option_4_result->apoya_la_causa_wwf;
        $option_4_fondo_incendios = $option_4_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_4_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_4_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_4_slugCookie])) {
        // Obtener el valor de la cookie
        $option_4_slugCookieValue = $_COOKIE[$option_4_slugCookie];
    }

    if ($option_4_stateValue == "APPROVED") {

        $option_4_nombreCookie = "proyecto_donaciones_colombia_nombre";
        $option_4_nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_4_nombreCookie])) {
            // Obtener el valor de la cookie
            $option_4_nombreCookieValue = $_COOKIE[$option_4_nombreCookie];
        }

        $option_4_correoCookie = "proyecto_donaciones_colombia_correo";
        $option_4_correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_4_correoCookie])) {
            // Obtener el valor de la cookie
            $option_4_correoCookieValue = $_COOKIE[$option_4_correoCookie];
        }

        $option_4_urlRedirect = $option_4_aproved;
        if (strpos($option_4_slugCookieValue, 'delfin') !== false) {
            $option_4_urlRedirect = $option_4_delfin_de_rio;
        } elseif (strpos($option_4_slugCookieValue, 'elefantes') !== false) {
            $option_4_urlRedirect = $option_4_elefante;
        } elseif (strpos($option_4_slugCookieValue, 'jaguar') !== false) {
            $option_4_urlRedirect = $option_4_jaguar;
        } elseif (strpos($option_4_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_4_urlRedirect = $option_4_oso;
        } elseif (strpos($option_4_slugCookieValue, 'oso-panda') !== false) {
            $option_4_urlRedirect = $option_4_oso_panda;
        } elseif (strpos($option_4_slugCookieValue, 'tortuga') !== false) {
            $option_4_urlRedirect = $option_4_tortuga;
        } elseif (strpos($option_4_slugCookieValue, 'apoyanos') !== false) {
            $option_4_urlRedirect = $option_4_apoya_la_causa_wwf;
        } elseif (strpos($option_4_slugCookieValue, 'fondo-incendios') !== false) {
            $option_4_urlRedirect = $option_4_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_4_timezone = new DateTimeZone('America/Bogota');
        $option_4_date = new DateTime('now', $option_4_timezone);
        $option_4_date_formatted = $option_4_date->format('Y-m-d H:i:s');

        $option_4_day = $option_4_date->format('d');
        $option_4_month = $option_4_date->format('m');
        $option_4_year = $option_4_date->format('Y');

        $option_4_total_date = $option_4_day . '-' . $option_4_month . '-' . $option_4_year;

        $inserted_id = $wpdb->insert_id;

        $option_4_donation_data = [$option_4_monthly_payu_bool, $option_4_amount, $inserted_id, $option_4_total_date, $option_4_tipoIdentificacionPayu . ': ' . $option_4_identification];

        option_4_enviar_correo($option_4_emailAddress, $option_4_slugCookieValue, $option_4_fullName, "", "", "", false, "payu", $option_4_donation_data);

        if ($option_4_is_gift_payu_bool == true) {
            option_4_enviar_correo($option_4_gift_email_payu, $option_4_slugCookieValue, $option_4_gift_name_payu, $option_4_gift_name_payu, $option_4_gift_message_payu, $option_4_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_4_urlRedirect."');</script>";
        //wp_redirect($option_4_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_4_error."');</script>";
        //wp_redirect($option_4_error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $option_4_timezone = new DateTimeZone('America/Bogota');
    $option_4_date = new DateTime('now', $option_4_timezone);
    $option_4_date_formatted = $option_4_date->format('Y-m-d H:i:s');

    $option_4_monthly = "NO";
    if($option_4_monthly_payu_bool){
        $option_4_monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($option_4_stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($option_4_slugCookieValue, 'delfin') !== false) {
        $option_4_description = "DELFIN DE RIO";
    } elseif (strpos($option_4_slugCookieValue, 'elefantes') !== false) {
        $option_4_description = "ELEFANTES";
    } elseif (strpos($option_4_slugCookieValue, 'jaguar') !== false) {
        $option_4_description = "JAGUAR";
    } elseif (strpos($option_4_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_4_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_4_slugCookieValue, 'oso-panda') !== false) {
        $option_4_description = "OSO PANDA";
    } elseif (strpos($option_4_slugCookieValue, 'tortuga') !== false) {
        $option_4_description = "TORTUGA MARINA";
    } elseif (strpos($option_4_slugCookieValue, 'apoyanos') !== false) {
        $option_4_description = "DONACION GENERAL";
    } elseif (strpos($option_4_slugCookieValue, 'fondo-incendios') !== false) {
        $option_4_description = "FONDO DE INCENDIOS";
    } else {
        $option_4_description = "DONACION GENERAL";
    }

    $option_4_format = array('%s');

    $option_4_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_4_table_logs,
        array(
            'name' => $option_4_fullName,
            'payment_method' => "PAYU",
            'id_type' => $option_4_tipoIdentificacionPayu,
            'id_number' => $option_4_identification,
            'phone_number' => $option_4_contactPhone,
            'email' => $option_4_emailAddress,
            'amount' => $option_4_amount,
            'payment_description' => $option_4_description,
            'date_in' => $option_4_date_formatted,
            'monthly' => $option_4_monthly,
            'final_result' => $final_status
        ),
        $option_4_format
    );

    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['option_4_payu_pse'])) {
    $option_4_person_type_pse = sanitize_text_field($_POST['option_4_person_type_pse']);
    $option_4_nombreBanco_pse = sanitize_text_field($_POST['option_4_nombreBanco_pse']);
    $option_4_amount = sanitize_text_field($_POST['option_4_amount_pse']);
    //$reference = 'abcde475674675';
    $option_4_reference = sanitize_text_field($_POST['option_4_referenceCode_pse']);
    $option_4_description = sanitize_text_field($_POST['option_4_description_pse']);
    $option_4_responseUrl = sanitize_text_field($_POST['option_4_responseUrl_pse']);
    $option_4_fullName = sanitize_text_field($_POST['option_4_payerFullName_pse']) . ' ' . sanitize_text_field($_POST['option_4_payerLastName_pse']);

    $option_4_tipoIdentificacionPayu = sanitize_text_field($_POST['option_4_tipoIdentificacionPayu_pse']);

    $option_4_emailAddress = sanitize_text_field($_POST['option_4_buyerEmail_pse']);
    $option_4_contactPhone = sanitize_text_field($_POST['option_4_payerPhone_pse']);
    $option_4_identification = sanitize_text_field($_POST['option_4_numeroIdentificacionPayu_pse']);

    $option_4_gift_email_payu = sanitize_text_field($_POST['option_4_gift_email_payu_pse']);
    $option_4_gift_name_payu = sanitize_text_field($_POST['option_4_gift_name_payu_pse']);
    $option_4_gift_message_payu = sanitize_text_field($_POST['option_4_gift_message_payu_pse']);
    $option_4_is_gift_payu_string = sanitize_text_field($_POST['option_4_is_gift_payu_pse']);

    $option_4_monthly_payu_string = sanitize_text_field($_POST['option_4_monthly_payu_pse']);

    $option_4_monthly_payu_bool = false;
    if ($option_4_monthly_payu_string == "1") {
        $option_4_monthly_payu_bool = true;
    } else {
        $option_4_monthly_payu_bool = false;
    }

    $option_4_is_gift_payu_int = intval($option_4_is_gift_payu_string);

    $option_4_ipAddress = $_SERVER['REMOTE_ADDR'];

    //--------------------------------------------------------------------------
    $option_4_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_4_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_4_slugCookie])) {
        // Obtener el valor de la cookie
        $option_4_slugCookieValue = $_COOKIE[$option_4_slugCookie];
    }
    //----------------------------------------------------------------------------------------------

    $option_4_preSignature = $option_4_ApiKey . '~' . $option_4_merchantId . '~' . $option_4_reference . '~' . $option_4_amount . '~' . 'COP';

    $option_4_signature = md5($option_4_preSignature);

    //----------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $option_4_timezone = new DateTimeZone('America/Bogota');
    $option_4_date = new DateTime('now', $option_4_timezone);
    $option_4_date_formatted = $option_4_date->format('Y-m-d H:i:s');
    //----------------------------------------------
    $option_4_format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d');
    //----------------------------------------------
    $option_4_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_4_table_logs,
        array(
            'name' => $option_4_fullName,
            'payment_method' => "PSE",
            'id_type' => $option_4_tipoIdentificacionPayu,
            'id_number' => $option_4_identification,
            'phone_number' => $option_4_contactPhone,
            'email' => $option_4_emailAddress,
            'amount' => $option_4_amount,
            'payment_description' => $option_4_slugCookieValue,
            'date_in' => $option_4_date_formatted,
            'monthly' => "NO",
            'final_result' => "No Aprobada",
            'signature_payu' => $option_4_reference,
            'is_gift' => $option_4_is_gift_payu_int
        ),
        $option_4_format
    );
    //----------------------------------------------
    $option_4_format = array('%s');
    //----------------------------------------------
    $option_4_table_logs = $wpdb->prefix . 'gift_table';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_4_table_logs,
        array(
            'signature_payu' => $option_4_reference,
            'gift_email' => $option_4_gift_email_payu,
            'gift_name' => $option_4_gift_name_payu,
            'gift_message' => $option_4_gift_message_payu
        ),
        $option_4_format
    );
    //----------------------------------------------
    $option_4_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_4_ApiKey,
            'apiLogin' => $option_4_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_4_accountId,
                'referenceCode' => $option_4_reference,
                'description' => $option_4_reference,
                'language' => 'es',
                'signature' => $option_4_signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($option_4_amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_4_fullName,
                'emailAddress' => $option_4_emailAddress,
                'contactPhone' => $option_4_contactPhone,
                'dniType' => $option_4_tipoIdentificacionPayu,
                'dniNumber' => $option_4_identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $option_4_responseUrl,
                'PSE_REFERENCE1' => $option_4_ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $option_4_nombreBanco_pse,
                'USER_TYPE' => $option_4_person_type_pse,
                'PSE_REFERENCE2' => $option_4_tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $option_4_identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_4_deviceSessionId,
            'ipAddress' => $option_4_ipAddress,
            'cookie' => $option_4_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_4_setTest
    );

    // Convertir datos a formato JSON
    $option_4_json_data = json_encode($option_4_data);

    // Configuración de la solicitud cURL
    $option_4_ch = curl_init($option_4_url);
    curl_setopt($option_4_ch, CURLOPT_POST, 1);
    curl_setopt($option_4_ch, CURLOPT_POSTFIELDS, $option_4_json_data);
    curl_setopt($option_4_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_4_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_4_response = curl_exec($option_4_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_4_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_4_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_4_ch);

    // Decodificar la respuesta XML
    $option_4_response_data_xml = simplexml_load_string($option_4_response);

    // Convertir SimpleXMLElement a array
    $option_4_response_data_array = json_decode(json_encode($option_4_response_data_xml), true);

    $option_4_json_result = json_encode($option_4_response_data_array);

    $option_4_array_result = json_decode($option_4_json_result, true);

    if (isset($option_4_array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($option_4_array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['option_4_guardar'])) {
    // Obtener los valores del formulario
    $option_4_monthly_bank = sanitize_text_field($_POST['option_4_monthly_bank']);
    $option_4_monto_form = sanitize_text_field($_POST['option_4_monto_form']);
    $option_4_name = sanitize_text_field($_POST['option_4_nombre']) . ' ' . sanitize_text_field($_POST['option_4_apellido']);
    $option_4_account_type = sanitize_text_field($_POST['option_4_tipoCuenta']);
    $option_4_account_number = sanitize_text_field($_POST['option_4_numeroCuenta']);
    $option_4_bank_name = sanitize_text_field($_POST['option_4_nombreBanco']);
    $option_4_id_type = sanitize_text_field($_POST['option_4_tipoIdentificacion']);
    $option_4_id_number = sanitize_text_field($_POST['option_4_numeroIdentificacion']);
    $option_4_phone_number = sanitize_text_field($_POST['option_4_numeroTelefono']);
    $option_4_email = sanitize_text_field($_POST['option_4_correoElectronico']);
    $option_4_description = sanitize_text_field($_POST['option_4_description_bank']);

    $option_4_gift_email_bank = sanitize_text_field($_POST['option_4_gift_email_bank']);
    $option_4_gift_name_bank = sanitize_text_field($_POST['option_4_gift_name_bank']);
    $option_4_gift_message_bank = sanitize_text_field($_POST['option_4_gift_message_bank']);
    $option_4_is_gift_bank_string = sanitize_text_field($_POST['option_4_is_gift_bank']);

    $option_4_is_gift_bank_bool = false;
    if ($option_4_is_gift_bank_string == "1") {
        $option_4_is_gift_bank_bool = true;
    } else {
        $option_4_is_gift_bank_bool = false;
    }

    $option_4_monthly = "NO";
    if ($option_4_monthly_bank == "1") {
        $option_4_monthly = "SI";
    } else {
        $option_4_monthly = "NO";
    }

    if (strpos($option_4_description, 'delfin') !== false) {
        $option_4_description = "DELFIN DE RIO";
    } elseif (strpos($option_4_description, 'elefantes') !== false) {
        $option_4_description = "ELEFANTES";
    } elseif (strpos($option_4_description, 'jaguar') !== false) {
        $option_4_description = "JAGUAR";
    } elseif (strpos($option_4_description, 'oso-de-anteojos') !== false) {
        $option_4_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_4_description, 'oso-panda') !== false) {
        $option_4_description = "OSO PANDA";
    } elseif (strpos($option_4_description, 'tortuga') !== false) {
        $option_4_description = "TORTUGA MARINA";
    } elseif (strpos($option_4_description, 'apoyanos') !== false) {
        $option_4_description = "DONACION GENERAL";
    } elseif (strpos($option_4_description, 'fondo-incendios') !== false) {
        $option_4_description = "FONDO DE INCENDIOS";
    } else {
        $option_4_description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $option_4_timezone = new DateTimeZone('America/Bogota');
    $option_4_date = new DateTime('now', $option_4_timezone);
    $option_4_date_formatted = $option_4_date->format('Y-m-d H:i:s');

    $option_4_day = $option_4_date->format('d');
    $option_4_month = $option_4_date->format('m');
    $option_4_year = $option_4_date->format('Y');

    $option_4_total_date = $option_4_day . '-' . $option_4_month . '-' . $option_4_year;

    $option_4_format = array('%s');

    $option_4_table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_4_table_name_bank_accounts,
        array(
            'name' => $option_4_name,
            'account_type' => $option_4_account_type,
            'account_number' => $option_4_account_number,
            'bank_name' => $option_4_bank_name,
            'id_type' => $option_4_id_type,
            'id_number' => $option_4_id_number,
            'phone_number' => $option_4_phone_number,
            'email' => $option_4_email,
            'amount' => $option_4_monto_form,
            'date_in' => $option_4_date_formatted,
            'payment_description' => $option_4_description,
            'monthly' => $option_4_monthly,
        ),
        $option_4_format
    );

    $inserted_id = $wpdb->insert_id;

    $option_4_donation_data = [$option_4_monthly, $option_4_monto_form, $inserted_id, $option_4_total_date];

    $option_4_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_4_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_4_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_4_nombreCookieValue = $_COOKIE[$option_4_nombreCookie];
    }

    $option_4_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_4_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_4_correoCookie])) {
        // Obtener el valor de la cookie
        $option_4_correoCookieValue = $_COOKIE[$option_4_correoCookie];
    }

    $option_4_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_4_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_4_slugCookie])) {
        // Obtener el valor de la cookie
        $option_4_slugCookieValue = $_COOKIE[$option_4_slugCookie];
    }

    //----------------------------------------------------------------------------
    $option_4_aproved = "";
    $option_4_error = "";
    $option_4_pending = "";
    $option_4_expired = "";
    $option_4_delfin_de_rio = "";
    $option_4_elefante = "";
    $option_4_jaguar = "";
    $option_4_oso = "";
    $option_4_oso_panda = "";
    $option_4_tortuga = "";
    $option_4_apoya_la_causa_wwf = "";
    $option_4_fondo_incendios = "";

    $option_4_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_4_sql = "SELECT * FROM $option_4_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_4_results = $wpdb->get_results($option_4_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_4_results as $option_4_result) {
        $option_4_aproved = $option_4_result->aproved;
        $option_4_error = $option_4_result->error;
        $option_4_pending = $option_4_result->pending;
        $option_4_expired = $option_4_result->expired;
        $option_4_delfin_de_rio = $option_4_result->delfin_de_rio;
        $option_4_elefante = $option_4_result->elefante;
        $option_4_jaguar = $option_4_result->jaguar;
        $option_4_oso = $option_4_result->oso;
        $option_4_oso_panda = $option_4_result->oso_panda;
        $option_4_tortuga = $option_4_result->tortuga;
        $option_4_apoya_la_causa_wwf = $option_4_result->apoya_la_causa_wwf;
        $option_4_fondo_incendios = $option_4_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_4_urlRedirect = $option_4_aproved;
    if (strpos($option_4_slugCookieValue, 'delfin') !== false) {
        $option_4_urlRedirect = $option_4_delfin_de_rio;
    } elseif (strpos($option_4_slugCookieValue, 'elefantes') !== false) {
        $option_4_urlRedirect = $option_4_elefante;
    } elseif (strpos($option_4_slugCookieValue, 'jaguar') !== false) {
        $option_4_urlRedirect = $option_4_jaguar;
    } elseif (strpos($option_4_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_4_urlRedirect = $option_4_oso;
    } elseif (strpos($option_4_slugCookieValue, 'oso-panda') !== false) {
        $option_4_urlRedirect = $option_4_oso_panda;
    } elseif (strpos($option_4_slugCookieValue, 'tortuga') !== false) {
        $option_4_urlRedirect = $option_4_tortuga;
    } elseif (strpos($option_4_slugCookieValue, 'apoyanos') !== false) {
        $option_4_urlRedirect = $option_4_apoya_la_causa_wwf;
    } elseif (strpos($option_4_slugCookieValue, 'fondo-incendios') !== false) {
        $option_4_urlRedirect = $option_4_fondo_incendios;
    }

    option_4_enviar_correo($option_4_email, $option_4_slugCookieValue, $option_4_name, "", "", "", false, "bank_account", $option_4_donation_data);

    if ($option_4_is_gift_bank_bool == true) {
        option_4_enviar_correo($option_4_gift_email_bank, $option_4_slugCookieValue, $option_4_gift_name_bank, $option_4_gift_name_bank, $option_4_gift_message_bank, $option_4_gift_email_bank, true, "", false);
    }

    echo "<script>window.location.assign('".$option_4_urlRedirect."');</script>";

    //wp_redirect($option_4_urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html/html_option_4.php');

include(plugin_dir_path(__FILE__) . '../css/css_option_4.php');
