<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option_payment/functions_option_payment_1.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState']))
{
    $option_payment_1_aproved = "";
    $option_payment_1_error = "";
    $option_payment_1_pending = "";
    $option_payment_1_expired = "";
    $option_payment_1_delfin_de_rio = "";
    $option_payment_1_elefante = "";
    $option_payment_1_jaguar = "";
    $option_payment_1_oso = "";
    $option_payment_1_oso_panda = "";
    $option_payment_1_tortuga = "";
    $option_payment_1_apoya_la_causa_wwf = "";
    $option_payment_1_fondo_incendios = "";

    $option_payment_1_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_payment_1_sql = "SELECT * FROM $option_payment_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_payment_1_results = $wpdb->get_results($option_payment_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_payment_1_results as $option_payment_1_result) {
        $option_payment_1_aproved = $option_payment_1_result->aproved;
        $option_payment_1_error = $option_payment_1_result->error;
        $option_payment_1_pending = $option_payment_1_result->pending;
        $option_payment_1_expired = $roption_payment_1_esult->expired;
        $option_payment_1_delfin_de_rio = $option_payment_1_result->delfin_de_rio;
        $option_payment_1_elefante = $option_payment_1_result->elefante;
        $option_payment_1_jaguar = $option_payment_1_result->jaguar;
        $option_payment_1_oso = $option_payment_1_result->oso;
        $option_payment_1_oso_panda = $option_payment_1_result->oso_panda;
        $option_payment_1_tortuga = $option_payment_1_result->tortuga;
        $option_payment_1_apoya_la_causa_wwf = $option_payment_1_result->apoya_la_causa_wwf;
        $option_payment_1_fondo_incendios = $option_payment_1_result->fondo_incendios;
    }
    //--------------------------------------------------------------------------
    $signature = sanitize_text_field($_GET['description']);
    $desired_signature = $signature;
    $signature_payu_specific = $signature;
    //--------------------------------------------------------------------------
    $table_name_orders_data = $wpdb->prefix . 'orders_data';

    $query = $wpdb->prepare("SELECT * FROM $table_name_orders_data WHERE signature_payu = %s", $desired_signature);
    $row = null;
    $row = $wpdb->get_row($query);

    $inserted_id = '';
    $option_payment_1_department_CookieValue = '';
    $option_payment_1_city_CookieValue = '';
    $option_payment_1_address_1_CookieValue = '';
    $option_payment_1_address_2_CookieValue = '';

    if (null !== $row){
        $inserted_id = $row->id;
        $option_payment_1_department_CookieValue = $row->department;
        $option_payment_1_city_CookieValue = $row->city;
        $option_payment_1_address_1_CookieValue = $row->address_1;
        $option_payment_1_address_2_CookieValue = $row->address_2;
        //--------------------------------------------------------------------------
        $table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';

        $query = $wpdb->prepare("SELECT * FROM $table_name_bank_accounts_logs WHERE signature_payu = %s", $desired_signature);

        $row = $wpdb->get_row($query);

        $option_payment_1_nombreCookieValue = '';
        $option_payment_1_correoCookieValue = '';
        $option_payment_1_slugCookieValue = '';
        $option_payment_1_monthly_payu_bool = false;
        $option_payment_1_amount = '';
        $option_payment_1_tipoIdentificacionPayu = '';
        $option_payment_1_identification = '';
        $option_payment_1_phone_CookieValue = '';
        $option_payment_1_is_gift_payu_bool = false;

        echo '<h1>1</h1>';

        if (null !== $row){
            $option_payment_1_nombreCookieValue = $row->name;
            $option_payment_1_correoCookieValue = $row->email;
            $option_payment_1_slugCookieValue = $row->payment_description;
            $option_payment_1_amount = $row->amount;
            $option_payment_1_tipoIdentificacionPayu = $row->id_type;
            $option_payment_1_identification = $row->id_number;
            $option_payment_1_phone_CookieValue = $row->phone_number;

            if ($row->is_gift == 1) {
                $option_payment_1_is_gift_payu_bool = true;
            } else {
                $option_payment_1_is_gift_payu_bool = false;
            }
        }
        echo '<h1>2</h1>';
        //--------------------------------------------------------------------------
        $option_payment_1_gift_email_payu = '';
        $option_payment_1_gift_name_payu = '';
        $option_payment_1_gift_message_payu = '';
        if($option_payment_1_is_gift_payu_bool){
            $table_name_gift_table = $wpdb->prefix . 'gift_table';

            $query = $wpdb->prepare("SELECT * FROM $table_name_gift_table WHERE signature_payu = %s", $desired_signature);

            $row = $wpdb->get_row($query);

            if (null !== $row){
                $option_payment_1_gift_email_payu = $row->gift_email;
                $option_payment_1_gift_name_payu = $row->gift_name;
                $option_payment_1_gift_message_payu = $row->gift_message;
            }
        }
        echo '<h1>3</h1>';
        //--------------------------------------------------------------------------
        $table_name_orders_data = $wpdb->prefix . 'orders_data';

        $query = $wpdb->prepare("SELECT * FROM $table_name_orders_data WHERE signature_payu = %s", $desired_signature);

        $row = $wpdb->get_row($query);

        $inserted_id = '';
        $option_payment_1_department_CookieValue = '';
        $option_payment_1_city_CookieValue = '';
        $option_payment_1_address_1_CookieValue = '';
        $option_payment_1_address_2_CookieValue = '';
        if (null !== $row){
            $inserted_id = $row->id;
            $option_payment_1_department_CookieValue = $row->department;
            $option_payment_1_city_CookieValue = $row->city;
            $option_payment_1_address_1_CookieValue = $row->address_1;
            $option_payment_1_address_2_CookieValue = $row->address_2;
        }
        echo '<h1>4</h1>';
        //--------------------------------------------------------------------------
        $option_payment_1_donation_data = array();
        //--------------------------------------------------------------------------
        $option_payment_1_stateValue = sanitize_text_field($_GET['transactionState']);
        //--------------------------------------------------------------------------
        if ($option_payment_1_stateValue == "4" || $option_payment_1_stateValue == 4) {
            $option_payment_1_urlRedirect = $option_payment_1_aproved;
            if (strpos($option_payment_1_slugCookieValue, 'delfin') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_delfin_de_rio;
            } elseif (strpos($option_payment_1_slugCookieValue, 'elefantes') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_elefante;
            } elseif (strpos($option_payment_1_slugCookieValue, 'jaguar') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_jaguar;
            } elseif (strpos($option_payment_1_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_oso;
            } elseif (strpos($option_payment_1_slugCookieValue, 'oso-panda') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_oso_panda;
            } elseif (strpos($option_payment_1_slugCookieValue, 'tortuga') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_tortuga;
            } elseif (strpos($option_payment_1_slugCookieValue, 'apoyanos') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_apoya_la_causa_wwf;
            } elseif (strpos($option_payment_1_slugCookieValue, 'fondo-incendios') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_fondo_incendios;
            }

            // Obtener la fecha actual en la zona horaria -5
            $option_payment_1_timezone = new DateTimeZone('America/Bogota');
            $option_payment_1_date = new DateTime('now', $option_payment_1_timezone);
            $option_payment_1_date_formatted = $option_payment_1_date->format('Y-m-d H:i:s');

            $option_payment_1_day = $option_payment_1_date->format('d');
            $option_payment_1_month = $option_payment_1_date->format('m');
            $option_payment_1_year = $option_payment_1_date->format('Y');

            $option_payment_1_total_date = $option_payment_1_day . '-' . $option_payment_1_month . '-' . $option_payment_1_year;

            $option_payment_1_donation_data = [
                $option_payment_1_monthly_payu_bool,
                $option_payment_1_amount,
                $inserted_id,
                $option_payment_1_total_date,
                $option_payment_1_tipoIdentificacionPayu . ': ' . $option_payment_1_identification,
                $option_payment_1_phone_CookieValue,
                $option_payment_1_department_CookieValue,
                $option_payment_1_city_CookieValue,
                $option_payment_1_address_1_CookieValue . '. ' . $option_payment_1_address_2_CookieValue
            ];

            //----------------------------------------------------------------------------------------
            // Obtener la fecha actual en la zona horaria -5
            $option_payment_1_timezone = new DateTimeZone('America/Bogota');
            $option_payment_1_date = new DateTime('now', $option_payment_1_timezone);
            $option_payment_1_date_formatted = $option_payment_1_date->format('Y-m-d H:i:s');
            
            $final_status = "No Aprobada";
            if ($option_payment_1_stateValue == "4" || $option_payment_1_stateValue == 4){
                $final_status = "Aprobada";
            }
            $option_payment_1_description = str_replace("/", "", $option_payment_1_slugCookieValue);
            $option_payment_1_description = str_replace("-", " ", $option_payment_1_description);
            $option_payment_1_description = str_replace("_", " ", $option_payment_1_description);
            $option_payment_1_description = strtoupper($option_payment_1_description);
            $option_payment_1_description = "Producto: " . $option_payment_1_description;
            //----------------------------------------------------------------------------------------
            if($final_status == "Aprobada"){

                //----------------------------------------------------------------------------------------
                $new_data = array(
                    'payment_description' => $option_payment_1_description,
                    'final_result' => $final_status,
                );

                $where = array(
                    'signature_payu' => $signature_payu_specific
                );

                $data_format = array('%s');
                $where_format = array('%s');
                $table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';
                $updated = $wpdb->update($table_name_bank_accounts_logs, $new_data, $where, $data_format, $where_format);
                //----------------------------------------------------------------------------------------
                $new_data = array(
                    'payment_description' => $option_payment_1_description,
                    'payment_made' => true,
                );

                $where = array(
                    'signature_payu' => $signature_payu_specific
                );

                $data_format = array('%s');
                $where_format = array('%s');
                $table_name_bank_accounts_orders_data = $wpdb->prefix . 'orders_data';
                $updated = $wpdb->update($table_name_bank_accounts_orders_data, $new_data, $where, $data_format, $where_format);
                //----------------------------------------------------------------------------------------
                $option_payment_1_donation_data[2] = $inserted_id;
                option_payment_1_enviar_correo($option_payment_1_correoCookieValue, $option_payment_1_slugCookieValue, $option_payment_1_nombreCookieValue, $option_payment_1_gift_name_payu, "", "", false, "payu", $option_payment_1_donation_data);
                if ($option_payment_1_is_gift_payu_bool){
                    option_payment_1_enviar_correo($option_payment_1_gift_email_CookieValue, $option_payment_1_slugCookieValue, $option_payment_1_nombreCookieValue, $option_payment_1_gift_name_payu, $option_payment_1_gift_message_CookieValue, $option_payment_1_gift_email_CookieValue, false, "payu", $option_payment_1_donation_data);
                }
            }
        //----------------------------------------------------------------------------------------

            echo "<script>window.location.assign('".$option_payment_1_urlRedirect."');</script>";
            //wp_redirect($option_payment_1_urlRedirect);
        } else {
            echo "<script>window.location.assign('".$option_payment_1_error."');</script>";
            //wp_redirect($option_payment_1_error);
        }
        exit;
    //----------------------------------------------------------------------------------------
    }
}
//--------------------------------------------------------------------------------------------
/*
if (isset($_REQUEST['transactionState'])) {
    $option_payment_1_aproved = "";
    $option_payment_1_error = "";
    $option_payment_1_pending = "";
    $option_payment_1_expired = "";
    $option_payment_1_delfin_de_rio = "";
    $option_payment_1_elefante = "";
    $option_payment_1_jaguar = "";
    $option_payment_1_oso = "";
    $option_payment_1_oso_panda = "";
    $option_payment_1_tortuga = "";
    $option_payment_1_apoya_la_causa_wwf = "";
    $option_payment_1_fondo_incendios = "";

    $option_payment_1_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_payment_1_sql = "SELECT * FROM $option_payment_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_payment_1_results = $wpdb->get_results($option_payment_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_payment_1_results as $option_payment_1_result) {
        $option_payment_1_aproved = $option_payment_1_result->aproved;
        $option_payment_1_error = $option_payment_1_result->error;
        $option_payment_1_pending = $option_payment_1_result->pending;
        $option_payment_1_expired = $option_payment_1_result->expired;
        $option_payment_1_delfin_de_rio = $option_payment_1_result->delfin_de_rio;
        $option_payment_1_elefante = $option_payment_1_result->elefante;
        $option_payment_1_jaguar = $option_payment_1_result->jaguar;
        $option_payment_1_oso = $option_payment_1_result->oso;
        $option_payment_1_oso_panda = $option_payment_1_result->oso_panda;
        $option_payment_1_tortuga = $option_payment_1_result->tortuga;
        $option_payment_1_apoya_la_causa_wwf = $option_payment_1_result->apoya_la_causa_wwf;
        $option_payment_1_fondo_incendios = $option_payment_1_result->fondo_incendios;
    }

    if ($_REQUEST['transactionState']) {

        if ($_REQUEST['transactionState'] == "4") {

            $option_payment_1_nombreCookie = "proyecto_donaciones_colombia_nombre";
            $option_payment_1_nombreCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_payment_1_nombreCookie])) {
                // Obtener el valor de la cookie
                $option_payment_1_nombreCookieValue = $_COOKIE[$option_payment_1_nombreCookie];
            }

            $option_payment_1_correoCookie = "proyecto_donaciones_colombia_correo";
            $option_payment_1_correoCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_payment_1_correoCookie])) {
                // Obtener el valor de la cookie
                $option_payment_1_correoCookieValue = $_COOKIE[$option_payment_1_correoCookie];
            }

            $option_payment_1_slugCookie = "proyecto_donaciones_colombia_slug";
            $option_payment_1_slugCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_payment_1_slugCookie])) {
                // Obtener el valor de la cookie
                $option_payment_1_slugCookieValue = $_COOKIE[$option_payment_1_slugCookie];
            }

            $option_payment_1_urlRedirect = $option_payment_1_aproved;
            if (strpos($option_payment_1_slugCookieValue, 'delfin') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_delfin_de_rio;
            } elseif (strpos($option_payment_1_slugCookieValue, 'elefantes') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_elefante;
            } elseif (strpos($option_payment_1_slugCookieValue, 'jaguar') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_jaguar;
            } elseif (strpos($option_payment_1_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_oso;
            } elseif (strpos($option_payment_1_slugCookieValue, 'oso-panda') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_oso_panda;
            } elseif (strpos($option_payment_1_slugCookieValue, 'tortuga') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_tortuga;
            } elseif (strpos($option_payment_1_slugCookieValue, 'apoyanos') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_apoya_la_causa_wwf;
            } elseif (strpos($option_payment_1_slugCookieValue, 'fondo-incendios') !== false) {
                $option_payment_1_urlRedirect = $option_payment_1_fondo_incendios;
            }

            option_payment_1_enviar_correo($option_payment_1_correoCookieValue, $option_payment_1_slugCookieValue, $option_payment_1_nombreCookieValue, false, false);
            echo $option_payment_1_urlRedirect;
            wp_redirect($option_payment_1_urlRedirect);
        } else if ($_REQUEST['transactionState'] == "6" || $_REQUEST['transactionState'] == "104") {
            wp_redirect($option_payment_1_error);
        }
        if ($_REQUEST['transactionState'] == "5") {
            wp_redirect($option_payment_1_expired);
        }
        if ($_REQUEST['transactionState'] == "7") {
            wp_redirect($option_payment_1_pending);
        }

        exit;
    }
}
*/
//--------------------------------------------------------------------------------------------
global $product;

$option_payment_1_price = "";
$product_name = "";
if (is_a($product, 'WC_Product')) {

    $option_payment_1_price = $product->get_price();
    $product_name = $product->get_name();
}

// Crear un array asociativo para almacenar los resultados
$option_payment_1_values = array();

$option_payment_1_values[1] = $option_payment_1_price;
$option_payment_1_values[2] = $option_payment_1_price;
$option_payment_1_values[3] = $option_payment_1_price;
$option_payment_1_values[4] = $option_payment_1_price;
$option_payment_1_values[5] = $option_payment_1_price;
$option_payment_1_values[6] = $option_payment_1_price;

// Codificar el array en formato JSON para usarlo en JavaScript
$option_payment_1_values_json = json_encode($option_payment_1_values);

$option_payment_1_timezone = new DateTimeZone('America/Bogota');
$option_payment_1_date = new DateTime('now', $option_payment_1_timezone);
$option_payment_1_reference = $option_payment_1_date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$option_payment_1_cookie = "";
// Nombre de la cookie
$option_payment_1_cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$option_payment_1_cookieName])) {
    // Obtiene el valor de la cookie
    $option_payment_1_cookie = $_COOKIE[$option_payment_1_cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $option_payment_1_cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($option_payment_1_cookieName, '', time() - 3600, '/'); // Borra la cookie
        $option_payment_1_newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($option_payment_1_cookieName, $option_payment_1_newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $option_payment_1_sessionId = session_id();
    setcookie($option_payment_1_cookieName, $option_payment_1_sessionId, time() + 3600, '/');
    $option_payment_1_cookie = $_COOKIE[$option_payment_1_cookieName];
}

$option_payment_1_deviceSessionId = md5($option_payment_1_cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$option_payment_1_table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$option_payment_1_sql = "SELECT * FROM $option_payment_1_table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$option_payment_1_results = $wpdb->get_results($option_payment_1_sql);

// Crear un array asociativo para almacenar los resultados
$option_payment_1_merchantId = "";
$option_payment_1_accountId = "";
$option_payment_1_ApiKey = "";
$option_payment_1_ApiLogin = "";
$option_payment_1_testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($option_payment_1_results as $option_payment_1_result) {
    $option_payment_1_merchantId = $option_payment_1_result->merchantId;
    $option_payment_1_accountId = $option_payment_1_result->accountId;
    $option_payment_1_ApiKey = $option_payment_1_result->apiKey;
    $option_payment_1_ApiLogin = $option_payment_1_result->apiLogin;
    $option_payment_1_testMode = $option_payment_1_result->testMode ? "1" : "0";
}

$option_payment_1_setTest = "";
$option_payment_1_url = "";
$option_payment_1_tokenURL = "";
// URL de la API
if ($option_payment_1_testMode == "1") {
    $option_payment_1_setTest = true;
    $option_payment_1_url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $option_payment_1_tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $option_payment_1_setTest = false;
    $option_payment_1_url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $option_payment_1_tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$option_payment_1_data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $option_payment_1_ApiLogin,
        'apiKey' => $option_payment_1_ApiKey
    ),
    'test' => $option_payment_1_setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$option_payment_1_json_data_bank_list = json_encode($option_payment_1_data_bank_list);

// Configuración de la solicitud cURL
$option_payment_1_ch_bank_list = curl_init($option_payment_1_url);
curl_setopt($option_payment_1_ch_bank_list, CURLOPT_POST, 1);
curl_setopt($option_payment_1_ch_bank_list, CURLOPT_POSTFIELDS, $option_payment_1_json_data_bank_list);
curl_setopt($option_payment_1_ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($option_payment_1_ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$option_payment_1_response_bank_list = curl_exec($option_payment_1_ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($option_payment_1_ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($option_payment_1_ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($option_payment_1_ch_bank_list);

// Decodificar la respuesta XML
$option_payment_1_response_data_bank_list_xml = simplexml_load_string($option_payment_1_response_bank_list);

// Convertir SimpleXMLElement a array
$option_payment_1_response_data_bank_list_array = json_decode(json_encode($option_payment_1_response_data_bank_list_xml), true);

$option_payment_1_json_result_bank_list = json_encode($option_payment_1_response_data_bank_list_array);

$option_payment_1_array_result_bank_list = json_decode($option_payment_1_json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($option_payment_1_array_result_bank_list['banks']['bank']) && is_array($option_payment_1_array_result_bank_list['banks']['bank'])) {
    foreach ($option_payment_1_array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['option_payment_1_payu'])) {
    $option_payment_1_amount = sanitize_text_field($_POST['option_payment_1_amount']);
    //$reference = 'abcde475674675';
    $option_payment_1_reference = sanitize_text_field($_POST['option_payment_1_referenceCode']);
    $option_payment_1_description = sanitize_text_field($_POST['option_payment_1_description']);
    $option_payment_1_notifyUrl = sanitize_text_field($_POST['option_payment_1_responseUrl']);
    $option_payment_1_fullName = sanitize_text_field($_POST['option_payment_1_payerFullName']) . ' ' . sanitize_text_field($_POST['option_payment_1_payerLastName']);

    $option_payment_1_tipoIdentificacionPayu = sanitize_text_field($_POST['option_payment_1_tipoIdentificacionPayu']);

    $option_payment_1_emailAddress = sanitize_text_field($_POST['option_payment_1_buyerEmail']);
    $option_payment_1_contactPhone = sanitize_text_field($_POST['option_payment_1_payerPhone']);
    $option_payment_1_creditCardNumber = sanitize_text_field($_POST['option_payment_1_card_number']);
    $option_payment_1_creditCardSecurityCode = sanitize_text_field($_POST['option_payment_1_cvv_card']);
    $option_payment_1_creditCardExpirationDate = sanitize_text_field($_POST['option_payment_1_expiration_year']) . '/' . sanitize_text_field($_POST['option_payment_1_expiration_month']);
    $option_payment_1_creditCardName = $option_payment_1_fullName;
    $option_payment_1_paymentMethod = sanitize_text_field($_POST['option_payment_1_payment_method_1']);
    $option_payment_1_identification = sanitize_text_field($_POST['option_payment_1_numeroIdentificacionPayu']);

    $option_payment_1_gift_email_payu = sanitize_text_field($_POST['option_payment_1_gift_email_payu']);
    $option_payment_1_gift_name_payu = sanitize_text_field($_POST['option_payment_1_gift_name_payu']);
    $option_payment_1_gift_message_payu = sanitize_text_field($_POST['option_payment_1_gift_message_payu']);
    $option_payment_1_is_gift_payu_string = sanitize_text_field($_POST['option_payment_1_is_gift_payu']);

    $option_payment_1_monthly_payu_string = sanitize_text_field($_POST['option_payment_1_monthly_payu']);

    $option_payment_1_department = sanitize_text_field($_POST['option_payment_1_department_payu']);
    $option_payment_1_city = sanitize_text_field($_POST['option_payment_1_city_payu']);
    $option_payment_1_address_1 = sanitize_text_field($_POST['option_payment_1_address_1_payu']);
    $option_payment_1_address_2 = sanitize_text_field($_POST['option_payment_1_address_2_payu']);

    $option_payment_1_monthly_payu_bool = false;
    if ($option_payment_1_monthly_payu_string == "1") {
        $option_payment_1_monthly_payu_bool = true;
    } else {
        $option_payment_1_monthly_payu_bool = false;
    }

    $option_payment_1_is_gift_payu_bool = false;
    if ($option_payment_1_is_gift_payu_string == "1") {
        $option_payment_1_is_gift_payu_bool = true;
    } else {
        $option_payment_1_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_payment_1_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($option_payment_1_monthly_payu_bool == true) {
        $option_payment_1_tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $option_payment_1_ApiLogin,
                "apiKey" => $option_payment_1_ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $option_payment_1_identification,
                "name" => $option_payment_1_fullName,
                "identificationNumber" => $option_payment_1_identification,
                "paymentMethod" => $option_payment_1_paymentMethod,
                "number" => $option_payment_1_creditCardNumber,
                "expirationDate" => $option_payment_1_creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $option_payment_1_json_data = json_encode($option_payment_1_tokenData);

        // Configuración de la solicitud cURL
        $option_payment_1_ch = curl_init($option_payment_1_tokenURL);
        curl_setopt($option_payment_1_ch, CURLOPT_POST, 1);
        curl_setopt($option_payment_1_ch, CURLOPT_POSTFIELDS, $option_payment_1_json_data);
        curl_setopt($option_payment_1_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($option_payment_1_ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $option_payment_1_response = curl_exec($option_payment_1_ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($option_payment_1_ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($option_payment_1_ch);
        }

        // Cerrar la conexión cURL
        curl_close($option_payment_1_ch);

        // Decodificar la respuesta XML
        $option_payment_1_response_data_xml = simplexml_load_string($option_payment_1_response);

        // Convertir SimpleXMLElement a array
        $option_payment_1_response_data_array = json_decode(json_encode($option_payment_1_response_data_xml), true);

        $option_payment_1_json_result = json_encode($option_payment_1_response_data_array);

        $option_payment_1_array_result = json_decode($option_payment_1_json_result, true);

        $option_payment_1_creditCardToken = "";
        if ($option_payment_1_array_result['creditCardToken']['creditCardTokenId']) {
            $option_payment_1_creditCardToken = $option_payment_1_array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($option_payment_1_creditCardToken != "") {

            $option_payment_1_format = array('%s');

            $option_payment_1_table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $option_payment_1_table_name_token,
                array(
                    'document' => $option_payment_1_identification,
                    'token_card' => $option_payment_1_creditCardToken,
                    'amount_to_discount' => $option_payment_1_amount,
                    'discount_day' => date('d'),
                    'payer_name' => $option_payment_1_fullName,
                    'phone_number' => $option_payment_1_contactPhone,
                    'payer_email' => $option_payment_1_emailAddress,
                    'cvv_card' => $option_payment_1_creditCardSecurityCode,
                    'paymentMethod' => $option_payment_1_paymentMethod
                ),
                $option_payment_1_format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $option_payment_1_preSignature = $option_payment_1_ApiKey . '~' . $option_payment_1_merchantId . '~' . $option_payment_1_reference . '~' . $option_payment_1_amount . '~' . 'COP';

    $option_payment_1_signature = option_payment_1_sha256($option_payment_1_preSignature);

    //----------------------------------------------

    $option_payment_1_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_payment_1_ApiKey,
            'apiLogin' => $option_payment_1_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_payment_1_accountId,
                'referenceCode' => $option_payment_1_reference,
                'description' => $option_payment_1_description,
                'language' => 'es',
                'signature' => $option_payment_1_signature,
                'notifyUrl' => $option_payment_1_notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $option_payment_1_amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_payment_1_fullName,
                'emailAddress' => $option_payment_1_emailAddress,
                'contactPhone' => $option_payment_1_contactPhone
            ),
            'creditCard' => array(
                'number' => $option_payment_1_creditCardNumber,
                'securityCode' => $option_payment_1_creditCardSecurityCode,
                'expirationDate' => $option_payment_1_creditCardExpirationDate,
                'name' => $option_payment_1_creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $option_payment_1_paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_payment_1_deviceSessionId,
            'ipAddress' => $option_payment_1_ipAddress,
            'cookie' => $option_payment_1_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_payment_1_setTest
    );

    // Convertir datos a formato JSON
    $option_payment_1_json_data = json_encode($option_payment_1_data);

    // Configuración de la solicitud cURL
    $option_payment_1_ch = curl_init($option_payment_1_url);
    curl_setopt($option_payment_1_ch, CURLOPT_POST, 1);
    curl_setopt($option_payment_1_ch, CURLOPT_POSTFIELDS, $option_payment_1_json_data);
    curl_setopt($option_payment_1_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_payment_1_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_payment_1_response = curl_exec($option_payment_1_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_payment_1_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_payment_1_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_payment_1_ch);

    // Decodificar la respuesta XML
    $option_payment_1_response_data_xml = simplexml_load_string($option_payment_1_response);

    // Convertir SimpleXMLElement a array
    $option_payment_1_response_data_array = json_decode(json_encode($option_payment_1_response_data_xml), true);

    $option_payment_1_json_result = json_encode($option_payment_1_response_data_array);

    $option_payment_1_array_result = json_decode($option_payment_1_json_result, true);

    $option_payment_1_stateValue = $option_payment_1_array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $option_payment_1_aproved = "";
    $option_payment_1_error = "";
    $option_payment_1_pending = "";
    $option_payment_1_expired = "";
    $option_payment_1_delfin_de_rio = "";
    $option_payment_1_elefante = "";
    $option_payment_1_jaguar = "";
    $option_payment_1_oso = "";
    $option_payment_1_oso_panda = "";
    $option_payment_1_tortuga = "";
    $option_payment_1_apoya_la_causa_wwf = "";
    $option_payment_1_fondo_incendios = "";

    $option_payment_1_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_payment_1_sql = "SELECT * FROM $option_payment_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_payment_1_results = $wpdb->get_results($option_payment_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_payment_1_results as $option_payment_1_result) {
        $option_payment_1_aproved = $option_payment_1_result->aproved;
        $option_payment_1_error = $option_payment_1_result->error;
        $option_payment_1_pending = $option_payment_1_result->pending;
        $option_payment_1_expired = $roption_payment_1_esult->expired;
        $option_payment_1_delfin_de_rio = $option_payment_1_result->delfin_de_rio;
        $option_payment_1_elefante = $option_payment_1_result->elefante;
        $option_payment_1_jaguar = $option_payment_1_result->jaguar;
        $option_payment_1_oso = $option_payment_1_result->oso;
        $option_payment_1_oso_panda = $option_payment_1_result->oso_panda;
        $option_payment_1_tortuga = $option_payment_1_result->tortuga;
        $option_payment_1_apoya_la_causa_wwf = $option_payment_1_result->apoya_la_causa_wwf;
        $option_payment_1_fondo_incendios = $option_payment_1_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_payment_1_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_payment_1_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_payment_1_slugCookie])) {
        // Obtener el valor de la cookie
        $option_payment_1_slugCookieValue = $_COOKIE[$option_payment_1_slugCookie];
    }

    $payment_made = false;

    $option_payment_1_donation_data = array();

    if ($option_payment_1_stateValue == "APPROVED") {

        $payment_made = true;

        $option_payment_1_nombreCookie = "proyecto_donaciones_colombia_nombre";
        $option_payment_1_nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_payment_1_nombreCookie])) {
            // Obtener el valor de la cookie
            $option_payment_1_nombreCookieValue = $_COOKIE[$option_payment_1_nombreCookie];
        }

        $option_payment_1_correoCookie = "proyecto_donaciones_colombia_correo";
        $option_payment_1_correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_payment_1_correoCookie])) {
            // Obtener el valor de la cookie
            $option_payment_1_correoCookieValue = $_COOKIE[$option_payment_1_correoCookie];
        }

        $option_payment_1_urlRedirect = $option_payment_1_aproved;
        if (strpos($option_payment_1_slugCookieValue, 'delfin') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_delfin_de_rio;
        } elseif (strpos($option_payment_1_slugCookieValue, 'elefantes') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_elefante;
        } elseif (strpos($option_payment_1_slugCookieValue, 'jaguar') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_jaguar;
        } elseif (strpos($option_payment_1_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_oso;
        } elseif (strpos($option_payment_1_slugCookieValue, 'oso-panda') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_oso_panda;
        } elseif (strpos($option_payment_1_slugCookieValue, 'tortuga') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_tortuga;
        } elseif (strpos($option_payment_1_slugCookieValue, 'apoyanos') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_apoya_la_causa_wwf;
        } elseif (strpos($option_payment_1_slugCookieValue, 'fondo-incendios') !== false) {
            $option_payment_1_urlRedirect = $option_payment_1_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_payment_1_timezone = new DateTimeZone('America/Bogota');
        $option_payment_1_date = new DateTime('now', $option_payment_1_timezone);
        $option_payment_1_date_formatted = $option_payment_1_date->format('Y-m-d H:i:s');

        $option_payment_1_day = $option_payment_1_date->format('d');
        $option_payment_1_month = $option_payment_1_date->format('m');
        $option_payment_1_year = $option_payment_1_date->format('Y');

        $option_payment_1_total_date = $option_payment_1_day . '-' . $option_payment_1_month . '-' . $option_payment_1_year;

        $inserted_id = $wpdb->insert_id;

        $option_payment_1_donation_data = [$option_payment_1_monthly_payu_bool, $option_payment_1_amount, $inserted_id, $option_payment_1_total_date, $option_payment_1_tipoIdentificacionPayu . ': ' . $option_payment_1_identification, $option_payment_1_contactPhone, $option_payment_1_department, $option_payment_1_city, $option_payment_1_address_1 . '. ' . $option_payment_1_address_2];

        echo "<script>window.location.assign('".$option_payment_1_urlRedirect."');</script>";
        //wp_redirect($option_payment_1_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_payment_1_error."');</script>";
        //wp_redirect($option_payment_1_error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $option_payment_1_timezone = new DateTimeZone('America/Bogota');
    $option_payment_1_date = new DateTime('now', $option_payment_1_timezone);
    $option_payment_1_date_formatted = $option_payment_1_date->format('Y-m-d H:i:s');

    $option_payment_1_monthly = "NO";
    if($option_payment_1_monthly_payu_bool){
        $option_payment_1_monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($option_payment_1_stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($option_payment_1_slugCookieValue, 'delfin') !== false) {
        $option_payment_1_description = "DELFIN DE RIO";
    } elseif (strpos($option_payment_1_slugCookieValue, 'elefantes') !== false) {
        $option_payment_1_description = "ELEFANTES";
    } elseif (strpos($option_payment_1_slugCookieValue, 'jaguar') !== false) {
        $option_payment_1_description = "JAGUAR";
    } elseif (strpos($option_payment_1_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_payment_1_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_payment_1_slugCookieValue, 'oso-panda') !== false) {
        $option_payment_1_description = "OSO PANDA";
    } elseif (strpos($option_payment_1_slugCookieValue, 'tortuga') !== false) {
        $option_payment_1_description = "TORTUGA MARINA";
    } elseif (strpos($option_payment_1_slugCookieValue, 'apoyanos') !== false) {
        $option_payment_1_description = "DONACION GENERAL";
    } elseif (strpos($option_payment_1_slugCookieValue, 'fondo-incendios') !== false) {
        $option_payment_1_description = "FONDO DE INCENDIOS";
    } else {
        $option_payment_1_description = "DONACION GENERAL";
    }

    $option_payment_1_format = array('%s');

    $option_payment_1_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_payment_1_table_logs,
        array(
            'name' => $option_payment_1_fullName,
            'payment_method' => "PAYU",
            'id_type' => $option_payment_1_tipoIdentificacionPayu,
            'id_number' => $option_payment_1_identification,
            'phone_number' => $option_payment_1_contactPhone,
            'email' => $option_payment_1_emailAddress,
            'amount' => $option_payment_1_amount,
            'payment_description' => 'Producto: ' . $product_name,
            'date_in' => $option_payment_1_date_formatted,
            'monthly' => "NO",
            'final_result' => $final_status
        ),
        $option_payment_1_format
    );
    //-----------------------------------------------------------
    if($final_status == "Aprobada"){
        $option_payment_1_table_logs = $wpdb->prefix . 'orders_data';
        // Insertar los datos en la tabla
        $who_receive = $option_payment_1_fullName;
        if ($option_payment_1_is_gift_payu_bool){
            $who_receive = $option_payment_1_gift_name_payu;
        }
        $wpdb->insert(
            $option_payment_1_table_logs,
            array(
                'name' => $option_payment_1_fullName,
                'who_receive' => $who_receive,
                'payment_method' => "PAYU",
                'id_type' => $option_payment_1_tipoIdentificacionPayu,
                'id_number' => $option_payment_1_identification,
                'phone_number' => $option_payment_1_contactPhone,
                'email' => $option_payment_1_emailAddress,
                'amount' => $option_payment_1_amount,
                'payment_description' => 'Producto: ' . $product_name,
                'date_in' => $option_payment_1_date_formatted,

                'department' => $option_payment_1_department,
                'city' => $option_payment_1_city,
                'address_1' => $option_payment_1_address_1,
                'address_2' => $option_payment_1_address_2,

                'payment_made' => $payment_made,
                'order_shipped' => false,
            ),
            $option_payment_1_format
        );
        $inserted_id = $wpdb->insert_id;
        $option_payment_1_donation_data[2] = $inserted_id;
        option_payment_1_enviar_correo($option_payment_1_emailAddress, $product_name, $option_payment_1_fullName, $option_payment_1_gift_name_payu, "", "", false, "payu", $option_payment_1_donation_data);
        if ($option_payment_1_is_gift_payu_bool){
            option_payment_1_enviar_correo($option_payment_1_gift_email_payu, $product_name, $option_payment_1_fullName, $option_payment_1_gift_name_payu, $option_payment_1_gift_message_payu, $option_payment_1_gift_email_payu, false, "payu", $option_payment_1_donation_data);
        }
        
    }
    //-----------------------------------------------------------
    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['option_payment_1_payu_pse'])) {
    $option_payment_1_person_type_pse = sanitize_text_field($_POST['option_payment_1_person_type_pse']);
    $option_payment_1_nombreBanco_pse = sanitize_text_field($_POST['option_payment_1_nombreBanco_pse']);
    $option_payment_1_amount = sanitize_text_field($_POST['option_payment_1_amount_pse']);
    //$reference = 'abcde475674675';
    $option_payment_1_reference = sanitize_text_field($_POST['option_payment_1_referenceCode_pse']);
    $option_payment_1_description = sanitize_text_field($_POST['option_payment_1_description_pse']);
    $option_payment_1_responseUrl = sanitize_text_field($_POST['option_payment_1_responseUrl_pse']);
    $option_payment_1_fullName = sanitize_text_field($_POST['option_payment_1_payerFullName_pse']) . ' ' . sanitize_text_field($_POST['option_payment_1_payerLastName_pse']);

    $option_payment_1_tipoIdentificacionPayu = sanitize_text_field($_POST['option_payment_1_tipoIdentificacionPayu_pse']);

    $option_payment_1_emailAddress = sanitize_text_field($_POST['option_payment_1_buyerEmail_pse']);
    $option_payment_1_contactPhone = sanitize_text_field($_POST['option_payment_1_payerPhone_pse']);
    $option_payment_1_identification = sanitize_text_field($_POST['option_payment_1_numeroIdentificacionPayu_pse']);

    $option_payment_1_gift_email_payu = sanitize_text_field($_POST['option_payment_1_gift_email_payu_pse']);
    $option_payment_1_gift_name_payu = sanitize_text_field($_POST['option_payment_1_gift_name_payu_pse']);
    $option_payment_1_gift_message_payu = sanitize_text_field($_POST['option_payment_1_gift_message_payu_pse']);
    $option_payment_1_is_gift_payu_string = sanitize_text_field($_POST['option_payment_1_is_gift_payu_pse']);

    $option_payment_1_monthly_payu_string = sanitize_text_field($_POST['option_payment_1_monthly_payu_pse']);

    $option_payment_1_department_pse = sanitize_text_field($_POST['option_payment_1_department_pse']);
    $option_payment_1_city_pse = sanitize_text_field($_POST['option_payment_1_city_pse']);
    $option_payment_1_address_1_pse = sanitize_text_field($_POST['option_payment_1_address_1_pse']);
    $option_payment_1_address_2_pse = sanitize_text_field($_POST['option_payment_1_address_2_pse']);

    $option_payment_1_monthly_payu_bool = false;
    if ($option_payment_1_monthly_payu_string == "1") {
        $option_payment_1_monthly_payu_bool = true;
    } else {
        $option_payment_1_monthly_payu_bool = false;
    }

    $option_payment_1_is_gift_payu_int = intval($option_payment_1_is_gift_payu_string);

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_payment_1_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    $option_payment_1_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_payment_1_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_payment_1_slugCookie])) {
        // Obtener el valor de la cookie
        $option_payment_1_slugCookieValue = $_COOKIE[$option_payment_1_slugCookie];
    }
    //----------------------------------------------------------------------------------------------
    
    $option_payment_1_preSignature = $option_payment_1_ApiKey . '~' . $option_payment_1_merchantId . '~' . $option_payment_1_reference . '~' . $option_payment_1_amount . '~' . 'COP';

    //$option_payment_1_signature = option_payment_1_sha256($option_payment_1_preSignature);
    $option_payment_1_signature = md5($option_payment_1_preSignature);

    //----------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $option_1_timezone = new DateTimeZone('America/Bogota');
    $option_1_date = new DateTime('now', $option_1_timezone);
    $option_1_date_formatted = $option_1_date->format('Y-m-d H:i:s');
    //----------------------------------------------
    $option_1_format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d');
    //----------------------------------------------
    $option_1_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    
    $wpdb->insert(
        $option_1_table_logs,
        array(
            'name' => $option_payment_1_fullName,
            'payment_method' => "PSE",
            'id_type' => $option_payment_1_tipoIdentificacionPayu,
            'id_number' => $option_payment_1_identification,
            'phone_number' => $option_payment_1_contactPhone,
            'email' => $option_payment_1_emailAddress,
            'amount' => $option_payment_1_amount,
            'payment_description' => $option_payment_1_slugCookieValue,
            'date_in' => $option_1_date_formatted,
            'monthly' => "NO",
            'final_result' => "No Aprobada",
            'signature_payu' => $option_payment_1_reference,
            'is_gift' => $option_payment_1_is_gift_payu_int
        ),
        $option_1_format
    );
    //----------------------------------------------
    $option_1_format = array('%s');
    //----------------------------------------------
    $option_1_table_logs = $wpdb->prefix . 'gift_table';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_1_table_logs,
        array(
            'signature_payu' => $option_payment_1_reference,
            'gift_email' => $option_payment_1_gift_email_payu,
            'gift_name' => $option_payment_1_gift_name_payu,
            'gift_message' => $option_payment_1_gift_message_payu
        ),
        $option_1_format
    );
    //----------------------------------------------
    $option_payment_1_table_logs = $wpdb->prefix . 'orders_data';

    $option_1_format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%d');

    $who_receive = $option_payment_1_fullName;
    if ($option_payment_1_is_gift_payu_int == 1){
        $who_receive = $option_payment_1_gift_name_payu;
    }

    $wpdb->insert(
        $option_payment_1_table_logs,
        array(
            'signature_payu' => $option_payment_1_reference,
            'name' => $option_payment_1_fullName,
            'who_receive' => $who_receive,
            'payment_method' => "PSE",
            'id_type' => $option_payment_1_tipoIdentificacionPayu,
            'id_number' => $option_payment_1_identification,
            'phone_number' => $option_payment_1_contactPhone,
            'email' => $option_payment_1_emailAddress,
            'amount' => $option_payment_1_amount,
            'payment_description' => $option_payment_1_slugCookieValue,
            'date_in' => $option_1_date_formatted,
            'department' => $option_payment_1_department_pse,
            'city' => $option_payment_1_city_pse,
            'address_1' => $option_payment_1_address_1_pse,
            'address_2' => $option_payment_1_address_2_pse,
            'payment_made' => 0,
            'order_shipped' => 0,
        ),
        $option_1_format
    );
    //----------------------------------------------
    $option_payment_1_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_payment_1_ApiKey,
            'apiLogin' => $option_payment_1_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_payment_1_accountId,
                'referenceCode' => $option_payment_1_reference,
                'description' => $option_payment_1_reference,
                'language' => 'es',
                'signature' => $option_payment_1_signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($option_payment_1_amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_payment_1_fullName,
                'emailAddress' => $option_payment_1_emailAddress,
                'contactPhone' => $option_payment_1_contactPhone,
                'dniType' => $option_payment_1_tipoIdentificacionPayu,
                'dniNumber' => $option_payment_1_identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $option_payment_1_responseUrl,
                'PSE_REFERENCE1' => $option_payment_1_ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $option_payment_1_nombreBanco_pse,
                'USER_TYPE' => $option_payment_1_person_type_pse,
                'PSE_REFERENCE2' => $option_payment_1_tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $option_payment_1_identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_payment_1_deviceSessionId,
            'ipAddress' => $option_payment_1_ipAddress,
            'cookie' => $option_payment_1_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_payment_1_setTest
    );

    // Convertir datos a formato JSON
    $option_payment_1_json_data = json_encode($option_payment_1_data);

    echo "<script>console.log('".$option_payment_1_json_data."')</script>";

    echo "<script>console.log('---------------------------------')</script>";

    // Configuración de la solicitud cURL
    $option_payment_1_ch = curl_init($option_payment_1_url);
    curl_setopt($option_payment_1_ch, CURLOPT_POST, 1);
    curl_setopt($option_payment_1_ch, CURLOPT_POSTFIELDS, $option_payment_1_json_data);
    curl_setopt($option_payment_1_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_payment_1_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_payment_1_response = curl_exec($option_payment_1_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_payment_1_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_payment_1_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_payment_1_ch);

    // Decodificar la respuesta XML
    $option_payment_1_response_data_xml = simplexml_load_string($option_payment_1_response);

    // Convertir SimpleXMLElement a array
    $option_payment_1_response_data_array = json_decode(json_encode($option_payment_1_response_data_xml), true);

    $option_payment_1_json_result = json_encode($option_payment_1_response_data_array);

    echo "<script>console.log('".$option_payment_1_json_result."')</script>";

    $option_payment_1_array_result = json_decode($option_payment_1_json_result, true);

    if (isset($option_payment_1_array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($option_payment_1_array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['option_payment_1_guardar'])) {
    // Obtener los valores del formulario
    $option_payment_1_monthly_bank = sanitize_text_field($_POST['option_payment_1_monthly_bank']);
    $option_payment_1_monto_form = sanitize_text_field($_POST['option_payment_1_monto_form']);
    $option_payment_1_name = sanitize_text_field($_POST['option_payment_1_nombre']) . ' ' . sanitize_text_field($_POST['option_payment_1_apellido']);
    $option_payment_1_account_type = sanitize_text_field($_POST['option_payment_1_tipoCuenta']);
    $option_payment_1_account_number = sanitize_text_field($_POST['option_payment_1_numeroCuenta']);
    $option_payment_1_bank_name = sanitize_text_field($_POST['option_payment_1_nombreBanco']);
    $option_payment_1_id_type = sanitize_text_field($_POST['option_payment_1_tipoIdentificacion']);
    $option_payment_1_id_number = sanitize_text_field($_POST['option_payment_1_numeroIdentificacion']);
    $option_payment_1_phone_number = sanitize_text_field($_POST['option_payment_1_numeroTelefono']);
    $option_payment_1_email = sanitize_text_field($_POST['option_payment_1_correoElectronico']);
    $option_payment_1_description = sanitize_text_field($_POST['option_payment_1_description_bank']);

    $option_payment_1_gift_email_bank = sanitize_text_field($_POST['option_payment_1_gift_email_bank']);
    $option_payment_1_gift_name_bank = sanitize_text_field($_POST['option_payment_1_gift_name_bank']);
    $option_payment_1_gift_message_bank = sanitize_text_field($_POST['option_payment_1_gift_message_bank']);
    $option_payment_1_is_gift_bank_string = sanitize_text_field($_POST['option_payment_1_is_gift_bank']);

    $option_payment_1_department = sanitize_text_field($_POST['option_payment_1_department_bank']);
    $option_payment_1_city = sanitize_text_field($_POST['option_payment_1_city_bank']);
    $option_payment_1_address_1 = sanitize_text_field($_POST['option_payment_1_address_1_bank']);
    $option_payment_1_address_2 = sanitize_text_field($_POST['option_payment_1_address_2_bank']);

    $option_payment_1_is_gift_bank_bool = false;
    if ($option_payment_1_is_gift_bank_string == "1") {
        $option_payment_1_is_gift_bank_bool = true;
    } else {
        $option_payment_1_is_gift_bank_bool = false;
    }

    $option_payment_1_monthly = "NO";
    if ($option_payment_1_monthly_bank == "1") {
        $option_payment_1_monthly = "SI";
    } else {
        $option_payment_1_monthly = "NO";
    }

    if (strpos($option_payment_1_description, 'delfin') !== false) {
        $option_payment_1_description = "DELFIN DE RIO";
    } elseif (strpos($option_payment_1_description, 'elefantes') !== false) {
        $option_payment_1_description = "ELEFANTES";
    } elseif (strpos($option_payment_1_description, 'jaguar') !== false) {
        $option_payment_1_description = "JAGUAR";
    } elseif (strpos($option_payment_1_description, 'oso-de-anteojos') !== false) {
        $option_payment_1_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_payment_1_description, 'oso-panda') !== false) {
        $option_payment_1_description = "OSO PANDA";
    } elseif (strpos($option_payment_1_description, 'tortuga') !== false) {
        $option_payment_1_description = "TORTUGA MARINA";
    } elseif (strpos($option_payment_1_description, 'apoyanos') !== false) {
        $option_payment_1_description = "DONACION GENERAL";
    } elseif (strpos($option_payment_1_description, 'fondo-incendios') !== false) {
        $option_payment_1_description = "FONDO DE INCENDIOS";
    } else {
        $option_payment_1_description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $option_payment_1_timezone = new DateTimeZone('America/Bogota');
    $option_payment_1_date = new DateTime('now', $option_payment_1_timezone);
    $option_payment_1_date_formatted = $option_payment_1_date->format('Y-m-d H:i:s');

    $option_payment_1_day = $option_payment_1_date->format('d');
    $option_payment_1_month = $option_payment_1_date->format('m');
    $option_payment_1_year = $option_payment_1_date->format('Y');

    $option_payment_1_total_date = $option_payment_1_day . '-' . $option_payment_1_month . '-' . $option_payment_1_year;

    $option_payment_1_format = array('%s');

    $option_payment_1_table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_payment_1_table_name_bank_accounts,
        array(
            'name' => $option_payment_1_name,
            'account_type' => $option_payment_1_account_type,
            'account_number' => $option_payment_1_account_number,
            'bank_name' => $option_payment_1_bank_name,
            'id_type' => $option_payment_1_id_type,
            'id_number' => $option_payment_1_id_number,
            'phone_number' => $option_payment_1_phone_number,
            'email' => $option_payment_1_email,
            'amount' => $option_payment_1_monto_form,
            'date_in' => $option_payment_1_date_formatted,
            'payment_description' => 'Producto: ' . $product_name,
            'monthly' => "NO",
        ),
        $option_payment_1_format
    );

    $inserted_id = $wpdb->insert_id;

    $option_payment_1_donation_data = [$option_payment_1_monthly, $option_payment_1_monto_form, $inserted_id, $option_payment_1_total_date];

    $option_payment_1_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_payment_1_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_payment_1_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_payment_1_nombreCookieValue = $_COOKIE[$option_payment_1_nombreCookie];
    }

    $option_payment_1_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_payment_1_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_payment_1_correoCookie])) {
        // Obtener el valor de la cookie
        $option_payment_1_correoCookieValue = $_COOKIE[$option_payment_1_correoCookie];
    }

    $option_payment_1_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_payment_1_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_payment_1_slugCookie])) {
        // Obtener el valor de la cookie
        $option_payment_1_slugCookieValue = $_COOKIE[$option_payment_1_slugCookie];
    }

    //----------------------------------------------------------------------------
    $option_payment_1_aproved = "";
    $option_payment_1_error = "";

    $option_payment_1_table_urls = $wpdb->prefix . 'urls_store';
    // Consulta SQL para obtener los valores
    $option_payment_1_sql = "SELECT * FROM $option_payment_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_payment_1_results = $wpdb->get_results($option_payment_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_payment_1_results as $option_payment_1_result) {
        $option_payment_1_aproved = $option_payment_1_result->aproved;
        $option_payment_1_error = $option_payment_1_result->error;
    }
    //----------------------------------------------------------------------------

    $option_payment_1_urlRedirect = $option_payment_1_aproved;

    //-----------------------------------------------------------
    $option_payment_1_table_logs = $wpdb->prefix . 'orders_data';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_payment_1_table_logs,
        array(
            'name' => $option_payment_1_name,
            'payment_method' => "Cuenta de banco",
            'id_type' => $option_payment_1_id_type,
            'id_number' => $option_payment_1_id_number,
            'phone_number' => $option_payment_1_phone_number,
            'email' => $option_payment_1_email,
            'amount' => $option_payment_1_monto_form,
            'payment_description' => 'Producto: ' . $product_name,
            'date_in' => $option_payment_1_date_formatted,
            'department' => $option_payment_1_department,
            'city' => $option_payment_1_city,
            'address_1' => $option_payment_1_address_1,
            'address_2' => $option_payment_1_address_2,
            'payment_made' => false,
            'order_shipped' => false,
        ),
        $option_payment_1_format
    );
    //-----------------------------------------------------------
    $inserted_id = $wpdb->insert_id;
    $option_payment_1_donation_data[2] = $inserted_id;

    option_payment_1_enviar_correo($option_payment_1_email, $product_name, $option_payment_1_name, "", "", "", false, "bank_account", $option_payment_1_donation_data);

    echo "<script>window.location.assign('".$option_payment_1_urlRedirect."');</script>";

    //wp_redirect($option_payment_1_urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html_payment/html_option_payment_1.php');

include(plugin_dir_path(__FILE__) . '../css_payment/css_option_payment_1.php');
