<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option_unique/functions_option_unique_1.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState'])) {
    $option_unique_1_aproved = "";
    $option_unique_1_error = "";
    $option_unique_1_pending = "";
    $option_unique_1_expired = "";
    $option_unique_1_delfin_de_rio = "";
    $option_unique_1_elefante = "";
    $option_unique_1_jaguar = "";
    $option_unique_1_oso = "";
    $option_unique_1_oso_panda = "";
    $option_unique_1_tortuga = "";
    $option_unique_1_apoya_la_causa_wwf = "";
    $option_unique_1_fondo_incendios = "";

    $option_unique_1_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_1_sql = "SELECT * FROM $option_unique_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_1_results = $wpdb->get_results($option_unique_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_1_results as $option_unique_1_result) {
        $option_unique_1_aproved = $option_unique_1_result->aproved;
        $option_unique_1_error = $option_unique_1_result->error;
        $option_unique_1_pending = $option_unique_1_result->pending;
        $option_unique_1_expired = $roption_unique_1_esult->expired;
        $option_unique_1_delfin_de_rio = $option_unique_1_result->delfin_de_rio;
        $option_unique_1_elefante = $option_unique_1_result->elefante;
        $option_unique_1_jaguar = $option_unique_1_result->jaguar;
        $option_unique_1_oso = $option_unique_1_result->oso;
        $option_unique_1_oso_panda = $option_unique_1_result->oso_panda;
        $option_unique_1_tortuga = $option_unique_1_result->tortuga;
        $option_unique_1_apoya_la_causa_wwf = $option_unique_1_result->apoya_la_causa_wwf;
        $option_unique_1_fondo_incendios = $option_unique_1_result->fondo_incendios;
    }
    //--------------------------------------------------------------------------
    $signature = sanitize_text_field($_GET['description']);
    $desired_signature = $signature;
    //--------------------------------------------------------------------------
    $table_name_orders_data = $wpdb->prefix . 'orders_data';

    $query = $wpdb->prepare("SELECT * FROM $table_name_orders_data WHERE signature_payu = %s", $desired_signature);
    $row = null;
    $row = $wpdb->get_row($query);
    //--------------------------------------------------------------------------
    if (empty($row)){
        $table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';

        $query = $wpdb->prepare("SELECT * FROM $table_name_bank_accounts_logs WHERE signature_payu = %s", $desired_signature);

        $row = $wpdb->get_row($query);

        $option_unique_1_nombreCookieValue = '';
        $option_unique_1_correoCookieValue = '';
        $option_unique_1_slugCookieValue = '';
        $option_unique_1_monthly_payu_bool = false;
        $option_unique_1_amount = '';
        $option_unique_1_tipoIdentificacionPayu = '';
        $option_unique_1_identification = '';
        $option_unique_1_phone_CookieValue = '';
        $option_unique_1_is_gift_payu_bool = false;

        if (null !== $row){
            $option_unique_1_nombreCookieValue = $row->name;
            $option_unique_1_correoCookieValue = $row->email;
            $option_unique_1_slugCookieValue = $row->payment_description;
            $option_unique_1_amount = $row->amount;
            $option_unique_1_tipoIdentificacionPayu = $row->id_type;
            $option_unique_1_identification = $row->id_number;
            $option_unique_1_phone_CookieValue = $row->phone_number;

            if ($row->is_gift == 1) {
                $option_unique_1_is_gift_payu_bool = true;
            } else {
                $option_unique_1_is_gift_payu_bool = false;
            }
        }
        //--------------------------------------------------------------------------
        $option_unique_1_gift_email_payu = '';
        $option_unique_1_gift_name_payu = '';
        $option_unique_1_gift_message_payu = '';
        if($option_unique_1_is_gift_payu_bool){
            $table_name_gift_table = $wpdb->prefix . 'gift_table';

            $query = $wpdb->prepare("SELECT * FROM $table_name_gift_table WHERE signature_payu = %s", $desired_signature);

            $row = $wpdb->get_row($query);

            if (null !== $row){
                $option_unique_1_gift_email_payu = $row->gift_email;
                $option_unique_1_gift_name_payu = $row->gift_name;
                $option_unique_1_gift_message_payu = $row->gift_message;
            }
        }
        //--------------------------------------------------------------------------
        $option_unique_1_donation_data = array();
        //--------------------------------------------------------------------------
        $option_unique_1_stateValue = sanitize_text_field($_GET['transactionState']);
        //--------------------------------------------------------------------------
        if ($option_unique_1_stateValue == "4" || $option_unique_1_stateValue == 4) {
            $option_unique_1_urlRedirect = $option_unique_1_aproved;
            if (strpos($option_unique_1_slugCookieValue, 'delfin') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_delfin_de_rio;
            } elseif (strpos($option_unique_1_slugCookieValue, 'elefantes') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_elefante;
            } elseif (strpos($option_unique_1_slugCookieValue, 'jaguar') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_jaguar;
            } elseif (strpos($option_unique_1_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_oso;
            } elseif (strpos($option_unique_1_slugCookieValue, 'oso-panda') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_oso_panda;
            } elseif (strpos($option_unique_1_slugCookieValue, 'tortuga') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_tortuga;
            } elseif (strpos($option_unique_1_slugCookieValue, 'apoyanos') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_apoya_la_causa_wwf;
            } elseif (strpos($option_unique_1_slugCookieValue, 'fondo-incendios') !== false) {
                $option_unique_1_urlRedirect = $option_unique_1_fondo_incendios;
            }

            // Obtener la fecha actual en la zona horaria -5
            $option_unique_1_timezone = new DateTimeZone('America/Bogota');
            $option_unique_1_date = new DateTime('now', $option_unique_1_timezone);
            $option_unique_1_date_formatted = $option_unique_1_date->format('Y-m-d H:i:s');

            $option_unique_1_day = $option_unique_1_date->format('d');
            $option_unique_1_month = $option_unique_1_date->format('m');
            $option_unique_1_year = $option_unique_1_date->format('Y');

            $option_unique_1_total_date = $option_unique_1_day . '-' . $option_unique_1_month . '-' . $option_unique_1_year;

            $inserted_id = "";

            $option_unique_1_donation_data = [
                $option_unique_1_monthly_payu_bool,
                $option_unique_1_amount,
                $inserted_id,
                $option_unique_1_total_date,
                $option_unique_1_tipoIdentificacionPayu . ': ' . $option_unique_1_identification
            ];

            option_unique_1_enviar_correo($option_unique_1_correoCookieValue, $option_unique_1_slugCookieValue, $option_unique_1_nombreCookieValue, "", "", "", false, "payu", $option_unique_1_donation_data);

            if ($option_unique_1_is_gift_payu_bool == true) {
                option_unique_1_enviar_correo($option_unique_1_gift_email_payu, $option_unique_1_slugCookieValue, $option_unique_1_gift_name_payu, $option_unique_1_gift_name_payu, $option_unique_1_gift_message_payu, $option_unique_1_gift_email_payu, true, "", false);
            }

            echo "<script>window.location.assign('".$option_unique_1_urlRedirect."');</script>";
            //wp_redirect($option_unique_1_urlRedirect);
        } else {
            echo "<script>window.location.assign('".$option_unique_1_error."');</script>";
            //wp_redirect($option_unique_1_error);
        }

        //----------------------------------------------------------------------------------------
        // Obtener la fecha actual en la zona horaria -5
        $option_unique_1_timezone = new DateTimeZone('America/Bogota');
        $option_unique_1_date = new DateTime('now', $option_unique_1_timezone);
        $option_unique_1_date_formatted = $option_unique_1_date->format('Y-m-d H:i:s');

        $final_status = "No Aprobada";
        if ($option_unique_1_stateValue == "4" || $option_unique_1_stateValue == 4){
            $final_status = "Aprobada";
        }

        $option_unique_1_description = "DONACION GENERAL";
        if (strpos($option_unique_1_slugCookieValue, 'delfin') !== false) {
            $option_unique_1_description = "DELFIN DE RIO";
        } elseif (strpos($option_unique_1_slugCookieValue, 'elefantes') !== false) {
            $option_unique_1_description = "ELEFANTES";
        } elseif (strpos($option_unique_1_slugCookieValue, 'jaguar') !== false) {
            $option_unique_1_description = "JAGUAR";
        } elseif (strpos($option_unique_1_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_unique_1_description = "OSO DE ANTEOJOS";
        } elseif (strpos($option_unique_1_slugCookieValue, 'oso-panda') !== false) {
            $option_unique_1_description = "OSO PANDA";
        } elseif (strpos($option_unique_1_slugCookieValue, 'tortuga') !== false) {
            $option_unique_1_description = "TORTUGA MARINA";
        } elseif (strpos($option_unique_1_slugCookieValue, 'apoyanos') !== false) {
            $option_unique_1_description = "DONACION GENERAL";
        } elseif (strpos($option_unique_1_slugCookieValue, 'fondo-incendios') !== false) {
            $option_unique_1_description = "FONDO DE INCENDIOS";
        } else {
            $option_unique_1_description = "DONACION GENERAL";
        }
        //----------------------------------------------------------------------------------------
        $signature_payu_specific = $signature;

        $new_data = array(
            'payment_description' => $option_unique_1_description,
            'final_result' => $final_status
        );

        $where = array(
            'signature_payu' => $signature_payu_specific
        );

        $data_format = array('%s');
        $where_format = array('%s');

        $updated = $wpdb->update($table_name_bank_accounts_logs, $new_data, $where, $data_format, $where_format);
        //----------------------------------------------------------------------------------------
        exit;
    }
}
//--------------------------------------------------------------------------------------------

// Nombre de la tabla
$option_unique_1_table_name_values = $wpdb->prefix . 'values_unique';

// Consulta SQL para obtener los valores de las filas 1, 2 y 3
$option_unique_1_sql = "SELECT * FROM $option_unique_1_table_name_values WHERE id = 1";

$form_type = "option_unique_1";

$id_to_search = intval(substr($form_type, -1));

$option_unique_1_sql = $wpdb->prepare("SELECT * FROM $option_unique_1_table_name_values WHERE id = %d",$id_to_search);

// Ejecutar la consulta
$option_unique_1_result = $wpdb->get_row($option_unique_1_sql);

// Crear un array asociativo para almacenar los resultados
$option_unique_1_values = array();

if ($option_unique_1_result){
    $option_unique_1_values[1] = $option_unique_1_result->value_1;
    $option_unique_1_values[2] = $option_unique_1_result->value_2;
    $option_unique_1_values[3] = $option_unique_1_result->value_3;
    $option_unique_1_values[4] = $option_unique_1_result->value_1;
    $option_unique_1_values[5] = $option_unique_1_result->value_2;
    $option_unique_1_values[6] = $option_unique_1_result->value_3;
}

// Codificar el array en formato JSON para usarlo en JavaScript
$option_unique_1_values_json = json_encode($option_unique_1_values);

$option_unique_1_timezone = new DateTimeZone('America/Bogota');
$option_unique_1_date = new DateTime('now', $option_unique_1_timezone);
$option_unique_1_reference = $option_unique_1_date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$option_unique_1_cookie = "";
// Nombre de la cookie
$option_unique_1_cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$option_unique_1_cookieName])) {
    // Obtiene el valor de la cookie
    $option_unique_1_cookie = $_COOKIE[$option_unique_1_cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $option_unique_1_cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($option_unique_1_cookieName, '', time() - 3600, '/'); // Borra la cookie
        $option_unique_1_newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($option_unique_1_cookieName, $option_unique_1_newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $option_unique_1_sessionId = session_id();
    setcookie($option_unique_1_cookieName, $option_unique_1_sessionId, time() + 3600, '/');
    $option_unique_1_cookie = $_COOKIE[$option_unique_1_cookieName];
}

$option_unique_1_deviceSessionId = md5($option_unique_1_cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$option_unique_1_table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$option_unique_1_sql = "SELECT * FROM $option_unique_1_table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$option_unique_1_results = $wpdb->get_results($option_unique_1_sql);

// Crear un array asociativo para almacenar los resultados
$option_unique_1_merchantId = "";
$option_unique_1_accountId = "";
$option_unique_1_ApiKey = "";
$option_unique_1_ApiLogin = "";
$option_unique_1_testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($option_unique_1_results as $option_unique_1_result) {
    $option_unique_1_merchantId = $option_unique_1_result->merchantId;
    $option_unique_1_accountId = $option_unique_1_result->accountId;
    $option_unique_1_ApiKey = $option_unique_1_result->apiKey;
    $option_unique_1_ApiLogin = $option_unique_1_result->apiLogin;
    $option_unique_1_testMode = $option_unique_1_result->testMode ? "1" : "0";
}

$option_unique_1_setTest = "";
$option_unique_1_url = "";
$option_unique_1_tokenURL = "";
// URL de la API
if ($option_unique_1_testMode == "1") {
    $option_unique_1_setTest = true;
    $option_unique_1_url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $option_unique_1_tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $option_unique_1_setTest = false;
    $option_unique_1_url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $option_unique_1_tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$option_unique_1_data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $option_unique_1_ApiLogin,
        'apiKey' => $option_unique_1_ApiKey
    ),
    'test' => $option_unique_1_setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$option_unique_1_json_data_bank_list = json_encode($option_unique_1_data_bank_list);

// Configuración de la solicitud cURL
$option_unique_1_ch_bank_list = curl_init($option_unique_1_url);
curl_setopt($option_unique_1_ch_bank_list, CURLOPT_POST, 1);
curl_setopt($option_unique_1_ch_bank_list, CURLOPT_POSTFIELDS, $option_unique_1_json_data_bank_list);
curl_setopt($option_unique_1_ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($option_unique_1_ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$option_unique_1_response_bank_list = curl_exec($option_unique_1_ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($option_unique_1_ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($option_unique_1_ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($option_unique_1_ch_bank_list);

// Decodificar la respuesta XML
$option_unique_1_response_data_bank_list_xml = simplexml_load_string($option_unique_1_response_bank_list);

// Convertir SimpleXMLElement a array
$option_unique_1_response_data_bank_list_array = json_decode(json_encode($option_unique_1_response_data_bank_list_xml), true);

$option_unique_1_json_result_bank_list = json_encode($option_unique_1_response_data_bank_list_array);

$option_unique_1_array_result_bank_list = json_decode($option_unique_1_json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($option_unique_1_array_result_bank_list['banks']['bank']) && is_array($option_unique_1_array_result_bank_list['banks']['bank'])) {
    foreach ($option_unique_1_array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['option_unique_1_payu'])) {
    $option_unique_1_amount = sanitize_text_field($_POST['option_unique_1_amount']);
    //$reference = 'abcde475674675';
    $option_unique_1_reference = sanitize_text_field($_POST['option_unique_1_referenceCode']);
    $option_unique_1_description = sanitize_text_field($_POST['option_unique_1_description']);
    $option_unique_1_notifyUrl = sanitize_text_field($_POST['option_unique_1_responseUrl']);
    $option_unique_1_fullName = sanitize_text_field($_POST['option_unique_1_payerFullName']) . ' ' . sanitize_text_field($_POST['option_unique_1_payerLastName']);

    $option_unique_1_tipoIdentificacionPayu = sanitize_text_field($_POST['option_unique_1_tipoIdentificacionPayu']);

    $option_unique_1_emailAddress = sanitize_text_field($_POST['option_unique_1_buyerEmail']);
    $option_unique_1_contactPhone = sanitize_text_field($_POST['option_unique_1_payerPhone']);
    $option_unique_1_creditCardNumber = sanitize_text_field($_POST['option_unique_1_card_number']);
    $option_unique_1_creditCardSecurityCode = sanitize_text_field($_POST['option_unique_1_cvv_card']);
    $option_unique_1_creditCardExpirationDate = sanitize_text_field($_POST['option_unique_1_expiration_year']) . '/' . sanitize_text_field($_POST['option_unique_1_expiration_month']);
    $option_unique_1_creditCardName = $option_unique_1_fullName;
    $option_unique_1_paymentMethod = sanitize_text_field($_POST['option_unique_1_payment_method_1']);
    $option_unique_1_identification = sanitize_text_field($_POST['option_unique_1_numeroIdentificacionPayu']);

    $option_unique_1_gift_email_payu = sanitize_text_field($_POST['option_unique_1_gift_email_payu']);
    $option_unique_1_gift_name_payu = sanitize_text_field($_POST['option_unique_1_gift_name_payu']);
    $option_unique_1_gift_message_payu = sanitize_text_field($_POST['option_unique_1_gift_message_payu']);
    $option_unique_1_is_gift_payu_string = sanitize_text_field($_POST['option_unique_1_is_gift_payu']);

    $option_unique_1_monthly_payu_string = sanitize_text_field($_POST['option_unique_1_monthly_payu']);

    $option_unique_1_monthly_payu_bool = false;
    if ($option_unique_1_monthly_payu_string == "1") {
        $option_unique_1_monthly_payu_bool = true;
    } else {
        $option_unique_1_monthly_payu_bool = false;
    }

    $option_unique_1_is_gift_payu_bool = false;
    if ($option_unique_1_is_gift_payu_string == "1") {
        $option_unique_1_is_gift_payu_bool = true;
    } else {
        $option_unique_1_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_unique_1_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($option_unique_1_monthly_payu_bool == true) {
        $option_unique_1_tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $option_unique_1_ApiLogin,
                "apiKey" => $option_unique_1_ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $option_unique_1_identification,
                "name" => $option_unique_1_fullName,
                "identificationNumber" => $option_unique_1_identification,
                "paymentMethod" => $option_unique_1_paymentMethod,
                "number" => $option_unique_1_creditCardNumber,
                "expirationDate" => $option_unique_1_creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $option_unique_1_json_data = json_encode($option_unique_1_tokenData);

        // Configuración de la solicitud cURL
        $option_unique_1_ch = curl_init($option_unique_1_tokenURL);
        curl_setopt($option_unique_1_ch, CURLOPT_POST, 1);
        curl_setopt($option_unique_1_ch, CURLOPT_POSTFIELDS, $option_unique_1_json_data);
        curl_setopt($option_unique_1_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($option_unique_1_ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $option_unique_1_response = curl_exec($option_unique_1_ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($option_unique_1_ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($option_unique_1_ch);
        }

        // Cerrar la conexión cURL
        curl_close($option_unique_1_ch);

        // Decodificar la respuesta XML
        $option_unique_1_response_data_xml = simplexml_load_string($option_unique_1_response);

        // Convertir SimpleXMLElement a array
        $option_unique_1_response_data_array = json_decode(json_encode($option_unique_1_response_data_xml), true);

        $option_unique_1_json_result = json_encode($option_unique_1_response_data_array);

        $option_unique_1_array_result = json_decode($option_unique_1_json_result, true);

        $option_unique_1_creditCardToken = "";
        if ($option_unique_1_array_result['creditCardToken']['creditCardTokenId']) {
            $option_unique_1_creditCardToken = $option_unique_1_array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($option_unique_1_creditCardToken != "") {

            $option_unique_1_format = array('%s');

            $option_unique_1_table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $option_unique_1_table_name_token,
                array(
                    'document' => $option_unique_1_identification,
                    'token_card' => $option_unique_1_creditCardToken,
                    'amount_to_discount' => $option_unique_1_amount,
                    'discount_day' => date('d'),
                    'payer_name' => $option_unique_1_fullName,
                    'phone_number' => $option_unique_1_contactPhone,
                    'payer_email' => $option_unique_1_emailAddress,
                    'cvv_card' => $option_unique_1_creditCardSecurityCode,
                    'paymentMethod' => $option_unique_1_paymentMethod
                ),
                $option_unique_1_format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $option_unique_1_preSignature = $option_unique_1_ApiKey . '~' . $option_unique_1_merchantId . '~' . $option_unique_1_reference . '~' . $option_unique_1_amount . '~' . 'COP';

    $option_unique_1_signature = option_unique_1_sha256($option_unique_1_preSignature);

    //----------------------------------------------

    $option_unique_1_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_unique_1_ApiKey,
            'apiLogin' => $option_unique_1_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_unique_1_accountId,
                'referenceCode' => $option_unique_1_reference,
                'description' => $option_unique_1_description,
                'language' => 'es',
                'signature' => $option_unique_1_signature,
                'notifyUrl' => $option_unique_1_notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $option_unique_1_amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_unique_1_fullName,
                'emailAddress' => $option_unique_1_emailAddress,
                'contactPhone' => $option_unique_1_contactPhone
            ),
            'creditCard' => array(
                'number' => $option_unique_1_creditCardNumber,
                'securityCode' => $option_unique_1_creditCardSecurityCode,
                'expirationDate' => $option_unique_1_creditCardExpirationDate,
                'name' => $option_unique_1_creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $option_unique_1_paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_unique_1_deviceSessionId,
            'ipAddress' => $option_unique_1_ipAddress,
            'cookie' => $option_unique_1_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_unique_1_setTest
    );

    // Convertir datos a formato JSON
    $option_unique_1_json_data = json_encode($option_unique_1_data);

    // Configuración de la solicitud cURL
    $option_unique_1_ch = curl_init($option_unique_1_url);
    curl_setopt($option_unique_1_ch, CURLOPT_POST, 1);
    curl_setopt($option_unique_1_ch, CURLOPT_POSTFIELDS, $option_unique_1_json_data);
    curl_setopt($option_unique_1_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_unique_1_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_unique_1_response = curl_exec($option_unique_1_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_unique_1_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_unique_1_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_unique_1_ch);

    // Decodificar la respuesta XML
    $option_unique_1_response_data_xml = simplexml_load_string($option_unique_1_response);

    // Convertir SimpleXMLElement a array
    $option_unique_1_response_data_array = json_decode(json_encode($option_unique_1_response_data_xml), true);

    $option_unique_1_json_result = json_encode($option_unique_1_response_data_array);

    $option_unique_1_array_result = json_decode($option_unique_1_json_result, true);

    $option_unique_1_stateValue = $option_unique_1_array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $option_unique_1_aproved = "";
    $option_unique_1_error = "";
    $option_unique_1_pending = "";
    $option_unique_1_expired = "";
    $option_unique_1_delfin_de_rio = "";
    $option_unique_1_elefante = "";
    $option_unique_1_jaguar = "";
    $option_unique_1_oso = "";
    $option_unique_1_oso_panda = "";
    $option_unique_1_tortuga = "";
    $option_unique_1_apoya_la_causa_wwf = "";
    $option_unique_1_fondo_incendios = "";

    $option_unique_1_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_1_sql = "SELECT * FROM $option_unique_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_1_results = $wpdb->get_results($option_unique_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_1_results as $option_unique_1_result) {
        $option_unique_1_aproved = $option_unique_1_result->aproved;
        $option_unique_1_error = $option_unique_1_result->error;
        $option_unique_1_pending = $option_unique_1_result->pending;
        $option_unique_1_expired = $roption_unique_1_esult->expired;
        $option_unique_1_delfin_de_rio = $option_unique_1_result->delfin_de_rio;
        $option_unique_1_elefante = $option_unique_1_result->elefante;
        $option_unique_1_jaguar = $option_unique_1_result->jaguar;
        $option_unique_1_oso = $option_unique_1_result->oso;
        $option_unique_1_oso_panda = $option_unique_1_result->oso_panda;
        $option_unique_1_tortuga = $option_unique_1_result->tortuga;
        $option_unique_1_apoya_la_causa_wwf = $option_unique_1_result->apoya_la_causa_wwf;
        $option_unique_1_fondo_incendios = $option_unique_1_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_unique_1_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_unique_1_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_1_slugCookie])) {
        // Obtener el valor de la cookie
        $option_unique_1_slugCookieValue = $_COOKIE[$option_unique_1_slugCookie];
    }

    if ($option_unique_1_stateValue == "APPROVED") {

        $option_unique_1_nombreCookie = "proyecto_donaciones_colombia_nombre";
        $option_unique_1_nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_unique_1_nombreCookie])) {
            // Obtener el valor de la cookie
            $option_unique_1_nombreCookieValue = $_COOKIE[$option_unique_1_nombreCookie];
        }

        $option_unique_1_correoCookie = "proyecto_donaciones_colombia_correo";
        $option_unique_1_correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_unique_1_correoCookie])) {
            // Obtener el valor de la cookie
            $option_unique_1_correoCookieValue = $_COOKIE[$option_unique_1_correoCookie];
        }

        $option_unique_1_urlRedirect = $option_unique_1_aproved;
        if (strpos($option_unique_1_slugCookieValue, 'delfin') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_delfin_de_rio;
        } elseif (strpos($option_unique_1_slugCookieValue, 'elefantes') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_elefante;
        } elseif (strpos($option_unique_1_slugCookieValue, 'jaguar') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_jaguar;
        } elseif (strpos($option_unique_1_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_oso;
        } elseif (strpos($option_unique_1_slugCookieValue, 'oso-panda') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_oso_panda;
        } elseif (strpos($option_unique_1_slugCookieValue, 'tortuga') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_tortuga;
        } elseif (strpos($option_unique_1_slugCookieValue, 'apoyanos') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_apoya_la_causa_wwf;
        } elseif (strpos($option_unique_1_slugCookieValue, 'fondo-incendios') !== false) {
            $option_unique_1_urlRedirect = $option_unique_1_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_unique_1_timezone = new DateTimeZone('America/Bogota');
        $option_unique_1_date = new DateTime('now', $option_unique_1_timezone);
        $option_unique_1_date_formatted = $option_unique_1_date->format('Y-m-d H:i:s');

        $option_unique_1_day = $option_unique_1_date->format('d');
        $option_unique_1_month = $option_unique_1_date->format('m');
        $option_unique_1_year = $option_unique_1_date->format('Y');

        $option_unique_1_total_date = $option_unique_1_day . '-' . $option_unique_1_month . '-' . $option_unique_1_year;

        $inserted_id = $wpdb->insert_id;

        $option_unique_1_donation_data = [$option_unique_1_monthly_payu_bool, $option_unique_1_amount, $inserted_id, $option_unique_1_total_date, $option_unique_1_tipoIdentificacionPayu . ': ' . $option_unique_1_identification];

        option_unique_1_enviar_correo($option_unique_1_emailAddress, $option_unique_1_slugCookieValue, $option_unique_1_fullName, "", "", "", false, "payu", $option_unique_1_donation_data);

        if ($option_unique_1_is_gift_payu_bool == true) {
            option_unique_1_enviar_correo($option_unique_1_gift_email_payu, $option_unique_1_slugCookieValue, $option_unique_1_gift_name_payu, $option_unique_1_gift_name_payu, $option_unique_1_gift_message_payu, $option_unique_1_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_unique_1_urlRedirect."');</script>";
        //wp_redirect($option_unique_1_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_unique_1_error."');</script>";
        //wp_redirect($option_unique_1_error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $option_unique_1_timezone = new DateTimeZone('America/Bogota');
    $option_unique_1_date = new DateTime('now', $option_unique_1_timezone);
    $option_unique_1_date_formatted = $option_unique_1_date->format('Y-m-d H:i:s');

    $option_unique_1_monthly = "NO";
    if($option_unique_1_monthly_payu_bool){
        $option_unique_1_monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($option_unique_1_stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($option_unique_1_slugCookieValue, 'delfin') !== false) {
        $option_unique_1_description = "DELFIN DE RIO";
    } elseif (strpos($option_unique_1_slugCookieValue, 'elefantes') !== false) {
        $option_unique_1_description = "ELEFANTES";
    } elseif (strpos($option_unique_1_slugCookieValue, 'jaguar') !== false) {
        $option_unique_1_description = "JAGUAR";
    } elseif (strpos($option_unique_1_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_unique_1_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_unique_1_slugCookieValue, 'oso-panda') !== false) {
        $option_unique_1_description = "OSO PANDA";
    } elseif (strpos($option_unique_1_slugCookieValue, 'tortuga') !== false) {
        $option_unique_1_description = "TORTUGA MARINA";
    } elseif (strpos($option_unique_1_slugCookieValue, 'apoyanos') !== false) {
        $option_unique_1_description = "DONACION GENERAL";
    } elseif (strpos($option_unique_1_slugCookieValue, 'fondo-incendios') !== false) {
        $option_unique_1_description = "FONDO DE INCENDIOS";
    } else {
        $option_unique_1_description = "DONACION GENERAL";
    }

    $option_unique_1_format = array('%s');

    $option_unique_1_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_unique_1_table_logs,
        array(
            'name' => $option_unique_1_fullName,
            'payment_method' => "PAYU",
            'id_type' => $option_unique_1_tipoIdentificacionPayu,
            'id_number' => $option_unique_1_identification,
            'phone_number' => $option_unique_1_contactPhone,
            'email' => $option_unique_1_emailAddress,
            'amount' => $option_unique_1_amount,
            'payment_description' => $option_unique_1_description,
            'date_in' => $option_unique_1_date_formatted,
            'monthly' => "NO",
            'final_result' => $final_status
        ),
        $option_unique_1_format
    );

    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['option_unique_1_payu_pse'])) {
    $option_unique_1_person_type_pse = sanitize_text_field($_POST['option_unique_1_person_type_pse']);
    $option_unique_1_nombreBanco_pse = sanitize_text_field($_POST['option_unique_1_nombreBanco_pse']);
    $option_unique_1_amount = sanitize_text_field($_POST['option_unique_1_amount_pse']);
    //$reference = 'abcde475674675';
    $option_unique_1_reference = sanitize_text_field($_POST['option_unique_1_referenceCode_pse']);
    $option_unique_1_description = sanitize_text_field($_POST['option_unique_1_description_pse']);
    $option_unique_1_responseUrl = sanitize_text_field($_POST['option_unique_1_responseUrl_pse']);
    $option_unique_1_fullName = sanitize_text_field($_POST['option_unique_1_payerFullName_pse']) . ' ' . sanitize_text_field($_POST['option_unique_1_payerLastName_pse']);

    $option_unique_1_tipoIdentificacionPayu = sanitize_text_field($_POST['option_unique_1_tipoIdentificacionPayu_pse']);

    $option_unique_1_emailAddress = sanitize_text_field($_POST['option_unique_1_buyerEmail_pse']);
    $option_unique_1_contactPhone = sanitize_text_field($_POST['option_unique_1_payerPhone_pse']);
    $option_unique_1_identification = sanitize_text_field($_POST['option_unique_1_numeroIdentificacionPayu_pse']);

    $option_unique_1_gift_email_payu = sanitize_text_field($_POST['option_unique_1_gift_email_payu_pse']);
    $option_unique_1_gift_name_payu = sanitize_text_field($_POST['option_unique_1_gift_name_payu_pse']);
    $option_unique_1_gift_message_payu = sanitize_text_field($_POST['option_unique_1_gift_message_payu_pse']);
    $option_unique_1_is_gift_payu_string = sanitize_text_field($_POST['option_unique_1_is_gift_payu_pse']);

    $option_unique_1_monthly_payu_string = sanitize_text_field($_POST['option_unique_1_monthly_payu_pse']);

    $option_unique_1_monthly_payu_bool = false;
    if ($option_unique_1_monthly_payu_string == "1") {
        $option_unique_1_monthly_payu_bool = true;
    } else {
        $option_unique_1_monthly_payu_bool = false;
    }

    $option_unique_1_is_gift_payu_int = intval($option_unique_1_is_gift_payu_string);

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_unique_1_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------

    $option_unique_1_preSignature = $option_unique_1_ApiKey . '~' . $option_unique_1_merchantId . '~' . $option_unique_1_reference . '~' . $option_unique_1_amount . '~' . 'COP';

    //$option_unique_1_signature = option_unique_1_sha256($option_unique_1_preSignature);
    $option_unique_1_signature = md5($option_unique_1_preSignature);

    //----------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $option_1_timezone = new DateTimeZone('America/Bogota');
    $option_1_date = new DateTime('now', $option_1_timezone);
    $option_1_date_formatted = $option_1_date->format('Y-m-d H:i:s');
    //----------------------------------------------
    $option_1_format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d');
    //----------------------------------------------
    $option_1_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_1_table_logs,
        array(
            'name' => $option_unique_1_fullName,
            'payment_method' => "PSE",
            'id_type' => $option_unique_1_tipoIdentificacionPayu,
            'id_number' => $option_unique_1_identification,
            'phone_number' => $option_unique_1_contactPhone,
            'email' => $option_unique_1_emailAddress,
            'amount' => $option_unique_1_amount,
            'payment_description' => $option_unique_1_reference,
            'date_in' => $option_1_date_formatted,
            'monthly' => "NO",
            'final_result' => "No Aprobada",
            'signature_payu' => $option_unique_1_reference,
            'is_gift' => $option_unique_1_is_gift_payu_int
        ),
        $option_1_format
    );
    //----------------------------------------------    
    $option_1_format = array('%s');
    //----------------------------------------------
    $option_1_table_logs = $wpdb->prefix . 'gift_table';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_1_table_logs,
        array(
            'signature_payu' => $option_unique_1_reference,
            'gift_email' => $option_unique_1_gift_email_payu,
            'gift_name' => $option_unique_1_gift_name_payu,
            'gift_message' => $option_unique_1_gift_message_payu
        ),
        $option_1_format
    );
    //----------------------------------------------

    $option_unique_1_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_unique_1_ApiKey,
            'apiLogin' => $option_unique_1_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_unique_1_accountId,
                'referenceCode' => $option_unique_1_reference,
                'description' => $option_unique_1_reference,
                'language' => 'es',
                'signature' => $option_unique_1_signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($option_unique_1_amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_unique_1_fullName,
                'emailAddress' => $option_unique_1_emailAddress,
                'contactPhone' => $option_unique_1_contactPhone,
                'dniType' => $option_unique_1_tipoIdentificacionPayu,
                'dniNumber' => $option_unique_1_identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $option_unique_1_responseUrl,
                'PSE_REFERENCE1' => $option_unique_1_ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $option_unique_1_nombreBanco_pse,
                'USER_TYPE' => $option_unique_1_person_type_pse,
                'PSE_REFERENCE2' => $option_unique_1_tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $option_unique_1_identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_unique_1_deviceSessionId,
            'ipAddress' => $option_unique_1_ipAddress,
            'cookie' => $option_unique_1_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_unique_1_setTest
    );

    // Convertir datos a formato JSON
    $option_unique_1_json_data = json_encode($option_unique_1_data);

    echo "<script>console.log('".$option_unique_1_json_data."')</script>";

    echo "<script>console.log('---------------------------------')</script>";

    // Configuración de la solicitud cURL
    $option_unique_1_ch = curl_init($option_unique_1_url);
    curl_setopt($option_unique_1_ch, CURLOPT_POST, 1);
    curl_setopt($option_unique_1_ch, CURLOPT_POSTFIELDS, $option_unique_1_json_data);
    curl_setopt($option_unique_1_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_unique_1_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_unique_1_response = curl_exec($option_unique_1_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_unique_1_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_unique_1_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_unique_1_ch);

    // Decodificar la respuesta XML
    $option_unique_1_response_data_xml = simplexml_load_string($option_unique_1_response);

    // Convertir SimpleXMLElement a array
    $option_unique_1_response_data_array = json_decode(json_encode($option_unique_1_response_data_xml), true);

    $option_unique_1_json_result = json_encode($option_unique_1_response_data_array);

    echo "<script>console.log('".$option_unique_1_json_result."')</script>";

    $option_unique_1_array_result = json_decode($option_unique_1_json_result, true);

    if (isset($option_unique_1_array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($option_unique_1_array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['option_unique_1_guardar'])) {
    // Obtener los valores del formulario
    $option_unique_1_monthly_bank = sanitize_text_field($_POST['option_unique_1_monthly_bank']);
    $option_unique_1_monto_form = sanitize_text_field($_POST['option_unique_1_monto_form']);
    $option_unique_1_name = sanitize_text_field($_POST['option_unique_1_nombre']) . ' ' . sanitize_text_field($_POST['option_unique_1_apellido']);
    $option_unique_1_account_type = sanitize_text_field($_POST['option_unique_1_tipoCuenta']);
    $option_unique_1_account_number = sanitize_text_field($_POST['option_unique_1_numeroCuenta']);
    $option_unique_1_bank_name = sanitize_text_field($_POST['option_unique_1_nombreBanco']);
    $option_unique_1_id_type = sanitize_text_field($_POST['option_unique_1_tipoIdentificacion']);
    $option_unique_1_id_number = sanitize_text_field($_POST['option_unique_1_numeroIdentificacion']);
    $option_unique_1_phone_number = sanitize_text_field($_POST['option_unique_1_numeroTelefono']);
    $option_unique_1_email = sanitize_text_field($_POST['option_unique_1_correoElectronico']);
    $option_unique_1_description = sanitize_text_field($_POST['option_unique_1_description_bank']);

    $option_unique_1_gift_email_bank = sanitize_text_field($_POST['option_unique_1_gift_email_bank']);
    $option_unique_1_gift_name_bank = sanitize_text_field($_POST['option_unique_1_gift_name_bank']);
    $option_unique_1_gift_message_bank = sanitize_text_field($_POST['option_unique_1_gift_message_bank']);
    $option_unique_1_is_gift_bank_string = sanitize_text_field($_POST['option_unique_1_is_gift_bank']);

    $option_unique_1_is_gift_bank_bool = false;
    if ($option_unique_1_is_gift_bank_string == "1") {
        $option_unique_1_is_gift_bank_bool = true;
    } else {
        $option_unique_1_is_gift_bank_bool = false;
    }

    $option_unique_1_monthly = "NO";
    if ($option_unique_1_monthly_bank == "1") {
        $option_unique_1_monthly = "SI";
    } else {
        $option_unique_1_monthly = "NO";
    }

    if (strpos($option_unique_1_description, 'delfin') !== false) {
        $option_unique_1_description = "DELFIN DE RIO";
    } elseif (strpos($option_unique_1_description, 'elefantes') !== false) {
        $option_unique_1_description = "ELEFANTES";
    } elseif (strpos($option_unique_1_description, 'jaguar') !== false) {
        $option_unique_1_description = "JAGUAR";
    } elseif (strpos($option_unique_1_description, 'oso-de-anteojos') !== false) {
        $option_unique_1_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_unique_1_description, 'oso-panda') !== false) {
        $option_unique_1_description = "OSO PANDA";
    } elseif (strpos($option_unique_1_description, 'tortuga') !== false) {
        $option_unique_1_description = "TORTUGA MARINA";
    } elseif (strpos($option_unique_1_description, 'apoyanos') !== false) {
        $option_unique_1_description = "DONACION GENERAL";
    } elseif (strpos($option_unique_1_description, 'fondo-incendios') !== false) {
        $option_unique_1_description = "FONDO DE INCENDIOS";
    } else {
        $option_unique_1_description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $option_unique_1_timezone = new DateTimeZone('America/Bogota');
    $option_unique_1_date = new DateTime('now', $option_unique_1_timezone);
    $option_unique_1_date_formatted = $option_unique_1_date->format('Y-m-d H:i:s');

    $option_unique_1_day = $option_unique_1_date->format('d');
    $option_unique_1_month = $option_unique_1_date->format('m');
    $option_unique_1_year = $option_unique_1_date->format('Y');

    $option_unique_1_total_date = $option_unique_1_day . '-' . $option_unique_1_month . '-' . $option_unique_1_year;

    $option_unique_1_format = array('%s');

    $option_unique_1_table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_unique_1_table_name_bank_accounts,
        array(
            'name' => $option_unique_1_name,
            'account_type' => $option_unique_1_account_type,
            'account_number' => $option_unique_1_account_number,
            'bank_name' => $option_unique_1_bank_name,
            'id_type' => $option_unique_1_id_type,
            'id_number' => $option_unique_1_id_number,
            'phone_number' => $option_unique_1_phone_number,
            'email' => $option_unique_1_email,
            'amount' => $option_unique_1_monto_form,
            'date_in' => $option_unique_1_date_formatted,
            'payment_description' => $option_unique_1_description,
            'monthly' => "NO",
        ),
        $option_unique_1_format
    );

    $inserted_id = $wpdb->insert_id;

    $option_unique_1_donation_data = [$option_unique_1_monthly, $option_unique_1_monto_form, $inserted_id, $option_unique_1_total_date];

    $option_unique_1_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_unique_1_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_1_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_unique_1_nombreCookieValue = $_COOKIE[$option_unique_1_nombreCookie];
    }

    $option_unique_1_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_unique_1_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_1_correoCookie])) {
        // Obtener el valor de la cookie
        $option_unique_1_correoCookieValue = $_COOKIE[$option_unique_1_correoCookie];
    }

    $option_unique_1_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_unique_1_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_1_slugCookie])) {
        // Obtener el valor de la cookie
        $option_unique_1_slugCookieValue = $_COOKIE[$option_unique_1_slugCookie];
    }

    //----------------------------------------------------------------------------
    $option_unique_1_aproved = "";
    $option_unique_1_error = "";
    $option_unique_1_pending = "";
    $option_unique_1_expired = "";
    $option_unique_1_delfin_de_rio = "";
    $option_unique_1_elefante = "";
    $option_unique_1_jaguar = "";
    $option_unique_1_oso = "";
    $option_unique_1_oso_panda = "";
    $option_unique_1_tortuga = "";
    $option_unique_1_apoya_la_causa_wwf = "";
    $option_unique_1_fondo_incendios = "";

    $option_unique_1_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_1_sql = "SELECT * FROM $option_unique_1_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_1_results = $wpdb->get_results($option_unique_1_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_1_results as $option_unique_1_result) {
        $option_unique_1_aproved = $option_unique_1_result->aproved;
        $option_unique_1_error = $option_unique_1_result->error;
        $option_unique_1_pending = $option_unique_1_result->pending;
        $option_unique_1_expired = $option_unique_1_result->expired;
        $option_unique_1_delfin_de_rio = $option_unique_1_result->delfin_de_rio;
        $option_unique_1_elefante = $option_unique_1_result->elefante;
        $option_unique_1_jaguar = $option_unique_1_result->jaguar;
        $option_unique_1_oso = $option_unique_1_result->oso;
        $option_unique_1_oso_panda = $option_unique_1_result->oso_panda;
        $option_unique_1_tortuga = $option_unique_1_result->tortuga;
        $option_unique_1_apoya_la_causa_wwf = $option_unique_1_result->apoya_la_causa_wwf;
        $option_unique_1_fondo_incendios = $option_unique_1_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_unique_1_urlRedirect = $option_unique_1_aproved;
    if (strpos($option_unique_1_slugCookieValue, 'delfin') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_delfin_de_rio;
    } elseif (strpos($option_unique_1_slugCookieValue, 'elefantes') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_elefante;
    } elseif (strpos($option_unique_1_slugCookieValue, 'jaguar') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_jaguar;
    } elseif (strpos($option_unique_1_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_oso;
    } elseif (strpos($option_unique_1_slugCookieValue, 'oso-panda') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_oso_panda;
    } elseif (strpos($option_unique_1_slugCookieValue, 'tortuga') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_tortuga;
    } elseif (strpos($option_unique_1_slugCookieValue, 'apoyanos') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_apoya_la_causa_wwf;
    } elseif (strpos($option_unique_1_slugCookieValue, 'fondo-incendios') !== false) {
        $option_unique_1_urlRedirect = $option_unique_1_fondo_incendios;
    }

    option_unique_1_enviar_correo($option_unique_1_email, $option_unique_1_slugCookieValue, $option_unique_1_name, "", "", "", false, "bank_account", $option_unique_1_donation_data);

    if ($option_unique_1_is_gift_bank_bool == true) {
        option_unique_1_enviar_correo($option_unique_1_gift_email_bank, $option_unique_1_slugCookieValue, $option_unique_1_gift_name_bank, $option_unique_1_gift_name_bank, $option_unique_1_gift_message_bank, $option_unique_1_gift_email_bank, true, "", false);
    }

    echo "<script>window.location.assign('".$option_unique_1_urlRedirect."');</script>";

    //wp_redirect($option_unique_1_urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html_unique/html_option_unique_1.php');

include(plugin_dir_path(__FILE__) . '../css_unique/css_option_unique_1.php');
