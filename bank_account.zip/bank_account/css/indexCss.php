<style>
input {
    margin: 5px 0px 0px 0px;
}

div#video-form video {
    height: 150px;
    object-fit: cover;
    border-radius: 15px;
}
.grid-2col{
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    width: 100%;
}

.container-steps .botones a{
border: 1px solid #000;
    padding: .2em .5em;
    border-radius: 50%;
    cursor: pointer;
}
.container-steps .botones a:hover {
    color: #fcbb29;
    border-color: #fcbb29;
}

.buttonContainer.tabs {
    position: relative;
    gap: 0;
    margin-bottom: 15px;
    border-radius: 20px;
    border: 1px solid #00000069;
}
.buttonContainer.tabs .content-tab {
    width: 100%;
    position: relative;
}
.buttonContainer,
.formButtonContainer {
    display: flex;
    justify-content: center;
    align-items: center;
}

.buttonContainer {
    flex-direction: row;
    align-items: flex-end;
    gap: 5px;
}

.formButtonContainer {
    flex-direction: column;
    margin-block-start: 0rem;
}
.formButton:hover,
.saveButton:hover {
    background-color: #8fef6c;
}
.formContainer,
.formContainer4 {
    justify-content: center;
    align-items: center;
    flex-direction: column;
    text-align: center;
    margin-top: 0px;
    line-height: 1;
}

.formContainer4 {
    display: flex;
    animation: slideDown 0.5s;
}

.formContainer form,
.formContainer4 form {
    background-color: white;
    color: black;
    border-radius: 12px;
    margin: 0px;
    font-size: 15px;
    padding: 0px;
    line-height: 1;
}


.otroValor {
    width: 90% !important;
    margin: 0 !important;
}
.divisor{
    width:100%;
    height:1px;
    background: rgb(199 199 199 / 48%);
    margin: 12px 0;
}

.contForm-nombre, .contForm-tarjerta{
    display: flex;
    gap: 13px;
    justify-content: center;
}
.contForm-tarjerta input{
    width: 33%;
}
.contForm-nombre input {
    width: 50%;
}
.checkbox-T\&C {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 10px;
}

h5.titulos-form {
    font-family: "WWF", sans-serif !important;
    font-size:22px;
    text-align:center;
    margin:0;
}
.text-pasos h3 {
    font-family: "WWF", Sans-serif;
    font-size: 22px;
    font-weight: 400;
    margin: 0;
    text-align:center;
    color: #000;
}
h3.titular{
    font-family: "WWF", Sans-serif;
    font-size: 25px;
    font-weight: 400;
}
.fav {
    text-align: center;
    background: #FFF3D7;
    border: 2px dotted #FCBB29;
    border-radius: 20px;
    padding: 5px;
}
.fav span {
    font-family: Open Sans;
    font-size: 11px;
    font-weight: 700;
    color: #D29A1A;
}
.titulo-form-2 h5.titulos-form {
    margin-left: -50px;
}
.titulo-form-2{
    display:grid;
    grid-template-columns: 100%;
    justify-content: center;
    align-items: center;
}
label.politicas {
    font-weight: 600;
    text-align: left;
    font-size: 0.8rem;
}
label.politicas a{
    text-decoration: underline;
    color: #000;
    font-family: Open Sans;
}
h5.info {
    font-family: Open Sans;
    text-align: left;
    color: #000;
   font-weight: 700;
    font-size: 16px;
    padding: 0 10px;
    margin: 10px 0;
}
h5.info span {
    color:#1257BE;
    font-weight: 700;
}

.formButton,
.saveButton {
    min-width:150px;
    width:100%;
    background-color: #7cde00;
    color: black;
    font-size: 25px;
}
.formButton.active,
.saveButton.active {
    background-color: #6fb300;
    color: black;
    border: 1px solid lightgrey;
}

/*--------------------------------Botones--------------------------------------*/
.donation-options {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.donation-button {
  background-color: #ffffff; /* Botón de fondo blanco */
  color: #333333; /* Texto oscuro para contraste */
  border: 2px solid #cccccc; /* Borde sólido de color gris claro */
  border-radius: 20px; /* Bordes redondeados para estilo de píldora */
  padding: 10px 20px; /* Relleno horizontal y vertical */
  font-size: 16px; /* Tamaño de fuente legible */
  cursor: pointer; /* Cursor de mano para indicar que es un botón */
  margin-right: 10px; /* Espacio entre los botones */
  transition: background-color 0.3s, color 0.3s; /* Transición suave para efectos de hover */
}

.donation-button:last-child {
  margin-right: 0; /* No hay margen a la derecha del último botón */
}

.donation-button:hover {
  background-color: #f5f5f5; /* Color de fondo ligeramente más oscuro en hover */
}

.donation-button-active {
  background-color: #f8d64e; /* Color de fondo amarillo para el botón activo */
  color: #ffffff; /* Texto blanco para contraste */
  border-color: #f8d64e; /* Borde del mismo color que el fondo para el botón activo */
}

/* Estilo para el corazón en el botón Mensual */
.donation-button-active:after {
  content: " ♥"; /* Agrega un corazón después del texto */
  color: #ffffff; /* Color del corazón blanco */
}

.checkbox-container {
    display: flex;
    align-items: center;
    margin-top: 5px;
}
.checkbox-container svg {
    margin-right: 10px;
}

/* Espaciado entre el checkbox y el texto */
.checkbox-container label {
    font-size: 14px;
    margin-left: 8px;
    font-weight:900;
}

/*----------------------------------------------------------------------*/
@keyframes slideDown {
    0% {
        transform: translateY(-100%);
    }
    100% {
        transform: translateY(0);
    }
}
[type=button]:focus, [type=button]:hover, [type=submit]:focus, [type=submit]:hover, button:focus, button:hover {
    background-color: inherit;
    border:none;
}
[type=button], [type=submit], button{
    border: none;
    outline: none;
}

input[type="text"], input[type="password"], select, textarea{
  background-color: #fff; /* fondo blanco */
  border: 2px solid #ccc; /* borde sólido con un color gris claro */
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.2); /* sombra interior más pronunciada para el estado normal */
  border-radius: 4px; /* bordes redondeados */
  padding: 8px 12px; /* un poco de relleno para hacer que el texto no esté demasiado pegado al borde */
  font-size: 16px; /* un tamaño de fuente legible */
  color: #333; /* color de texto oscuro para contraste con el fondo */
  width: 100%; /* para que ocupe el ancho del contenedor padre */
  box-sizing: border-box; /* asegurarse de que el padding y border no aumenten el ancho total */
  margin-bottom: 10px; /* espacio debajo del input */
  text-align: center; /* centra el texto dentro del input */
}




@media (max-width: 768px) {

    .buttonContainer, .formButtonContainer {
        flex-direction: row;
        gap: 5px;
        justify-content: space-evenly;
    }
    .fav{
        padding: 3px 5px;
    }.fav span {
         font-size: 10px;
    }
    .divisor{
        margin: 5px 0;
    }
     
}

@media (max-width:425px){
    .text-pasos h3 {
        font-size: 16px;
    }
}


</style>