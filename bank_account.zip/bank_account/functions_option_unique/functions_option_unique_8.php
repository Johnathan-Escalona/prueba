<?php
// functions.php

function option_unique_8_enviar_correo($to, $slug, $name, $gift_name, $gift_message, $gift_email, $isGift, $payment_type, $payment_data) {
    $message = "";
    $strToConvert = $name . ',' . $slug;
    $codeToSend = urlencode($strToConvert);
    $linkToSend = "https://donacion.wwf.org.co/certificado/?code=".$codeToSend;
    if ($isGift == true || $payment_type != "bank_account"){
        if($isGift == true){
            $pathToHtmlFile = plugin_dir_path(__FILE__) . '../emails_templates/gift.html';
        }
        else{
            $pathToHtmlFile = plugin_dir_path(__FILE__) . '../emails_templates/'.$slug.'.html';
        }
        if (file_exists($pathToHtmlFile)) {
            // Si el archivo existe, cárgalo
            $message = file_get_contents($pathToHtmlFile);
        } else {
            // Si el archivo no existe, carga el archivo gracias.html
            $message = file_get_contents(plugin_dir_path(__FILE__) . '../emails_templates/gracias.html');
        }

        if ($isGift == false){            
            $message = str_replace('{{link}}', $linkToSend, $message);
            $message = str_replace('{{name_1}}', $name, $message);
            $message = str_replace('{{name}}', 'Nombre: ' . $name, $message);
            if (strpos($slug , 'delfin') !== false) {
                $message = str_replace('{{nombre_donacion}}', "DELFIN DE RIO", $message);
            } elseif (strpos($slug , 'elefantes') !==false) {
                $message = str_replace('{{nombre_donacion}}', "ELEFANTES", $message);
            } elseif (strpos($slug, 'jaguar') !== false) {
                $message = str_replace('{{nombre_donacion}}', "JAGUAR", $message);
            } elseif (strpos($slug, 'oso-de-anteojos') !==false) {
                $message = str_replace('{{nombre_donacion}}', "OSO DE ANTEOJOS", $message);
            } elseif (strpos($slug, 'oso-panda') !== false){
                $message = str_replace('{{nombre_donacion}}', "OSO PANDA", $message);
            } elseif (strpos($slug, 'tortuga') !==false) {
                $message = str_replace('{{nombre_donacion}}', "TORTUGA MARINA", $message);
            } elseif (strpos($slug, 'apoyanos') !==false){
                $message = str_replace('{{nombre_donacion}}', "DONACION GENERAL", $message);
            } elseif (strpos($slug, 'fondo-incendios') !== false) {
                $message = str_replace('{{nombre_donacion}}', "FONDO DE INCENDIOS", $message);
            } else {
                $message = str_replace('{{nombre_donacion}}', "DONACION GENERAL", $message);
            }
            $donatipn_type = "";
            if($payment_data[0] == true){
                $donatipn_type = "Donación Mensual";
            }
            else{
                $donatipn_type = "Donación única";
            }
            $message = str_replace('{{tipo_donacion}}', $donatipn_type, $message);
            $message = str_replace('{{monto_donacion}}', $formatoMoneda = '$' . number_format($payment_data[1], 0, ',', '.'), $message);
            $message = str_replace('{{fecha_donacion}}', 'Fecha de la donación: ' . $payment_data[3], $message);
            $message = str_replace('{{identificacion}}', $payment_data[4], $message);
        }
        else{
            $message = str_replace('{{link}}', $linkToSend, $message);
            $message = str_replace('{{mensaje}}', $gift_message, $message);
        }
    }
    else
    {
        //$message = 'Este es el contenido del correo.';
        $pathToHtmlFile = plugin_dir_path(__FILE__) . '../emails_templates/cuenta-bancaria.html';
        
        $message = file_get_contents($pathToHtmlFile);
        $message = str_replace('{{name_1}}', $name, $message);
        $message = str_replace('{{name}}', $name, $message);
        $message = str_replace('{{link}}', $linkToSend, $message);
        if (strpos($slug , 'delfin') !== false) {
            $message = str_replace('{{nombre_donacion}}', "DELFIN DE RIO", $message);
        } elseif (strpos($slug , 'elefantes') !==false) {
            $message = str_replace('{{nombre_donacion}}', "ELEFANTES", $message);
        } elseif (strpos($slug, 'jaguar') !== false) {
            $message = str_replace('{{nombre_donacion}}', "JAGUAR", $message);
        } elseif (strpos($slug, 'oso-de-anteojos') !==false) {
            $message = str_replace('{{nombre_donacion}}', "OSO DE ANTEOJOS", $message);
        } elseif (strpos($slug, 'oso-panda') !== false){
            $message = str_replace('{{nombre_donacion}}', "OSO PANDA", $message);
        } elseif (strpos($slug, 'tortuga') !==false) {
            $message = str_replace('{{nombre_donacion}}', "TORTUGA MARINA", $message);
        } elseif (strpos($slug, 'apoyanos') !==false){
            $message = str_replace('{{nombre_donacion}}', "DONACION GENERAL", $message);
        } elseif (strpos($slug, 'fondo-incendios') !== false) {
            $message = str_replace('{{nombre_donacion}}', "FONDO DE INCENDIOS", $message);
        } else {
            $message = str_replace('{{nombre_donacion}}', "DONACION GENERAL", $message);
        }
        $donatipn_type = "";
        if($payment_data[0] == "SI"){
            $donatipn_type = "Donación Mensual";
        }
        else{
            $donatipn_type = "Donación única";
        }
        $message = str_replace('{{tipo_donacion}}', $donatipn_type, $message);
        $message = str_replace('{{monto_donacion}}', $formatoMoneda = '$' . number_format($payment_data[1], 0, ',', '.'), $message);
        $message = str_replace('{{id_donacion}}', $payment_data[2], $message);
        $message = str_replace('{{fecha_donacion}}', $payment_data[3], $message);
    }
    $headers = array('Content-Type: text/html; charset=UTF-8');

    $subject = 'Muchas gracias por tu donación 🐼💚 ';
    if ($isGift == true) {
        $subject = 'Alguien especial tiene algo para ti 🐼💚';
        $setTo = $gift_email;
    } /*elseif ($slug == 'delfin-de-rio') {
        $subject = '¡GRACIAS!';
    } elseif ($slug == 'elefantes') {
        $subject = '¡GRACIAS POR DEJAR TU HUELLA FUERTE!';
    } elseif ($slug == 'jaguar') {
        $subject = 'GRRRRRACIAS';
    } elseif ($slug == 'oso-de-anteojos') {
        $subject = '¡MUCHÍSIMAS GRACIAS!';
    } elseif ($slug == 'oso-panda') {
        $subject = '¡Un abrazo panda!';
    } elseif ($slug == 'tortuga-marina') {
        $subject = '¡GRACIAS!';
    } elseif ($slug == 'apoyanos') {
        $subject = '¡Tu donación está en camino! 🌿🐼';
    } elseif ($slug == 'fondo-incendios') {
        $subject = '¡GRACIAS!';
    }*/

    // Envía el correo
    $result = wp_mail($to, $subject, $message, $headers);
}

function option_unique_8_sha256($str) {
    $buffer = utf8_encode($str);
    $hashArray = hash('sha256', $buffer, true);
    $hashHex = bin2hex($hashArray);
    return $hashHex;
}

function option_unique_8_encriptar($cadena, $clave) {
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $cifrado = openssl_encrypt($cadena, 'aes-256-cbc', $clave, 0, $iv);
    return base64_encode($iv . $cifrado);
}

?>
