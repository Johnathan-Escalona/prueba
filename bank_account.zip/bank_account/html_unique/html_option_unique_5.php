<div id="pasosContainer_optionunique5" style="display: none;">
    <div class="container-steps">
        <div class="botones">
            <a role="button" id="option_unique_5_atras" class="btn-atras">
                <i aria-hidden="true" class="fas fa-chevron-left"></i>
            </a>
        </div>
        <div class="text-pasos">
            <h3 id="paso-text1_opu5" style="display: none;">Completa tu información personal</h3>
            <h3 id="paso-text2_opu5" style="display: none;">Llena los datos de tu tarjeta para contribuir a esta causa importante</h3>
        </div>
    </div>
</div>

<div id="option_unique_5_values_container">
    <!-- ------------ -->
    <div style="display: none">
        <div class="content-tab ">
            <span class="arrow" id="unica"></span>
            <button id="button1" class="option_unique_5_myButton_1">Única vez</button>
        </div>
        <div class="content-tab">
            <span class="arrow" id="mensual"></span>
            <button id="button2" class="option_unique_5_myButton_1 active">Mensual 🤍</button>
        </div>
    </div>
    <div class="divisor"></div>
    <div class="buttonContainer">
        <button id="option_unique_5_button1" class="option_unique_5_myButton"><?php echo $option_unique_5_values[1]; ?></button>
        <div class="fav">
            <span>Donación favorita</span>
            <button id="option_unique_5_button2" class="option_unique_5_myButton active"><?php echo $option_unique_5_values[2]; ?></button>
        </div>
        <button id="option_unique_5_button3" class="option_unique_5_myButton"><?php echo $option_unique_5_values[3]; ?></button>
    </div>
    <div>
        <input placeholder="Ingrese otro monto" type="text" id="option_unique_5_monto" name="option_unique_5_monto" inputmode="numeric" pattern="[0-9]*">
        <p id="option_unique_5_error_monto_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un monto</p>
        <p id="option_unique_5_error_monto_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Ingrese un valor" solo acepta números</p>
        <p id="option_unique_5_error_monto_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El monto a donar debe ser mayor a 40.000 COP </p>
        <p id="option_unique_5_error_monto_4" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El monto a donar debe ser mayor a 85.000 COP </p>
    </div>
    <!-- ------------ -->

    <div id="option_unique_5_data_user" class="formContainer">
        <input id="option_unique_5_monto_form_1" name="option_unique_5_monto_form" id="option_unique_5_monto_form" type="hidden" value='<?php echo $option_unique_5_values[2]; ?>'>

        <!-- ------------ -->
        <div class="divisor"></div>
        <div id="video-form">
            <video controls muted poster="https://donacion.wwf.org.co/wp-content/uploads/2024/01/cover-video.png">
                <source src="https://donacion.wwf.org.co/wp-content/uploads/2024/02/video.mp4" type="video/mp4">
                Tu navegador no soporta el elemento de video.
            </video>
        </div>
        <div class="checkbox-container">
            <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.32906 6.34211H13.6712C15.4197 6.34211 16.8422 4.91954 16.8422 3.17105C16.6828 -1.03026 10.6587 -1.02862 10.5001 3.17105C10.5001 1.4225 9.07754 0 7.32906 0C3.12781 0.159408 3.12939 6.18349 7.32906 6.34211Z" fill="#FF73AE" />
                <path d="M2.04373 23.114H18.956C19.501 23.114 19.9428 22.6722 19.9428 22.1272V14.5176H1.05688V22.1272C1.05688 22.6722 1.49873 23.114 2.04373 23.114Z" fill="#FF73AE" />
                <path d="M21 11.5572V9.30276C21 8.75776 20.5582 8.31592 20.0132 8.31592H0.986842C0.441842 8.31592 0 8.75776 0 9.30276V11.5572C0 12.1022 0.441842 12.544 0.986842 12.544H20.0132C20.5582 12.544 21 12.1022 21 11.5572Z" fill="#FF73AE" />
            </svg>
            <div style="padding-bottom: 4px;">
                <input type="checkbox" id="option_unique_5_giftCheck" style="min-height: 0px;">
            </div>
            <label for="giftCheck">para un regalo</label>
        </div>
        <div id="option_unique_5_gift_container" style="display: none;">
            <input placeholder="Correo de dedicatoria" id="option_unique_5_giftEmail" name="option_unique_5_giftEmail" type="text" value="">
            <p id="option_unique_5_error_email_gift_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_unique_5_error_email_gift_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
            <input placeholder="¿A quién va la dedicatoria?" id="option_unique_5_whoName" name="option_unique_5_whoName" type="text" value="">
            <p id="option_unique_5_error_whoName_gift" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un nombre para la dedicatoria</p>
            <textarea id="option_unique_5_message" name="option_unique_5_message" rows="4" cols="50" placeholder="Escribe dedicatoria" style="border-radius: 15px;"></textarea>
            <p id="option_unique_5_error_message_gift" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un mensaje</p>
        </div>
    </div>
    <!-- ------------ -->
    <div class="formButtonContainer">
        <button id="option_unique_5_next_step" class="formButton payuButton">¡Donar ahora!🤍</button>
    </div>
</div>
<!-- Por Pay U - Tarjetas-->
<div id="option_unique_5_form3" class="formContainer" style="display: none;">
    <!-- ------------ -->
    <!-- inicio form de Payu NO MODIFICAR -->
    <form id="option_unique_5_form_payu" method="post" action="">
        <input id="option_unique_5_monthly_payu" name="option_unique_5_monthly_payu" type="hidden" value="1">
        <input id="option_unique_5_gift_email_payu" name="option_unique_5_gift_email_payu" type="hidden" value="">
        <input id="option_unique_5_gift_name_payu" name="option_unique_5_gift_name_payu" type="hidden" value="">
        <input id="option_unique_5_gift_message_payu" name="option_unique_5_gift_message_payu" type="hidden" value="">
        <input id="option_unique_5_is_gift_payu" name="option_unique_5_is_gift_payu" type="hidden" value="0">

        <input id="option_unique_5_description" name="option_unique_5_description" type="hidden" value="">
        <input id="option_unique_5_referenceCode" name="option_unique_5_referenceCode" type="hidden" value="<?php echo $option_unique_5_reference; ?>">
        <input id="option_unique_5_amount_payu" name="option_unique_5_amount" type="hidden" value="<?php echo $option_unique_5_values[2]; ?>">
        <input name="option_unique_5_tax" type="hidden" value="0">
        <input id="option_unique_5_taxReturnBase" name="option_unique_5_taxReturnBase" type="hidden" value="0">
        <input id="option_unique_5_currency" name="option_unique_5_currency" type="hidden" value="COP">
        <input id="option_unique_5_signature" name="option_unique_5_signature" type="hidden" value="">
        <input name="option_unique_5_algorithmSignature" type="hidden" value="SHA256">

        <!-- Codigo nuevo de nombre y apellido -->
        <div style="display: none;">
            <div style="width: 100%;">
                <input placeholder="Nombre" id="option_unique_5_payerFullName" name="option_unique_5_payerFullName" type="text" value="">
                <p id="option_unique_5_error_payerFullName_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe ingresar un nombre</p>
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_unique_5_payerLastName" name="option_unique_5_payerLastName" type="text" value="">
                <p id="option_unique_5_error_payerFullName_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe ingresar un apellido</p>
            </div>
        </div>

        <!-- ------------ -->
        <select id="option_unique_5_tipoIdentificacionPayu" name="option_unique_5_tipoIdentificacionPayu" placeholder="Tipo de documento" style="display: none;">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="CC">Cédula de ciudadanía</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="RC">Registro civil de nacimiento</option>
            <option value="DE">Documento de identificación extranjero</option>
            <option value="PP">Pasaporte</option>
            <option value="NIT">NIT</option>
        </select>
        <p id="option_unique_5_error_id_type_payu" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de documento</p>
        <input placeholder="Número de identificación" type="text" id="option_unique_5_numeroIdentificacionPayu" name="option_unique_5_numeroIdentificacionPayu" style="display: none;">
        <div>
            <p id="option_unique_5_error_numeroIdentificacionPayu_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de identificación</p>
            <p id="option_unique_5_error_numeroIdentificacionPayu_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de identificación" solo puede contener números</p>
        </div>
        <input placeholder="Número de teléfono" id="option_unique_5_payerPhone" name="option_unique_5_payerPhone" type="text" value="" style="display: none;">
        <div>
            <p id="option_unique_5_error_payerPhone_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de teléfono</p>
            <p id="option_unique_5_error_payerPhone_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de teléfono ingresado no es válido</p>
        </div>
        <input placeholder="Correo electrónico" id="option_unique_5_email" name="option_unique_5_buyerEmail" type="text" value="" style="display: none;">
        <div>
            <p id="option_unique_5_error_email_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_unique_5_error_email_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
        </div>
        <input id="option_unique_5_responseUrl" name="option_unique_5_responseUrl" type="hidden" value="">
        <input id="option_unique_5_confirmationUrl" name="option_unique_5_confirmationUrl" type="hidden" value="">
        <input id="option_unique_5_payment_method_1" name="option_unique_5_payment_method_1" type="hidden" value="MASTERCARD">
        <select id="option_unique_5_payment_method_type_card" name="option_unique_5_payment_method_type_card">
            <option value="" disabled selected>Seleccione el tipo de tarjeta</option>
            <option value="credito">Tarjeta Crédito</option>
            <option value="debito">Tarjeta Débito</option>
        </select>
        <p id="option_unique_5_payment_method_type_card_error" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de tarjeta</p>
        <select id="option_unique_5_payment_method_brand_card" name="option_unique_5_payment_method_brand_card">
            <option value="" disabled selected>Seleccione tarjeta</option>
            <option value="MASTERCARD">Tarjeta Crédito Mastercard</option>
            <option value="VISA">Tarjeta Crédito VISA</option>
            <option value="AMEX">Tarjeta Crédito American Express</option>
            <option value="DINERS">Tarjeta Crédito Diners</option>
            <option value="ARGENCARD">Tarjeta Crédito Argencard</option>
            <option value="CABAL">Tarjeta Crédito CABAL</option>
            <option value="CENCOSUD">Tarjeta Crédito Cencosud</option>
            <option value="NARANJA">Tarjeta Crédito Naranja</option>
            <option value="SHOPPING">Tarjeta Crédito Shopping</option>
        </select>
        <p id="option_unique_5_payment_method_brand_card_error" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar una tarjeta</p>
        <input placeholder="Número de la tarjeta" type="text" id="option_unique_5_card_number" name="option_unique_5_card_number">
        <div>
            <p id="option_unique_5_error_card_number_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de tarjeta</p>
            <p id="option_unique_5_error_card_number_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de tarjeta ingresado no es válido</p>
        </div>

        <!------ Codigo de datos de tarjeta -->

        <div class="contForm-tarjerta">
            <input placeholder="CVV" type="password" id="option_unique_5_cvv_card" name="option_unique_5_cvv_card" inputmode="numeric" pattern="[0-9]*">
            <input placeholder="Mes" type="text" id="option_unique_5_expiration_month" name="option_unique_5_expiration_month">
            <input placeholder="Año" type="text" id="option_unique_5_expiration_year" name="option_unique_5_expiration_year">
        </div>
        <div>
            <p id="option_unique_5_error_cvv_card_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un CVV</p>
            <p id="option_unique_5_error_cvv_card_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">CVV no es válido</p>

            <p id="option_unique_5_error_expiration_month_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un mes de expiración</p>
            <p id="option_unique_5_error_expiration_month_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración solo puede contener números</p>
            <p id="option_unique_5_error_expiration_month_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración debe contener 2 dígitos, ejemplo: 02</p>
            <p id="option_unique_5_error_expiration_month_4" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración debe estar entre 01 y 12</p>

            <p id="option_unique_5_error_expiration_year_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un año de expiración</p>
            <p id="option_unique_5_error_expiration_year_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Año de expiración solo puede contener números</p>
            <p id="option_unique_5_error_expiration_year_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Año de expiración debe contener 4 dígitos, ejemplo: 2030</p>

            <p id="option_unique_5_error_expired_card" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Tarjeta vencida</p>

        </div>
        <!-- ------------ -->
        <button id="option_unique_5_payu" name="option_unique_5_payu" style="display: none;"></button>
    </form>
    <!-- fin form de Payu NO MODIFICAR -->

    <!-- Codigo aGregado -->
    <div class="checkbox-T&C">
        <div style="padding-bottom: 4px;">
            <input type="checkbox" id="option_unique_5_t&c" style="min-height: 0px;" requerid>
        </div>
        <label class="politicas" for="option_unique_5_t&c">Acepto los <a href="https://www.wwf.org.co/politica_de_tratamiento_de_datos/" target="_blank">términos y condiciones</a> de la donación</label>
    </div>

    <div>
        <p id="option_unique_5_error_option_unique_5_t&c" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes aceptar los términos y condiciones</p>
    </div>

    <h5 class="info" id="option_unique_5_info_payu">Estás donando mensualmente: <span id="option_unique_5_valorDonacion"><?php echo $option_unique_5_values[2]; ?></span></h5>

    <button id="option_unique_5_payu_1" name="option_unique_5_payu_1" class="saveButton">¡Confirmar donación!🤍</button>
    <div style="display: flex; justify-content: center; align-items: center; height: 100%;">
        <img id="option_unique_5_payu_2" src="https://donacion.wwf.org.co/wp-content/uploads/2024/01/loading.gif" alt="loading" style='display: none; width: 30px;'>
    </div>
</div>
<!-- Fin Por Pay U - Tarjetas-->

<!-- Por Pay U - PSE-->
<div id="option_unique_5_form5" class="formContainer" style="display: none;">
    <!-- ------------ -->
    <!-- inicio form de Payu NO MODIFICAR -->
    <form id="option_unique_5_form_payu_pse" method="post" action="">
        <input id="option_unique_5_monthly_payu_pse" name="option_unique_5_monthly_payu_pse" type="hidden" value="1">
        <input id="option_unique_5_gift_email_payu_pse" name="option_unique_5_gift_email_payu_pse" type="hidden" value="">
        <input id="option_unique_5_gift_name_payu_pse" name="option_unique_5_gift_name_payu_pse" type="hidden" value="">
        <input id="option_unique_5_gift_message_payu_pse" name="option_unique_5_gift_message_payu_pse" type="hidden" value="">
        <input id="option_unique_5_is_gift_payu_pse" name="option_unique_5_is_gift_payu_pse" type="hidden" value="0">

        <input id="option_unique_5_description_pse" name="option_unique_5_description_pse" type="hidden" value="">
        <input id="option_unique_5_referenceCode_pse" name="option_unique_5_referenceCode_pse" type="hidden" value="<?php echo $option_unique_5_reference; ?>">
        <input id="option_unique_5_amount_payu_pse" name="option_unique_5_amount_pse" type="hidden" value="<?php echo $option_unique_5_values[2]; ?>">
        <input name="option_unique_5_tax_pse" type="hidden" value="0">
        <input id="option_unique_5_taxReturnBase_pse" name="option_unique_5_taxReturnBase_pse" type="hidden" value="0">
        <input id="option_unique_5_currency_pse" name="option_unique_5_currency_pse" type="hidden" value="COP">
        <input id="option_unique_5_signature_pse" name="option_unique_5_signature_pse" type="hidden" value="">
        <input name="option_unique_5_algorithmSignature_pse" type="hidden" value="SHA256">

        <!-- Codigo nuevo de nombre y apellido -->
        <div style="display: none;">
            <div style="width: 100%;">
                <input placeholder="Nombre" id="option_unique_5_payerFullName_pse" name="option_unique_5_payerFullName_pse" type="text" value="">
                <p id="option_unique_5_error_payerFullName_1_pse" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe ingresar un nombre</p>
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_unique_5_payerLastName_pse" name="option_unique_5_payerLastName_pse" type="text" value="">
                <p id="option_unique_5_error_payerFullName_2_pse" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe ingresar un apellido</p>
            </div>
        </div>

        <!-- ------------ -->
        <select id="option_unique_5_tipoIdentificacionPayu_pse" name="option_unique_5_tipoIdentificacionPayu_pse" style="display: none;">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="CC">Cédula de ciudadanía</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="RC">Registro civil de nacimiento</option>
            <option value="DE">Documento de identificación extranjero</option>           
            <option value="PP">Pasaporte</option>
            <option value="NIT">NIT</option>
        </select>
        <p id="option_unique_5_error_id_type_payu_pse" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de documento</p>
        <input placeholder="Número de identificación" type="text" id="option_unique_5_numeroIdentificacionPayu_pse" name="option_unique_5_numeroIdentificacionPayu_pse" style="display: none;">
        <div>
            <p id="option_unique_5_error_numeroIdentificacionPayu_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de identificación</p>
            <p id="option_unique_5_error_numeroIdentificacionPayu_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de identificación" solo puede contener números</p>
        </div>
        <input placeholder="Número de teléfono" id="option_unique_5_payerPhone_pse" name="option_unique_5_payerPhone_pse" type="text" value="" style="display: none;">
        <div>
            <p id="option_unique_5_error_payerPhone_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de teléfono</p>
            <p id="option_unique_5_error_payerPhone_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de teléfono ingresado no es válido</p>
        </div>
        <input placeholder="Correo electrónico" id="option_unique_5_email_pse" name="option_unique_5_buyerEmail_pse" type="text" value="" style="display: none;">
        <div>
            <p id="option_unique_5_error_email_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_unique_5_error_email_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
        </div>
        <input id="option_unique_5_responseUrl_pse" name="option_unique_5_responseUrl_pse" type="hidden" value="">
        <input id="option_unique_5_confirmationUrl_pse" name="option_unique_5_confirmationUrl_pse" type="hidden" value="">
        <select id="option_unique_5_person_type_pse" name="option_unique_5_person_type_pse">
            <option value="" disabled selected>Tipo de persona</option>
            <option value="N">Natural</option>
            <option value="J">Jurídica</option>
        </select>
        <select id="option_unique_5_nombreBanco_pse" name="option_unique_5_nombreBanco_pse">
        <?php
            if (count($pseCodes) == count($descriptions)) {
                for ($i = 0; $i < count($pseCodes); $i++) {
                    $code = htmlspecialchars($pseCodes[$i], ENT_QUOTES, 'UTF-8');
                    $desc = htmlspecialchars($descriptions[$i], ENT_QUOTES, 'UTF-8');
                    if (strpos(strtolower($desc), "bancolombia") !== false) {
                        $desc = "BANCOLOMBIA";
                    }
                    elseif (strpos(strtolower($desc), "nequi") !== false) {
                        $desc = "NEQUI";
                    }

                    if($code == "0" || $code == 0){
                        echo "<option value=\"$code\" disabled selected>$desc</option>\n";
                    }
                    elseif(strpos(strtolower($desc), "prueba") === false){
                        echo "<option value=\"$code\">$desc</option>\n";
                    }
                }
            }
        ?>
        </select>
        <div>
            <p id="option_unique_5_error_card_number_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de tarjeta</p>
            <p id="option_unique_5_error_card_number_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de tarjeta ingresado no es válido</p>
        </div>

        <!------ Codigo de datos de tarjeta -->
        <div>
            <p id="option_unique_5_error_cvv_card_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un CVV</p>
            <p id="option_unique_5_error_cvv_card_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">CVV no es válido</p>

            <p id="option_unique_5_error_expiration_month_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un mes de expiración</p>
            <p id="option_unique_5_error_expiration_month_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración solo puede contener números</p>
            <p id="option_unique_5_error_expiration_month_pse_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración debe contener 2 dígitos, ejemplo: 02</p>
            <p id="option_unique_5_error_expiration_month_pse_4" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración debe estar entre 01 y 12</p>

            <p id="option_unique_5_error_expiration_year_pse_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un año de expiración</p>
            <p id="option_unique_5_error_expiration_year_pse_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Año de expiración solo puede contener números</p>
            <p id="option_unique_5_error_expiration_year_pse_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Año de expiración debe contener 4 dígitos, ejemplo: 2030</p>

            <p id="option_unique_5_error_expired_card_pse" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Tarjeta vencida</p>

        </div>
        <!-- ------------ -->
        <button id="option_unique_5_payu_pse" name="option_unique_5_payu_pse" style="display: none;"></button>
    </form>
    <!-- fin form de Payu NO MODIFICAR -->
</div>
<!-- Fin Por Pay U - PSE-->

<!-- ------informacion del usuario------ -->
<div id="option_unique_5_form4" class="formContainer" style="display: none; ">
    <form id="option_unique_5_form_user_data" method="post" action="">
        <div class="contForm-nombre">
            <div style="width: 100%;">
                <input id="option_unique_5_nombre_1" placeholder="Nombre" name="option_unique_5_nombre_1" type="text" value="">
                <p id="option_unique_5_error_nombre_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un nombre</p>
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_unique_5_apellido_1" name="option_unique_5_apellido_1" type="text" value="">
                <p id="option_unique_5_error_nombre_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un apellido</p>
            </div>
        </div>
        
        <select id="option_unique_5_person_type" name="option_unique_5_person_type">
            <option value="" disabled selected>Tipo de persona</option>
            <option value="N">Natural</option>
            <option value="J">Jurídica</option>
        </select>
        <div>
            <p id="option_unique_5_error_person_type" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe seleccionar un tipo de persona</p>
        </div>
        <select id="option_unique_5_tipoIdentificacion_1" name="option_unique_5_tipoIdentificacion_1">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="CC">Cédula de ciudadanía</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="RC">Registro civil de nacimiento</option>
            <option value="DE">Documento de identificación extranjero</option>
            <option value="PP">Pasaporte</option>
            <option value="NIT">NIT</option>
        </select>
        <p id="option_unique_5_error_id_type_bank" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de identificación</p>
        <input placeholder="Número de identificación" type="text" id="option_unique_5_numeroIdentificacion_1" name="option_unique_5_numeroIdentificacion_1">

        <div>
            <p id="option_unique_5_error_numeroIdentificacion_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un número de identificación</p>
            <p id="option_unique_5_error_numeroIdentificacion_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de identificación" solo puede contener números</p>
        </div>

        <input placeholder="Número de teléfono" type="text" id="option_unique_5_numeroTelefono_1" name="option_unique_5_numeroTelefono_1" inputmode="numeric" pattern="[0-9]*">
        <div>
            <p id="option_unique_5_error_numeroTelefono_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de teléfono</p>
            <p id="option_unique_5_error_numeroTelefono_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de teléfono" solo puede contener números</p>
            <p id="option_unique_5_error_numeroTelefono_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de teléfono ingresado no es válido</p>
        </div>

        <input placeholder="Correo electrónico" type="text" id="option_unique_5_correoElectronico_1" name="option_unique_5_correoElectronico_1">

        <div>
            <p id="option_unique_5_error_correoElectronico_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_unique_5_error_correoElectronico_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
        </div>

        <select id="option_unique_5_payment_method" name="option_unique_5_payment_method">
        <option value="" disabled selected>Seleccione el método de pago</option>
            <option value="tarjeta">Tarjeta</option>
            <option value="Cuenta de banco">Cuenta Bancaria</option>
            <option value="PSE">PSE</option>
        </select>
        <p id="option_unique_5_error_payment_method" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar un método de pago</p>
        
        <select id="option_unique_5_nombreBanco_1" name="option_unique_5_nombreBanco_1" style="display: none;">
        <?php
            if (count($pseCodes) == count($descriptions)) {
                for ($i = 0; $i < count($pseCodes); $i++) {
                    $code = htmlspecialchars($pseCodes[$i], ENT_QUOTES, 'UTF-8');
                    $desc = htmlspecialchars($descriptions[$i], ENT_QUOTES, 'UTF-8');
                    if (strpos(strtolower($desc), "bancolombia") !== false) {
                        $desc = "BANCOLOMBIA";
                    }
                    elseif (strpos(strtolower($desc), "nequi") !== false) {
                        $desc = "NEQUI";
                    }

                    if($code == "0" || $code == 0){
                        echo "<option value=\"$code\" disabled selected>$desc</option>\n";
                    }
                    elseif(strpos(strtolower($desc), "prueba") === false){
                        echo "<option value=\"$code\">$desc</option>\n";
                    }
                }
            }
        ?>
        </select>
        <p id="option_unique_5_error_nombreBanco_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar un banco</p>
        <!-- ------------------------------------ -->
        <div class="checkbox-T&C" id="option_unique_5_checkbox-T&C_form" style="display: none;">
            <div style="padding-bottom: 4px;">
                <input type="checkbox" id="option_unique_5_t&c_form" style="min-height: 0px;" requerid>
            </div>
            <label class="politicas" for="option_unique_5_t&c_form">Acepto los <a href="https://www.wwf.org.co/politica_de_tratamiento_de_datos/" target="_blank">términos y condiciones</a> de la donación</label>
        </div>

        <div>
            <p id="option_unique_5_error_option_unique_5_t&c_form" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes aceptar los términos y condiciones</p>
        </div>

        <h5 class="info" id="option_unique_5_info_form" style="display: none;">Estás donando mensualmente: <span id="option_unique_5_valorDonacion_form"><?php echo $option_unique_5_values[2]; ?></span></h5>
        
        <div style="display: flex; justify-content: center; align-items: center; height: 100%;">
            <img id="option_unique_5_payu_2_form" src="https://donacion.wwf.org.co/wp-content/uploads/2024/01/loading.gif" alt="loading" style='display: none; width: 30px;'>
        </div>
        <!-- ------------------------------------ -->
        <button id="option_unique_5_next_step_1" type="submit" name="option_unique_5_next_step_1" class="saveButton">Siguiente</button>
    </form>
</div>
<!-- ------script evita la recarga luego de enviar el form------ -->
<script>
    document.getElementById('option_unique_5_form_user_data').addEventListener('submit', function(e) {
        e.preventDefault();
    });
</script>

<!-- informacion del banco -->
<div id="option_unique_5_form2" class="formContainer" style="display: none; ">
    <form id="option_unique_5_form_bank" method="post" action="">
        <input id="option_unique_5_monthly_bank" name="option_unique_5_monthly_bank" type="hidden" value="1">
        <input id="option_unique_5_gift_email_bank" name="option_unique_5_gift_email_bank" type="hidden" value="">
        <input id="option_unique_5_gift_name_bank" name="option_unique_5_gift_name_bank" type="hidden" value="">
        <input id="option_unique_5_gift_message_bank" name="option_unique_5_gift_message_bank" type="hidden" value="">
        <input id="option_unique_5_is_gift_bank" name="option_unique_5_is_gift_bank" type="hidden" value="0">

        <input id="option_unique_5_monto_form" name="option_unique_5_monto_form" type="hidden" style="border-radius: 30px;" value='<?php echo $option_unique_5_values[2]; ?>'>
        <!-- Codigo nuevo de nombre y apellido -->
        <div style="display: none;">
            <div style="width: 100%;">
                <input id="option_unique_5_nombre" placeholder="Nombre" name="option_unique_5_nombre" type="text" value="">
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_unique_5_apellido" name="option_unique_5_apellido" type="text" value="">
            </div>
        </div>

        <!-- ------------ -->
        <select id="option_unique_5_tipoCuenta" name="option_unique_5_tipoCuenta">
            <option value="" disabled selected>Tipo de Cuenta</option>
            <option value="Ahorros">Ahorros</option>
            <option value="Corriente">Corriente</option>
        </select>
        <p id="option_unique_5_error_account_type" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de cuenta</p>
        <input placeholder="Número de cuenta" type="text" id="option_unique_5_numeroCuenta" name="option_unique_5_numeroCuenta" inputmode="numeric" pattern="[0-9]*">
        <div>
            <p id="option_unique_5_error_numeroCuenta_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un número de cuenta</p>
            <p id="option_unique_5_error_numeroCuenta_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de cuenta" solo puede contener números</p>
        </div>

        <select id="option_unique_5_nombreBanco" name="option_unique_5_nombreBanco">
            <option value="" disabled selected>Seleccione el banco</option>
            <option value="BANCO DE BOGOTÁ">BANCO DE BOGOTÁ</option>
            <option value="BANCO POPULAR">BANCO POPULAR</option>
            <option value="BANCO ITAÚ CORPBANCA COLOMBIA S.A.">BANCO ITAÚ CORPBANCA COLOMBIA S.A.</option>
            <option value="BANCOLOMBIA S.A.">BANCOLOMBIA S.A.</option>
            <option value="BANCO GNB SUDAMERIS S.A.">BANCO GNB SUDAMERIS S.A.</option>
            <option value="BBVA COLOMBIA">BBVA COLOMBIA</option>
            <option value="(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.">(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.</option>
            <option value="BANCO COLPATRIA">BANCO COLPATRIA</option>
            <option value="BANCO DE OCCIDENTE">BANCO DE OCCIDENTE</option>
            <option value="BANCOLDEX">BANCOLDEX</option>
            <option value="BANCO CAJA SOCIAL - BCSC S.A.">BANCO CAJA SOCIAL - BCSC S.A.</option>
            <option value="BANCO AGRARIO DE COLOMBIA S.A.">BANCO AGRARIO DE COLOMBIA S.A.</option>
            <option value="BANCO DAVIVIENDA S.A.">BANCO DAVIVIENDA S.A.</option>
            <option value="BANCO AV VILLAS">BANCO AV VILLAS</option>
            <option value="BANCOOMEVA">BANCOOMEVA</option>
            <option value="BANCO FALABELLA S.A.">BANCO FALABELLA S.A.</option>
            <option value="BANCO MUNDO MUJER">BANCO MUNDO MUJER</option>
            <option value="BANCO MULTIBANK">BANCO MULTIBANK</option>
            <option value="BANCO SANTANDER NEGOCIOS COLOMBIA">BANCO SANTANDER NEGOCIOS COLOMBIA</option>
            <option value="BANCO COOPERATIVO COOPENTRAL">BANCO COOPERATIVO COOPENTRAL</option>
            <option value="BANCO COMPARTIR SA">BANCO COMPARTIR SA</option>
            <option value="BANCO SERFINANZA SA">BANCO SERFINANZA SA</option>
            <option value="FINANCIERA JURISCOOP">FINANCIERA JURISCOOP</option>
            <option value="COOPERATIVA FINANCIERA ANTIOQUIA">COOPERATIVA FINANCIERA ANTIOQUIA</option>
            <option value="CONTRAFA">CONTRAFA</option>
            <option value="BANCO CONFIAR">BANCO CONFIAR</option>
            <option value="COLTEFINANCIERA">COLTEFINANCIERA</option>
            <option value="Deceval S.A">Deceval S.A</option>
            <option value="DTN">DTN</option>
            <option value="DGCPTN SISTEMA GENERAL DE REGALIAS">DGCPTN SISTEMA GENERAL DE REGALIAS</option>
        </select>
        <p id="option_unique_5_error_bank_name" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el método de pago</p>
        <input type="hidden" placeholder="CVV (Opcional)" id="option_unique_5_cvv" name="option_unique_5_cvv" inputmode="numeric" pattern="[0-9]*">

        <select id="option_unique_5_tipoIdentificacion" name="option_unique_5_tipoIdentificacion" style="display: none;">
        <option value="" disabled selected>Tipo de Documento</option>
            <option value="CC">Cédula de ciudadanía</option>
            <option value="CE">Cédula de extranjería</option>
            <option value="TI">Tarjeta de identidad</option>
            <option value="RC">Registro civil de nacimiento</option>
            <option value="DE">Documento de identificación extranjero</option>
            <option value="PP">Pasaporte</option>
            <option value="NIT">NIT</option>
        </select>

        <input placeholder="Número de identificación" type="text" id="option_unique_5_numeroIdentificacion" name="option_unique_5_numeroIdentificacion" style="display: none;">

        <input placeholder="Número de teléfono" type="text" id="option_unique_5_numeroTelefono" name="option_unique_5_numeroTelefono" inputmode="numeric" pattern="[0-9]*" style="display: none;">

        <input placeholder="Correo electrónico" type="text" id="option_unique_5_correoElectronico" name="option_unique_5_correoElectronico" style="display: none;">

        <input type="hidden" id="option_unique_5_description_bank" name="option_unique_5_description_bank">

        <button id="option_unique_5_guardar" name="option_unique_5_guardar" style="display: none;"></button>
    </form>
    <!-- Codigo aGregado -->
    <div class="checkbox-T&C">
        <div style="padding-bottom: 4px;">
            <input type="checkbox" id="option_unique_5_t&c_bank" style="min-height: 0px;" requerid>
        </div>
        <label class="politicas" for="option_unique_5_t&c">Acepto los <a href="https://www.wwf.org.co/politica_de_tratamiento_de_datos/" target="_blank">términos y condiciones</a> de la donación</label>
    </div>
    <div>
        <p id="option_unique_5_error_checkbox-T&C_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes aceptar los términos y condiciones</p>
    </div>
    <h5 class="info" id="option_unique_5_info_bank">Estás donando mensualmente: <span id="option_unique_5_valorDonacion_bank"><?php echo $option_unique_5_values[2]; ?></span></h5>
    <!-- ------------ -->
    <button id="option_unique_5_guardar_1" name="option_unique_5_guardar" class="saveButton">¡Confirmar donación!🤍</button>
    <div style="display: flex; justify-content: center; align-items: center; height: 100%;">
        <img id="option_unique_5_guardar_2" src="https://donacion.wwf.org.co/wp-content/uploads/2024/01/loading.gif" alt="loading" style='display: none; width: 30px;'>
    </div>
</div>