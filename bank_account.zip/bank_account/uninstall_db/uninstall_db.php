<?php
// uninstall-plugin.php

// Código para desinstalación del plugin
global $wpdb;

// Consulta SQL para eliminar tablas
$sql_eliminar_tablas = "DROP TABLE IF EXISTS {$wpdb->prefix}values, {$wpdb->prefix}bank_accounts, {$wpdb->prefix}payu_settings, {$wpdb->prefix}urls, {$wpdb->prefix}tokensCards, {$wpdb->prefix}bank_accounts_logs, {$wpdb->prefix}values_unique, {$wpdb->prefix}values_monthly, {$wpdb->prefix}orders_data, {$wpdb->prefix}urls_store, {$wpdb->prefix}gift_table;";

// Ejecuta la consulta SQL
$wpdb->query($sql_eliminar_tablas);