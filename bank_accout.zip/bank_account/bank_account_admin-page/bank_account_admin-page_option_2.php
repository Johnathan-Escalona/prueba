<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option/functions_option_2.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState'])) {
    $option_2_aproved = "";
    $option_2_error = "";
    $option_2_pending = "";
    $option_2_expired = "";
    $option_2_delfin_de_rio = "";
    $option_2_elefante = "";
    $option_2_jaguar = "";
    $option_2_oso = "";
    $option_2_oso_panda = "";
    $option_2_tortuga = "";
    $option_2_apoya_la_causa_wwf = "";
    $option_2_fondo_incendios = "";

    $option_2_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_2_sql = "SELECT * FROM $option_2_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_2_results = $wpdb->get_results($option_2_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_2_results as $option_2_result) {
        $option_2_aproved = $option_2_result->aproved;
        $option_2_error = $option_2_result->error;
        $option_2_pending = $option_2_result->pending;
        $option_2_expired = $roption_2_esult->expired;
        $option_2_delfin_de_rio = $option_2_result->delfin_de_rio;
        $option_2_elefante = $option_2_result->elefante;
        $option_2_jaguar = $option_2_result->jaguar;
        $option_2_oso = $option_2_result->oso;
        $option_2_oso_panda = $option_2_result->oso_panda;
        $option_2_tortuga = $option_2_result->tortuga;
        $option_2_apoya_la_causa_wwf = $option_2_result->apoya_la_causa_wwf;
        $option_2_fondo_incendios = $option_2_result->fondo_incendios;
    }

    //--------------------------------------------------------------------------
    $option_2_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_2_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_2_nombreCookieValue = $_COOKIE[$option_2_nombreCookie];
    }
    //--------------------------------------------------------------------------
    $option_2_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_2_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_correoCookie])) {
        // Obtener el valor de la cookie
        $option_2_correoCookieValue = $_COOKIE[$option_2_correoCookie];
    }
    //--------------------------------------------------------------------------
    $option_2_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_2_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_slugCookie])) {
        // Obtener el valor de la cookie
        $option_2_slugCookieValue = $_COOKIE[$option_2_slugCookie];
    }
    //--------------------------------------------------------------------------
    $option_2_monthly_Cookie = "option_2_monthly_payu_pse";
    $option_2_monthly_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_monthly_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_monthly_CookieValue = $_COOKIE[$option_2_monthly_Cookie];
    }
    $option_2_monthly_payu_bool = false;
    /*
    if ($option_2_monthly_CookieValue == "1") {
        $option_2_monthly_payu_bool = true;
    } else {
        $option_2_monthly_payu_bool = false;
    }
    */
    //--------------------------------------------------------------------------
    $option_2_amount_Cookie = "option_2_amount_payu_pse";
    $option_2_amount_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_amount_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_amount_CookieValue = $_COOKIE[$option_2_amount_Cookie];
    }
    $option_2_amount = $option_2_amount_CookieValue;
    //--------------------------------------------------------------------------
    $option_2_tipoIdentificacion_Cookie = "option_2_tipoIdentificacionPayu_pse";
    $option_2_tipoIdentificacion_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_tipoIdentificacion_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_tipoIdentificacion_CookieValue = $_COOKIE[$option_2_tipoIdentificacion_Cookie];
    }
    $option_2_tipoIdentificacionPayu = $option_2_tipoIdentificacion_CookieValue;
    //--------------------------------------------------------------------------
    $option_2_numeroIdentificacion_Cookie = "option_2_numeroIdentificacionPayu_pse";
    $option_2_numeroIdentificacion_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_numeroIdentificacion_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_numeroIdentificacion_CookieValue = $_COOKIE[$option_2_numeroIdentificacion_Cookie];
    }
    $option_2_identification = $option_2_numeroIdentificacion_CookieValue;
    //--------------------------------------------------------------------------
    $option_2_gift_email_Cookie = "option_2_gift_email_payu_pse";
    $option_2_gift_email_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_gift_email_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_gift_email_CookieValue = $_COOKIE[$option_2_gift_email_Cookie];
    }
    $option_2_gift_email_payu = $option_2_gift_email_CookieValue;
    //--------------------------------------------------------------------------
    $option_2_gift_name_Cookie = "option_2_gift_name_payu_pse";
    $option_2_gift_name_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_gift_name_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_gift_name_CookieValue = $_COOKIE[$option_2_gift_name_Cookie];
    }
    $option_2_gift_name_payu = $option_2_gift_name_CookieValue;
    //--------------------------------------------------------------------------
    $option_2_gift_message_Cookie = "option_2_gift_message_payu_pse";
    $option_2_gift_message_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_gift_message_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_gift_message_CookieValue = $_COOKIE[$option_2_gift_message_Cookie];
    }
    $option_2_gift_message_payu = $option_2_gift_message_CookieValue;
    //--------------------------------------------------------------------------
    $option_2_is_gift_Cookie = "option_2_is_gift_payu_pse";
    $option_2_is_gift_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_is_gift_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_is_gift_CookieValue = $_COOKIE[$option_2_is_gift_Cookie];
    }

    $option_2_is_gift_payu_bool = false;
    if ($option_2_is_gift_CookieValue == "1") {
        $option_2_is_gift_payu_bool = true;
    } else {
        $option_2_is_gift_payu_bool = false;
    }
    //--------------------------------------------------------------------------
    $option_2_phone_Cookie = "option_2_payerPhone_pse";
    $option_2_phone_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_phone_Cookie])) {
        // Obtener el valor de la cookie
        $option_2_phone_CookieValue = $_COOKIE[$option_2_phone_Cookie];
    }

    //--------------------------------------------------------------------------
    $option_2_stateValue = sanitize_text_field($_GET['transactionState']);
    //--------------------------------------------------------------------------
    if ($option_2_stateValue == "4" || $option_2_stateValue == 4) {
        $option_2_urlRedirect = $option_2_aproved;
        if (strpos($option_2_slugCookieValue, 'delfin') !== false) {
            $option_2_urlRedirect = $option_2_delfin_de_rio;
        } elseif (strpos($option_2_slugCookieValue, 'elefantes') !== false) {
            $option_2_urlRedirect = $option_2_elefante;
        } elseif (strpos($option_2_slugCookieValue, 'jaguar') !== false) {
            $option_2_urlRedirect = $option_2_jaguar;
        } elseif (strpos($option_2_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_2_urlRedirect = $option_2_oso;
        } elseif (strpos($option_2_slugCookieValue, 'oso-panda') !== false) {
            $option_2_urlRedirect = $option_2_oso_panda;
        } elseif (strpos($option_2_slugCookieValue, 'tortuga') !== false) {
            $option_2_urlRedirect = $option_2_tortuga;
        } elseif (strpos($option_2_slugCookieValue, 'apoyanos') !== false) {
            $option_2_urlRedirect = $option_2_apoya_la_causa_wwf;
        } elseif (strpos($option_2_slugCookieValue, 'fondo-incendios') !== false) {
            $option_2_urlRedirect = $option_2_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_2_timezone = new DateTimeZone('America/Bogota');
        $option_2_date = new DateTime('now', $option_2_timezone);
        $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

        $option_2_day = $option_2_date->format('d');
        $option_2_month = $option_2_date->format('m');
        $option_2_year = $option_2_date->format('Y');

        $option_2_total_date = $option_2_day . '-' . $option_2_month . '-' . $option_2_year;

        $inserted_id = "";

        $option_2_donation_data = [$option_2_monthly_payu_bool, $option_2_amount, $inserted_id, $option_2_total_date, $option_2_tipoIdentificacionPayu . ': ' . $option_2_identification];

        option_2_enviar_correo($option_2_correoCookieValue, $option_2_slugCookieValue, $option_2_nombreCookieValue, "", "", "", false, "payu", $option_2_donation_data);

        if ($option_2_is_gift_payu_bool == true) {
            option_2_enviar_correo($option_2_gift_email_payu, $option_2_slugCookieValue, $option_2_gift_name_payu, $option_2_gift_name_payu, $option_2_gift_message_payu, $option_2_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_2_urlRedirect."');</script>";
        //wp_redirect($option_2_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_2_error."');</script>";
        //wp_redirect($option_2_error);
    }

    //----------------------------------------------------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $option_2_timezone = new DateTimeZone('America/Bogota');
    $option_2_date = new DateTime('now', $option_2_timezone);
    $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

    $final_status = "No Aprobada";
    if ($option_2_stateValue == "4" || $option_2_stateValue == 4){
        $final_status = "Aprobada";
    }

    $option_2_description = "DONACION GENERAL";
    if (strpos($option_2_slugCookieValue, 'delfin') !== false) {
        $option_2_description = "DELFIN DE RIO";
    } elseif (strpos($option_2_slugCookieValue, 'elefantes') !== false) {
        $option_2_description = "ELEFANTES";
    } elseif (strpos($option_2_slugCookieValue, 'jaguar') !== false) {
        $option_2_description = "JAGUAR";
    } elseif (strpos($option_2_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_2_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_2_slugCookieValue, 'oso-panda') !== false) {
        $option_2_description = "OSO PANDA";
    } elseif (strpos($option_2_slugCookieValue, 'tortuga') !== false) {
        $option_2_description = "TORTUGA MARINA";
    } elseif (strpos($option_2_slugCookieValue, 'apoyanos') !== false) {
        $option_2_description = "DONACION GENERAL";
    } elseif (strpos($option_2_slugCookieValue, 'fondo-incendios') !== false) {
        $option_2_description = "FONDO DE INCENDIOS";
    } else {
        $option_2_description = "DONACION GENERAL";
    }

    $option_2_format = array('%s');

    $option_2_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_2_table_logs,
        array(
            'name' => $option_2_nombreCookieValue,
            'payment_method' => "PSE",
            'id_type' => $option_2_tipoIdentificacionPayu,
            'id_number' => $option_2_identification,
            'phone_number' => $option_2_phone_CookieValue,
            'email' => $option_2_correoCookieValue,
            'amount' => $option_2_amount,
            'payment_description' => $option_2_description,
            'date_in' => $option_2_date_formatted,
            'monthly' => "NO",
            'final_result' => $final_status
        ),
        $option_2_format
    );
    //----------------------------------------------------------------------------------------
    exit;
}
//--------------------------------------------------------------------------------------------
if (isset($_REQUEST['transactionState'])) {
    $option_2_aproved = "";
    $option_2_error = "";
    $option_2_pending = "";
    $option_2_expired = "";
    $option_2_delfin_de_rio = "";
    $option_2_elefante = "";
    $option_2_jaguar = "";
    $option_2_oso = "";
    $option_2_oso_panda = "";
    $option_2_tortuga = "";
    $option_2_apoya_la_causa_wwf = "";
    $option_2_fondo_incendios = "";

    $option_2_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_2_sql = "SELECT * FROM $option_2_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_2_results = $wpdb->get_results($option_2_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_2_results as $option_2_result) {
        $option_2_aproved = $option_2_result->aproved;
        $option_2_error = $option_2_result->error;
        $option_2_pending = $option_2_result->pending;
        $option_2_expired = $option_2_result->expired;
        $option_2_delfin_de_rio = $option_2_result->delfin_de_rio;
        $option_2_elefante = $option_2_result->elefante;
        $option_2_jaguar = $option_2_result->jaguar;
        $option_2_oso = $option_2_result->oso;
        $option_2_oso_panda = $option_2_result->oso_panda;
        $option_2_tortuga = $option_2_result->tortuga;
        $option_2_apoya_la_causa_wwf = $option_2_result->apoya_la_causa_wwf;
        $option_2_fondo_incendios = $option_2_result->fondo_incendios;
    }

    if ($_REQUEST['transactionState']) {

        if ($_REQUEST['transactionState'] == "4") {

            $option_2_nombreCookie = "proyecto_donaciones_colombia_nombre";
            $option_2_nombreCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_2_nombreCookie])) {
                // Obtener el valor de la cookie
                $option_2_nombreCookieValue = $_COOKIE[$option_2_nombreCookie];
            }

            $option_2_correoCookie = "proyecto_donaciones_colombia_correo";
            $option_2_correoCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_2_correoCookie])) {
                // Obtener el valor de la cookie
                $option_2_correoCookieValue = $_COOKIE[$option_2_correoCookie];
            }

            $option_2_slugCookie = "proyecto_donaciones_colombia_slug";
            $option_2_slugCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_2_slugCookie])) {
                // Obtener el valor de la cookie
                $option_2_slugCookieValue = $_COOKIE[$option_2_slugCookie];
            }

            $option_2_urlRedirect = $option_2_aproved;
            if (strpos($option_2_slugCookieValue, 'delfin') !== false) {
                $option_2_urlRedirect = $option_2_delfin_de_rio;
            } elseif (strpos($option_2_slugCookieValue, 'elefantes') !== false) {
                $option_2_urlRedirect = $option_2_elefante;
            } elseif (strpos($option_2_slugCookieValue, 'jaguar') !== false) {
                $option_2_urlRedirect = $option_2_jaguar;
            } elseif (strpos($option_2_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_2_urlRedirect = $option_2_oso;
            } elseif (strpos($option_2_slugCookieValue, 'oso-panda') !== false) {
                $option_2_urlRedirect = $option_2_oso_panda;
            } elseif (strpos($option_2_slugCookieValue, 'tortuga') !== false) {
                $option_2_urlRedirect = $option_2_tortuga;
            } elseif (strpos($option_2_slugCookieValue, 'apoyanos') !== false) {
                $option_2_urlRedirect = $option_2_apoya_la_causa_wwf;
            } elseif (strpos($option_2_slugCookieValue, 'fondo-incendios') !== false) {
                $option_2_urlRedirect = $option_2_fondo_incendios;
            }

            option_2_enviar_correo($option_2_correoCookieValue, $option_2_slugCookieValue, $option_2_nombreCookieValue, false, false);
            echo $option_2_urlRedirect;
            wp_redirect($option_2_urlRedirect);
        } else if ($_REQUEST['transactionState'] == "6" || $_REQUEST['transactionState'] == "104") {
            wp_redirect($option_2_error);
        }
        if ($_REQUEST['transactionState'] == "5") {
            wp_redirect($option_2_expired);
        }
        if ($_REQUEST['transactionState'] == "7") {
            wp_redirect($option_2_pending);
        }

        exit;
    }
}

// Nombre de la tabla
$option_2_table_name_values = $wpdb->prefix . 'values';

// Consulta SQL para obtener los valores de las filas 1, 2 y 3
$option_2_sql = "SELECT id, value FROM $option_2_table_name_values WHERE id IN (1, 2, 3, 4, 5, 6)";

// Ejecutar la consulta
$option_2_results = $wpdb->get_results($option_2_sql);

// Crear un array asociativo para almacenar los resultados
$option_2_values = array();

// Recorrer los resultados y asignar los valores al array
foreach ($option_2_results as $option_2_result) {
    $option_2_values[$option_2_result->id] = $option_2_result->value;
}

// Codificar el array en formato JSON para usarlo en JavaScript
$option_2_values_json = json_encode($option_2_values);

$option_2_timezone = new DateTimeZone('America/Bogota');
$option_2_date = new DateTime('now', $option_2_timezone);
$option_2_reference = $option_2_date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$option_2_cookie = "";
// Nombre de la cookie
$option_2_cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$option_2_cookieName])) {
    // Obtiene el valor de la cookie
    $option_2_cookie = $_COOKIE[$option_2_cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $option_2_cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($option_2_cookieName, '', time() - 3600, '/'); // Borra la cookie
        $option_2_newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($option_2_cookieName, $option_2_newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $option_2_sessionId = session_id();
    setcookie($option_2_cookieName, $option_2_sessionId, time() + 3600, '/');
    $option_2_cookie = $_COOKIE[$option_2_cookieName];
}

$option_2_deviceSessionId = md5($option_2_cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$option_2_table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$option_2_sql = "SELECT * FROM $option_2_table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$option_2_results = $wpdb->get_results($option_2_sql);

// Crear un array asociativo para almacenar los resultados
$option_2_merchantId = "";
$option_2_accountId = "";
$option_2_ApiKey = "";
$option_2_ApiLogin = "";
$option_2_testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($option_2_results as $option_2_result) {
    $option_2_merchantId = $option_2_result->merchantId;
    $option_2_accountId = $option_2_result->accountId;
    $option_2_ApiKey = $option_2_result->apiKey;
    $option_2_ApiLogin = $option_2_result->apiLogin;
    $option_2_testMode = $option_2_result->testMode ? "1" : "0";
}

$option_2_setTest = "";
$option_2_url = "";
$option_2_tokenURL = "";
// URL de la API
if ($option_2_testMode == "1") {
    $option_2_setTest = true;
    $option_2_url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $option_2_tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $option_2_setTest = false;
    $option_2_url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $option_2_tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$option_2_data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $option_2_ApiLogin,
        'apiKey' => $option_2_ApiKey
    ),
    'test' => $option_2_setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$option_2_json_data_bank_list = json_encode($option_2_data_bank_list);

// Configuración de la solicitud cURL
$option_2_ch_bank_list = curl_init($option_2_url);
curl_setopt($option_2_ch_bank_list, CURLOPT_POST, 1);
curl_setopt($option_2_ch_bank_list, CURLOPT_POSTFIELDS, $option_2_json_data_bank_list);
curl_setopt($option_2_ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($option_2_ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$option_2_response_bank_list = curl_exec($option_2_ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($option_2_ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($option_2_ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($option_2_ch_bank_list);

// Decodificar la respuesta XML
$option_2_response_data_bank_list_xml = simplexml_load_string($option_2_response_bank_list);

// Convertir SimpleXMLElement a array
$option_2_response_data_bank_list_array = json_decode(json_encode($option_2_response_data_bank_list_xml), true);

$option_2_json_result_bank_list = json_encode($option_2_response_data_bank_list_array);

$option_2_array_result_bank_list = json_decode($option_2_json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($option_2_array_result_bank_list['banks']['bank']) && is_array($option_2_array_result_bank_list['banks']['bank'])) {
    foreach ($option_2_array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['option_2_payu'])) {
    $option_2_amount = sanitize_text_field($_POST['option_2_amount']);
    //$reference = 'abcde475674675';
    $option_2_reference = sanitize_text_field($_POST['option_2_referenceCode']);
    $option_2_description = sanitize_text_field($_POST['option_2_description']);
    $option_2_notifyUrl = sanitize_text_field($_POST['option_2_responseUrl']);
    $option_2_fullName = sanitize_text_field($_POST['option_2_payerFullName']) . ' ' . sanitize_text_field($_POST['option_2_payerLastName']);

    $option_2_tipoIdentificacionPayu = sanitize_text_field($_POST['option_2_tipoIdentificacionPayu']);

    $option_2_emailAddress = sanitize_text_field($_POST['option_2_buyerEmail']);
    $option_2_contactPhone = sanitize_text_field($_POST['option_2_payerPhone']);
    $option_2_creditCardNumber = sanitize_text_field($_POST['option_2_card_number']);
    $option_2_creditCardSecurityCode = sanitize_text_field($_POST['option_2_cvv_card']);
    $option_2_creditCardExpirationDate = sanitize_text_field($_POST['option_2_expiration_year']) . '/' . sanitize_text_field($_POST['option_2_expiration_month']);
    $option_2_creditCardName = $option_2_fullName;
    $option_2_paymentMethod = sanitize_text_field($_POST['option_2_payment_method_1']);
    $option_2_identification = sanitize_text_field($_POST['option_2_numeroIdentificacionPayu']);

    $option_2_gift_email_payu = sanitize_text_field($_POST['option_2_gift_email_payu']);
    $option_2_gift_name_payu = sanitize_text_field($_POST['option_2_gift_name_payu']);
    $option_2_gift_message_payu = sanitize_text_field($_POST['option_2_gift_message_payu']);
    $option_2_is_gift_payu_string = sanitize_text_field($_POST['option_2_is_gift_payu']);

    $option_2_monthly_payu_string = sanitize_text_field($_POST['option_2_monthly_payu']);

    $option_2_monthly_payu_bool = false;
    if ($option_2_monthly_payu_string == "1") {
        $option_2_monthly_payu_bool = true;
    } else {
        $option_2_monthly_payu_bool = false;
    }

    $option_2_is_gift_payu_bool = false;
    if ($option_2_is_gift_payu_string == "1") {
        $option_2_is_gift_payu_bool = true;
    } else {
        $option_2_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_2_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($option_2_monthly_payu_bool == true) {
        $option_2_tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $option_2_ApiLogin,
                "apiKey" => $option_2_ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $option_2_identification,
                "name" => $option_2_fullName,
                "identificationNumber" => $option_2_identification,
                "paymentMethod" => $option_2_paymentMethod,
                "number" => $option_2_creditCardNumber,
                "expirationDate" => $option_2_creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $option_2_json_data = json_encode($option_2_tokenData);

        // Configuración de la solicitud cURL
        $option_2_ch = curl_init($option_2_tokenURL);
        curl_setopt($option_2_ch, CURLOPT_POST, 1);
        curl_setopt($option_2_ch, CURLOPT_POSTFIELDS, $option_2_json_data);
        curl_setopt($option_2_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($option_2_ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $option_2_response = curl_exec($option_2_ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($option_2_ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($option_2_ch);
        }

        // Cerrar la conexión cURL
        curl_close($option_2_ch);

        // Decodificar la respuesta XML
        $option_2_response_data_xml = simplexml_load_string($option_2_response);

        // Convertir SimpleXMLElement a array
        $option_2_response_data_array = json_decode(json_encode($option_2_response_data_xml), true);

        $option_2_json_result = json_encode($option_2_response_data_array);

        $option_2_array_result = json_decode($option_2_json_result, true);

        $option_2_creditCardToken = "";
        if ($option_2_array_result['creditCardToken']['creditCardTokenId']) {
            $option_2_creditCardToken = $option_2_array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($option_2_creditCardToken != "") {

            $option_2_format = array('%s');

            $option_2_table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $option_2_table_name_token,
                array(
                    'document' => $option_2_identification,
                    'token_card' => $option_2_creditCardToken,
                    'amount_to_discount' => $option_2_amount,
                    'discount_day' => date('d'),
                    'payer_name' => $option_2_fullName,
                    'phone_number' => $option_2_contactPhone,
                    'payer_email' => $option_2_emailAddress,
                    'cvv_card' => $option_2_creditCardSecurityCode,
                    'paymentMethod' => $option_2_paymentMethod
                ),
                $option_2_format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $option_2_preSignature = $option_2_ApiKey . '~' . $option_2_merchantId . '~' . $option_2_reference . '~' . $option_2_amount . '~' . 'COP';

    $option_2_signature = option_2_sha256($option_2_preSignature);

    //----------------------------------------------

    $option_2_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_2_ApiKey,
            'apiLogin' => $option_2_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_2_accountId,
                'referenceCode' => $option_2_reference,
                'description' => $option_2_description,
                'language' => 'es',
                'signature' => $option_2_signature,
                'notifyUrl' => $option_2_notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $option_2_amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_2_fullName,
                'emailAddress' => $option_2_emailAddress,
                'contactPhone' => $option_2_contactPhone
            ),
            'creditCard' => array(
                'number' => $option_2_creditCardNumber,
                'securityCode' => $option_2_creditCardSecurityCode,
                'expirationDate' => $option_2_creditCardExpirationDate,
                'name' => $option_2_creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $option_2_paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_2_deviceSessionId,
            'ipAddress' => $option_2_ipAddress,
            'cookie' => $option_2_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_2_setTest
    );

    // Convertir datos a formato JSON
    $option_2_json_data = json_encode($option_2_data);

    // Configuración de la solicitud cURL
    $option_2_ch = curl_init($option_2_url);
    curl_setopt($option_2_ch, CURLOPT_POST, 1);
    curl_setopt($option_2_ch, CURLOPT_POSTFIELDS, $option_2_json_data);
    curl_setopt($option_2_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_2_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_2_response = curl_exec($option_2_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_2_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_2_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_2_ch);

    // Decodificar la respuesta XML
    $option_2_response_data_xml = simplexml_load_string($option_2_response);

    // Convertir SimpleXMLElement a array
    $option_2_response_data_array = json_decode(json_encode($option_2_response_data_xml), true);

    $option_2_json_result = json_encode($option_2_response_data_array);

    $option_2_array_result = json_decode($option_2_json_result, true);

    $option_2_stateValue = $option_2_array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $option_2_aproved = "";
    $option_2_error = "";
    $option_2_pending = "";
    $option_2_expired = "";
    $option_2_delfin_de_rio = "";
    $option_2_elefante = "";
    $option_2_jaguar = "";
    $option_2_oso = "";
    $option_2_oso_panda = "";
    $option_2_tortuga = "";
    $option_2_apoya_la_causa_wwf = "";
    $option_2_fondo_incendios = "";

    $option_2_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_2_sql = "SELECT * FROM $option_2_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_2_results = $wpdb->get_results($option_2_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_2_results as $option_2_result) {
        $option_2_aproved = $option_2_result->aproved;
        $option_2_error = $option_2_result->error;
        $option_2_pending = $option_2_result->pending;
        $option_2_expired = $roption_2_esult->expired;
        $option_2_delfin_de_rio = $option_2_result->delfin_de_rio;
        $option_2_elefante = $option_2_result->elefante;
        $option_2_jaguar = $option_2_result->jaguar;
        $option_2_oso = $option_2_result->oso;
        $option_2_oso_panda = $option_2_result->oso_panda;
        $option_2_tortuga = $option_2_result->tortuga;
        $option_2_apoya_la_causa_wwf = $option_2_result->apoya_la_causa_wwf;
        $option_2_fondo_incendios = $option_2_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_2_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_2_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_slugCookie])) {
        // Obtener el valor de la cookie
        $option_2_slugCookieValue = $_COOKIE[$option_2_slugCookie];
    }

    if ($option_2_stateValue == "APPROVED") {

        $option_2_nombreCookie = "proyecto_donaciones_colombia_nombre";
        $option_2_nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_2_nombreCookie])) {
            // Obtener el valor de la cookie
            $option_2_nombreCookieValue = $_COOKIE[$option_2_nombreCookie];
        }

        $option_2_correoCookie = "proyecto_donaciones_colombia_correo";
        $option_2_correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_2_correoCookie])) {
            // Obtener el valor de la cookie
            $option_2_correoCookieValue = $_COOKIE[$option_2_correoCookie];
        }

        $option_2_urlRedirect = $option_2_aproved;
        if (strpos($option_2_slugCookieValue, 'delfin') !== false) {
            $option_2_urlRedirect = $option_2_delfin_de_rio;
        } elseif (strpos($option_2_slugCookieValue, 'elefantes') !== false) {
            $option_2_urlRedirect = $option_2_elefante;
        } elseif (strpos($option_2_slugCookieValue, 'jaguar') !== false) {
            $option_2_urlRedirect = $option_2_jaguar;
        } elseif (strpos($option_2_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_2_urlRedirect = $option_2_oso;
        } elseif (strpos($option_2_slugCookieValue, 'oso-panda') !== false) {
            $option_2_urlRedirect = $option_2_oso_panda;
        } elseif (strpos($option_2_slugCookieValue, 'tortuga') !== false) {
            $option_2_urlRedirect = $option_2_tortuga;
        } elseif (strpos($option_2_slugCookieValue, 'apoyanos') !== false) {
            $option_2_urlRedirect = $option_2_apoya_la_causa_wwf;
        } elseif (strpos($option_2_slugCookieValue, 'fondo-incendios') !== false) {
            $option_2_urlRedirect = $option_2_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_2_timezone = new DateTimeZone('America/Bogota');
        $option_2_date = new DateTime('now', $option_2_timezone);
        $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

        $option_2_day = $option_2_date->format('d');
        $option_2_month = $option_2_date->format('m');
        $option_2_year = $option_2_date->format('Y');

        $option_2_total_date = $option_2_day . '-' . $option_2_month . '-' . $option_2_year;

        $inserted_id = $wpdb->insert_id;

        $option_2_donation_data = [$option_2_monthly_payu_bool, $option_2_amount, $inserted_id, $option_2_total_date, $option_2_tipoIdentificacionPayu . ': ' . $option_2_identification];

        option_2_enviar_correo($option_2_emailAddress, $option_2_slugCookieValue, $option_2_fullName, "", "", "", false, "payu", $option_2_donation_data);

        if ($option_2_is_gift_payu_bool == true) {
            option_2_enviar_correo($option_2_gift_email_payu, $option_2_slugCookieValue, $option_2_gift_name_payu, $option_2_gift_name_payu, $option_2_gift_message_payu, $option_2_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_2_urlRedirect."');</script>";
        //wp_redirect($option_2_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_2_error."');</script>";
        //wp_redirect($option_2_error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $option_2_timezone = new DateTimeZone('America/Bogota');
    $option_2_date = new DateTime('now', $option_2_timezone);
    $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

    $option_2_monthly = "NO";
    if($option_2_monthly_payu_bool){
        $option_2_monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($option_2_stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($option_2_slugCookieValue, 'delfin') !== false) {
        $option_2_description = "DELFIN DE RIO";
    } elseif (strpos($option_2_slugCookieValue, 'elefantes') !== false) {
        $option_2_description = "ELEFANTES";
    } elseif (strpos($option_2_slugCookieValue, 'jaguar') !== false) {
        $option_2_description = "JAGUAR";
    } elseif (strpos($option_2_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_2_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_2_slugCookieValue, 'oso-panda') !== false) {
        $option_2_description = "OSO PANDA";
    } elseif (strpos($option_2_slugCookieValue, 'tortuga') !== false) {
        $option_2_description = "TORTUGA MARINA";
    } elseif (strpos($option_2_slugCookieValue, 'apoyanos') !== false) {
        $option_2_description = "DONACION GENERAL";
    } elseif (strpos($option_2_slugCookieValue, 'fondo-incendios') !== false) {
        $option_2_description = "FONDO DE INCENDIOS";
    } else {
        $option_2_description = "DONACION GENERAL";
    }

    $option_2_format = array('%s');

    $option_2_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_2_table_logs,
        array(
            'name' => $option_2_fullName,
            'payment_method' => "PAYU",
            'id_type' => $option_2_tipoIdentificacionPayu,
            'id_number' => $option_2_identification,
            'phone_number' => $option_2_contactPhone,
            'email' => $option_2_emailAddress,
            'amount' => $option_2_amount,
            'payment_description' => $option_2_description,
            'date_in' => $option_2_date_formatted,
            'monthly' => $option_2_monthly,
            'final_result' => $final_status
        ),
        $option_2_format
    );

    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['option_2_payu_pse'])) {
    $option_2_person_type_pse = sanitize_text_field($_POST['option_2_person_type_pse']);
    $option_2_nombreBanco_pse = sanitize_text_field($_POST['option_2_nombreBanco_pse']);
    $option_2_amount = sanitize_text_field($_POST['option_2_amount_pse']);
    //$reference = 'abcde475674675';
    $option_2_reference = sanitize_text_field($_POST['option_2_referenceCode_pse']);
    $option_2_description = sanitize_text_field($_POST['option_2_description_pse']);
    $option_2_responseUrl = sanitize_text_field($_POST['option_2_responseUrl_pse']);
    $option_2_fullName = sanitize_text_field($_POST['option_2_payerFullName_pse']) . ' ' . sanitize_text_field($_POST['option_2_payerLastName_pse']);

    $option_2_tipoIdentificacionPayu = sanitize_text_field($_POST['option_2_tipoIdentificacionPayu_pse']);

    $option_2_emailAddress = sanitize_text_field($_POST['option_2_buyerEmail_pse']);
    $option_2_contactPhone = sanitize_text_field($_POST['option_2_payerPhone_pse']);
    $option_2_identification = sanitize_text_field($_POST['option_2_numeroIdentificacionPayu_pse']);

    $option_2_gift_email_payu = sanitize_text_field($_POST['option_2_gift_email_payu_pse']);
    $option_2_gift_name_payu = sanitize_text_field($_POST['option_2_gift_name_payu_pse']);
    $option_2_gift_message_payu = sanitize_text_field($_POST['option_2_gift_message_payu_pse']);
    $option_2_is_gift_payu_string = sanitize_text_field($_POST['option_2_is_gift_payu_pse']);

    $option_2_monthly_payu_string = sanitize_text_field($_POST['option_2_monthly_payu_pse']);

    $option_2_monthly_payu_bool = false;
    if ($option_2_monthly_payu_string == "1") {
        $option_2_monthly_payu_bool = true;
    } else {
        $option_2_monthly_payu_bool = false;
    }

    $option_2_is_gift_payu_bool = false;
    if ($option_2_is_gift_payu_string == "1") {
        $option_2_is_gift_payu_bool = true;
    } else {
        $option_2_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_2_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------

    $option_2_preSignature = $option_2_ApiKey . '~' . $option_2_merchantId . '~' . $option_2_reference . '~' . $option_2_amount . '~' . 'COP';

    //$option_2_signature = option_2_sha256($option_2_preSignature);
    $option_2_signature = md5($option_2_preSignature);

    //----------------------------------------------

    $option_2_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_2_ApiKey,
            'apiLogin' => $option_2_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_2_accountId,
                'referenceCode' => $option_2_reference,
                'description' => $option_2_reference,
                'language' => 'es',
                'signature' => $option_2_signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($option_2_amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_2_fullName,
                'emailAddress' => $option_2_emailAddress,
                'contactPhone' => $option_2_contactPhone,
                'dniType' => $option_2_tipoIdentificacionPayu,
                'dniNumber' => $option_2_identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $option_2_responseUrl,
                'PSE_REFERENCE1' => $option_2_ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $option_2_nombreBanco_pse,
                'USER_TYPE' => $option_2_person_type_pse,
                'PSE_REFERENCE2' => $option_2_tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $option_2_identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_2_deviceSessionId,
            'ipAddress' => $option_2_ipAddress,
            'cookie' => $option_2_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_2_setTest
    );

    // Convertir datos a formato JSON
    $option_2_json_data = json_encode($option_2_data);

    echo "<script>console.log('".$option_2_json_data."')</script>";

    echo "<script>console.log('---------------------------------')</script>";

    // Configuración de la solicitud cURL
    $option_2_ch = curl_init($option_2_url);
    curl_setopt($option_2_ch, CURLOPT_POST, 1);
    curl_setopt($option_2_ch, CURLOPT_POSTFIELDS, $option_2_json_data);
    curl_setopt($option_2_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_2_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_2_response = curl_exec($option_2_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_2_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_2_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_2_ch);

    // Decodificar la respuesta XML
    $option_2_response_data_xml = simplexml_load_string($option_2_response);

    // Convertir SimpleXMLElement a array
    $option_2_response_data_array = json_decode(json_encode($option_2_response_data_xml), true);

    $option_2_json_result = json_encode($option_2_response_data_array);

    echo "<script>console.log('".$option_2_json_result."')</script>";

    $option_2_array_result = json_decode($option_2_json_result, true);

    if (isset($option_2_array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($option_2_array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['option_2_guardar'])) {
    // Obtener los valores del formulario
    $option_2_monthly_bank = sanitize_text_field($_POST['option_2_monthly_bank']);
    $option_2_monto_form = sanitize_text_field($_POST['option_2_monto_form']);
    $option_2_name = sanitize_text_field($_POST['option_2_nombre']) . ' ' . sanitize_text_field($_POST['option_2_apellido']);
    $option_2_account_type = sanitize_text_field($_POST['option_2_tipoCuenta']);
    $option_2_account_number = sanitize_text_field($_POST['option_2_numeroCuenta']);
    $option_2_bank_name = sanitize_text_field($_POST['option_2_nombreBanco']);
    $option_2_id_type = sanitize_text_field($_POST['option_2_tipoIdentificacion']);
    $option_2_id_number = sanitize_text_field($_POST['option_2_numeroIdentificacion']);
    $option_2_phone_number = sanitize_text_field($_POST['option_2_numeroTelefono']);
    $option_2_email = sanitize_text_field($_POST['option_2_correoElectronico']);
    $option_2_description = sanitize_text_field($_POST['option_2_description_bank']);

    $option_2_gift_email_bank = sanitize_text_field($_POST['option_2_gift_email_bank']);
    $option_2_gift_name_bank = sanitize_text_field($_POST['option_2_gift_name_bank']);
    $option_2_gift_message_bank = sanitize_text_field($_POST['option_2_gift_message_bank']);
    $option_2_is_gift_bank_string = sanitize_text_field($_POST['option_2_is_gift_bank']);

    $option_2_is_gift_bank_bool = false;
    if ($option_2_is_gift_bank_string == "1") {
        $option_2_is_gift_bank_bool = true;
    } else {
        $option_2_is_gift_bank_bool = false;
    }

    $option_2_monthly = "NO";
    if ($option_2_monthly_bank == "1") {
        $option_2_monthly = "SI";
    } else {
        $option_2_monthly = "NO";
    }

    if (strpos($option_2_description, 'delfin') !== false) {
        $option_2_description = "DELFIN DE RIO";
    } elseif (strpos($option_2_description, 'elefantes') !== false) {
        $option_2_description = "ELEFANTES";
    } elseif (strpos($option_2_description, 'jaguar') !== false) {
        $option_2_description = "JAGUAR";
    } elseif (strpos($option_2_description, 'oso-de-anteojos') !== false) {
        $option_2_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_2_description, 'oso-panda') !== false) {
        $option_2_description = "OSO PANDA";
    } elseif (strpos($option_2_description, 'tortuga') !== false) {
        $option_2_description = "TORTUGA MARINA";
    } elseif (strpos($option_2_description, 'apoyanos') !== false) {
        $option_2_description = "DONACION GENERAL";
    } elseif (strpos($option_2_description, 'fondo-incendios') !== false) {
        $option_2_description = "FONDO DE INCENDIOS";
    } else {
        $option_2_description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $option_2_timezone = new DateTimeZone('America/Bogota');
    $option_2_date = new DateTime('now', $option_2_timezone);
    $option_2_date_formatted = $option_2_date->format('Y-m-d H:i:s');

    $option_2_day = $option_2_date->format('d');
    $option_2_month = $option_2_date->format('m');
    $option_2_year = $option_2_date->format('Y');

    $option_2_total_date = $option_2_day . '-' . $option_2_month . '-' . $option_2_year;

    $option_2_format = array('%s');

    $option_2_table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_2_table_name_bank_accounts,
        array(
            'name' => $option_2_name,
            'account_type' => $option_2_account_type,
            'account_number' => $option_2_account_number,
            'bank_name' => $option_2_bank_name,
            'id_type' => $option_2_id_type,
            'id_number' => $option_2_id_number,
            'phone_number' => $option_2_phone_number,
            'email' => $option_2_email,
            'amount' => $option_2_monto_form,
            'date_in' => $option_2_date_formatted,
            'payment_description' => $option_2_description,
            'monthly' => $option_2_monthly,
        ),
        $option_2_format
    );

    $inserted_id = $wpdb->insert_id;

    $option_2_donation_data = [$option_2_monthly, $option_2_monto_form, $inserted_id, $option_2_total_date];

    $option_2_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_2_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_2_nombreCookieValue = $_COOKIE[$option_2_nombreCookie];
    }

    $option_2_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_2_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_correoCookie])) {
        // Obtener el valor de la cookie
        $option_2_correoCookieValue = $_COOKIE[$option_2_correoCookie];
    }

    $option_2_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_2_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_2_slugCookie])) {
        // Obtener el valor de la cookie
        $option_2_slugCookieValue = $_COOKIE[$option_2_slugCookie];
    }

    //----------------------------------------------------------------------------
    $option_2_aproved = "";
    $option_2_error = "";
    $option_2_pending = "";
    $option_2_expired = "";
    $option_2_delfin_de_rio = "";
    $option_2_elefante = "";
    $option_2_jaguar = "";
    $option_2_oso = "";
    $option_2_oso_panda = "";
    $option_2_tortuga = "";
    $option_2_apoya_la_causa_wwf = "";
    $option_2_fondo_incendios = "";

    $option_2_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_2_sql = "SELECT * FROM $option_2_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_2_results = $wpdb->get_results($option_2_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_2_results as $option_2_result) {
        $option_2_aproved = $option_2_result->aproved;
        $option_2_error = $option_2_result->error;
        $option_2_pending = $option_2_result->pending;
        $option_2_expired = $option_2_result->expired;
        $option_2_delfin_de_rio = $option_2_result->delfin_de_rio;
        $option_2_elefante = $option_2_result->elefante;
        $option_2_jaguar = $option_2_result->jaguar;
        $option_2_oso = $option_2_result->oso;
        $option_2_oso_panda = $option_2_result->oso_panda;
        $option_2_tortuga = $option_2_result->tortuga;
        $option_2_apoya_la_causa_wwf = $option_2_result->apoya_la_causa_wwf;
        $option_2_fondo_incendios = $option_2_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_2_urlRedirect = $option_2_aproved;
    if (strpos($option_2_slugCookieValue, 'delfin') !== false) {
        $option_2_urlRedirect = $option_2_delfin_de_rio;
    } elseif (strpos($option_2_slugCookieValue, 'elefantes') !== false) {
        $option_2_urlRedirect = $option_2_elefante;
    } elseif (strpos($option_2_slugCookieValue, 'jaguar') !== false) {
        $option_2_urlRedirect = $option_2_jaguar;
    } elseif (strpos($option_2_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_2_urlRedirect = $option_2_oso;
    } elseif (strpos($option_2_slugCookieValue, 'oso-panda') !== false) {
        $option_2_urlRedirect = $option_2_oso_panda;
    } elseif (strpos($option_2_slugCookieValue, 'tortuga') !== false) {
        $option_2_urlRedirect = $option_2_tortuga;
    } elseif (strpos($option_2_slugCookieValue, 'apoyanos') !== false) {
        $option_2_urlRedirect = $option_2_apoya_la_causa_wwf;
    } elseif (strpos($option_2_slugCookieValue, 'fondo-incendios') !== false) {
        $option_2_urlRedirect = $option_2_fondo_incendios;
    }

    option_2_enviar_correo($option_2_email, $option_2_slugCookieValue, $option_2_name, "", "", "", false, "bank_account", $option_2_donation_data);

    if ($option_2_is_gift_bank_bool == true) {
        option_2_enviar_correo($option_2_gift_email_bank, $option_2_slugCookieValue, $option_2_gift_name_bank, $option_2_gift_name_bank, $option_2_gift_message_bank, $option_2_gift_email_bank, true, "", false);
    }

    echo "<script>window.location.assign('".$option_2_urlRedirect."');</script>";

    //wp_redirect($option_2_urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html/html_option_2.php');

include(plugin_dir_path(__FILE__) . '../css/css_option_2.php');
