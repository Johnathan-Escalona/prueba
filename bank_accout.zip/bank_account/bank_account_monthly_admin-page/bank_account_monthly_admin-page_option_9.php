<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option_monthly/functions_option_monthly_9.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState'])) {
    $option_monthly_9_aproved = "";
    $option_monthly_9_error = "";
    $option_monthly_9_pending = "";
    $option_monthly_9_expired = "";
    $option_monthly_9_delfin_de_rio = "";
    $option_monthly_9_elefante = "";
    $option_monthly_9_jaguar = "";
    $option_monthly_9_oso = "";
    $option_monthly_9_oso_panda = "";
    $option_monthly_9_tortuga = "";
    $option_monthly_9_apoya_la_causa_wwf = "";
    $option_monthly_9_fondo_incendios = "";

    $option_monthly_9_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_monthly_9_sql = "SELECT * FROM $option_monthly_9_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_monthly_9_results = $wpdb->get_results($option_monthly_9_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_monthly_9_results as $option_monthly_9_result) {
        $option_monthly_9_aproved = $option_monthly_9_result->aproved;
        $option_monthly_9_error = $option_monthly_9_result->error;
        $option_monthly_9_pending = $option_monthly_9_result->pending;
        $option_monthly_9_expired = $roption_monthly_9_esult->expired;
        $option_monthly_9_delfin_de_rio = $option_monthly_9_result->delfin_de_rio;
        $option_monthly_9_elefante = $option_monthly_9_result->elefante;
        $option_monthly_9_jaguar = $option_monthly_9_result->jaguar;
        $option_monthly_9_oso = $option_monthly_9_result->oso;
        $option_monthly_9_oso_panda = $option_monthly_9_result->oso_panda;
        $option_monthly_9_tortuga = $option_monthly_9_result->tortuga;
        $option_monthly_9_apoya_la_causa_wwf = $option_monthly_9_result->apoya_la_causa_wwf;
        $option_monthly_9_fondo_incendios = $option_monthly_9_result->fondo_incendios;
    }

    //--------------------------------------------------------------------------
    $option_monthly_9_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_monthly_9_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_nombreCookieValue = $_COOKIE[$option_monthly_9_nombreCookie];
    }
    //--------------------------------------------------------------------------
    $option_monthly_9_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_monthly_9_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_correoCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_correoCookieValue = $_COOKIE[$option_monthly_9_correoCookie];
    }
    //--------------------------------------------------------------------------
    $option_monthly_9_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_monthly_9_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_slugCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_slugCookieValue = $_COOKIE[$option_monthly_9_slugCookie];
    }
    //--------------------------------------------------------------------------
    $option_monthly_9_monthly_Cookie = "option_monthly_9_monthly_payu_pse";
    $option_monthly_9_monthly_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_monthly_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_monthly_CookieValue = $_COOKIE[$option_monthly_9_monthly_Cookie];
    }
    $option_monthly_9_monthly_payu_bool = false;
    /*
    if ($option_monthly_9_monthly_CookieValue == "1") {
        $option_monthly_9_monthly_payu_bool = true;
    } else {
        $option_monthly_9_monthly_payu_bool = false;
    }
    */
    //--------------------------------------------------------------------------
    $option_monthly_9_amount_Cookie = "option_monthly_9_amount_payu_pse";
    $option_monthly_9_amount_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_amount_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_amount_CookieValue = $_COOKIE[$option_monthly_9_amount_Cookie];
    }
    $option_monthly_9_amount = $option_monthly_9_amount_CookieValue;
    //--------------------------------------------------------------------------
    $option_monthly_9_tipoIdentificacion_Cookie = "option_monthly_9_tipoIdentificacionPayu_pse";
    $option_monthly_9_tipoIdentificacion_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_tipoIdentificacion_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_tipoIdentificacion_CookieValue = $_COOKIE[$option_monthly_9_tipoIdentificacion_Cookie];
    }
    $option_monthly_9_tipoIdentificacionPayu = $option_monthly_9_tipoIdentificacion_CookieValue;
    //--------------------------------------------------------------------------
    $option_monthly_9_numeroIdentificacion_Cookie = "option_monthly_9_numeroIdentificacionPayu_pse";
    $option_monthly_9_numeroIdentificacion_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_numeroIdentificacion_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_numeroIdentificacion_CookieValue = $_COOKIE[$option_monthly_9_numeroIdentificacion_Cookie];
    }
    $option_monthly_9_identification = $option_monthly_9_numeroIdentificacion_CookieValue;
    //--------------------------------------------------------------------------
    $option_monthly_9_gift_email_Cookie = "option_monthly_9_gift_email_payu_pse";
    $option_monthly_9_gift_email_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_gift_email_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_gift_email_CookieValue = $_COOKIE[$option_monthly_9_gift_email_Cookie];
    }
    $option_monthly_9_gift_email_payu = $option_monthly_9_gift_email_CookieValue;
    //--------------------------------------------------------------------------
    $option_monthly_9_gift_name_Cookie = "option_monthly_9_gift_name_payu_pse";
    $option_monthly_9_gift_name_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_gift_name_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_gift_name_CookieValue = $_COOKIE[$option_monthly_9_gift_name_Cookie];
    }
    $option_monthly_9_gift_name_payu = $option_monthly_9_gift_name_CookieValue;
    //--------------------------------------------------------------------------
    $option_monthly_9_gift_message_Cookie = "option_monthly_9_gift_message_payu_pse";
    $option_monthly_9_gift_message_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_gift_message_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_gift_message_CookieValue = $_COOKIE[$option_monthly_9_gift_message_Cookie];
    }
    $option_monthly_9_gift_message_payu = $option_monthly_9_gift_message_CookieValue;
    //--------------------------------------------------------------------------
    $option_monthly_9_is_gift_Cookie = "option_monthly_9_is_gift_payu_pse";
    $option_monthly_9_is_gift_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_is_gift_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_is_gift_CookieValue = $_COOKIE[$option_monthly_9_is_gift_Cookie];
    }

    $option_monthly_9_is_gift_payu_bool = false;
    if ($option_monthly_9_is_gift_CookieValue == "1") {
        $option_monthly_9_is_gift_payu_bool = true;
    } else {
        $option_monthly_9_is_gift_payu_bool = false;
    }
    //--------------------------------------------------------------------------
    $option_monthly_9_phone_Cookie = "option_monthly_9_payerPhone_pse";
    $option_monthly_9_phone_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_phone_Cookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_phone_CookieValue = $_COOKIE[$option_monthly_9_phone_Cookie];
    }

    //--------------------------------------------------------------------------
    $option_monthly_9_stateValue = sanitize_text_field($_GET['transactionState']);
    //--------------------------------------------------------------------------
    if ($option_monthly_9_stateValue == "4" || $option_monthly_9_stateValue == 4) {
        $option_monthly_9_urlRedirect = $option_monthly_9_aproved;
        if (strpos($option_monthly_9_slugCookieValue, 'delfin') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_delfin_de_rio;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'elefantes') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_elefante;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'jaguar') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_jaguar;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_oso;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-panda') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_oso_panda;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'tortuga') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_tortuga;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'apoyanos') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_apoya_la_causa_wwf;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'fondo-incendios') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_monthly_9_timezone = new DateTimeZone('America/Bogota');
        $option_monthly_9_date = new DateTime('now', $option_monthly_9_timezone);
        $option_monthly_9_date_formatted = $option_monthly_9_date->format('Y-m-d H:i:s');

        $option_monthly_9_day = $option_monthly_9_date->format('d');
        $option_monthly_9_month = $option_monthly_9_date->format('m');
        $option_monthly_9_year = $option_monthly_9_date->format('Y');

        $option_monthly_9_total_date = $option_monthly_9_day . '-' . $option_monthly_9_month . '-' . $option_monthly_9_year;

        $inserted_id = "";

        $option_monthly_9_donation_data = [$option_monthly_9_monthly_payu_bool, $option_monthly_9_amount, $inserted_id, $option_monthly_9_total_date, $option_monthly_9_tipoIdentificacionPayu . ': ' . $option_monthly_9_identification];

        option_monthly_9_enviar_correo($option_monthly_9_correoCookieValue, $option_monthly_9_slugCookieValue, $option_monthly_9_nombreCookieValue, "", "", "", false, "payu", $option_monthly_9_donation_data);

        if ($option_monthly_9_is_gift_payu_bool == true) {
            option_monthly_9_enviar_correo($option_monthly_9_gift_email_payu, $option_monthly_9_slugCookieValue, $option_monthly_9_gift_name_payu, $option_monthly_9_gift_name_payu, $option_monthly_9_gift_message_payu, $option_monthly_9_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_monthly_9_urlRedirect."');</script>";
        //wp_redirect($option_monthly_9_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_monthly_9_error."');</script>";
        //wp_redirect($option_monthly_9_error);
    }

    //----------------------------------------------------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $option_monthly_9_timezone = new DateTimeZone('America/Bogota');
    $option_monthly_9_date = new DateTime('now', $option_monthly_9_timezone);
    $option_monthly_9_date_formatted = $option_monthly_9_date->format('Y-m-d H:i:s');

    $final_status = "No Aprobada";
    if ($option_monthly_9_stateValue == "4" || $option_monthly_9_stateValue == 4){
        $final_status = "Aprobada";
    }

    $option_monthly_9_description = "DONACION GENERAL";
    if (strpos($option_monthly_9_slugCookieValue, 'delfin') !== false) {
        $option_monthly_9_description = "DELFIN DE RIO";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'elefantes') !== false) {
        $option_monthly_9_description = "ELEFANTES";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'jaguar') !== false) {
        $option_monthly_9_description = "JAGUAR";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_monthly_9_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-panda') !== false) {
        $option_monthly_9_description = "OSO PANDA";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'tortuga') !== false) {
        $option_monthly_9_description = "TORTUGA MARINA";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'apoyanos') !== false) {
        $option_monthly_9_description = "DONACION GENERAL";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'fondo-incendios') !== false) {
        $option_monthly_9_description = "FONDO DE INCENDIOS";
    } else {
        $option_monthly_9_description = "DONACION GENERAL";
    }

    $option_monthly_9_format = array('%s');

    $option_monthly_9_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_monthly_9_table_logs,
        array(
            'name' => $option_monthly_9_nombreCookieValue,
            'payment_method' => "PSE",
            'id_type' => $option_monthly_9_tipoIdentificacionPayu,
            'id_number' => $option_monthly_9_identification,
            'phone_number' => $option_monthly_9_phone_CookieValue,
            'email' => $option_monthly_9_correoCookieValue,
            'amount' => $option_monthly_9_amount,
            'payment_description' => $option_monthly_9_description,
            'date_in' => $option_monthly_9_date_formatted,
            'monthly' => "NO",
            'final_result' => $final_status
        ),
        $option_monthly_9_format
    );
    //----------------------------------------------------------------------------------------
    exit;
}
//--------------------------------------------------------------------------------------------
if (isset($_REQUEST['transactionState'])) {
    $option_monthly_9_aproved = "";
    $option_monthly_9_error = "";
    $option_monthly_9_pending = "";
    $option_monthly_9_expired = "";
    $option_monthly_9_delfin_de_rio = "";
    $option_monthly_9_elefante = "";
    $option_monthly_9_jaguar = "";
    $option_monthly_9_oso = "";
    $option_monthly_9_oso_panda = "";
    $option_monthly_9_tortuga = "";
    $option_monthly_9_apoya_la_causa_wwf = "";
    $option_monthly_9_fondo_incendios = "";

    $option_monthly_9_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_monthly_9_sql = "SELECT * FROM $option_monthly_9_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_monthly_9_results = $wpdb->get_results($option_monthly_9_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_monthly_9_results as $option_monthly_9_result) {
        $option_monthly_9_aproved = $option_monthly_9_result->aproved;
        $option_monthly_9_error = $option_monthly_9_result->error;
        $option_monthly_9_pending = $option_monthly_9_result->pending;
        $option_monthly_9_expired = $option_monthly_9_result->expired;
        $option_monthly_9_delfin_de_rio = $option_monthly_9_result->delfin_de_rio;
        $option_monthly_9_elefante = $option_monthly_9_result->elefante;
        $option_monthly_9_jaguar = $option_monthly_9_result->jaguar;
        $option_monthly_9_oso = $option_monthly_9_result->oso;
        $option_monthly_9_oso_panda = $option_monthly_9_result->oso_panda;
        $option_monthly_9_tortuga = $option_monthly_9_result->tortuga;
        $option_monthly_9_apoya_la_causa_wwf = $option_monthly_9_result->apoya_la_causa_wwf;
        $option_monthly_9_fondo_incendios = $option_monthly_9_result->fondo_incendios;
    }

    if ($_REQUEST['transactionState']) {

        if ($_REQUEST['transactionState'] == "4") {

            $option_monthly_9_nombreCookie = "proyecto_donaciones_colombia_nombre";
            $option_monthly_9_nombreCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_monthly_9_nombreCookie])) {
                // Obtener el valor de la cookie
                $option_monthly_9_nombreCookieValue = $_COOKIE[$option_monthly_9_nombreCookie];
            }

            $option_monthly_9_correoCookie = "proyecto_donaciones_colombia_correo";
            $option_monthly_9_correoCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_monthly_9_correoCookie])) {
                // Obtener el valor de la cookie
                $option_monthly_9_correoCookieValue = $_COOKIE[$option_monthly_9_correoCookie];
            }

            $option_monthly_9_slugCookie = "proyecto_donaciones_colombia_slug";
            $option_monthly_9_slugCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_monthly_9_slugCookie])) {
                // Obtener el valor de la cookie
                $option_monthly_9_slugCookieValue = $_COOKIE[$option_monthly_9_slugCookie];
            }

            $option_monthly_9_urlRedirect = $option_monthly_9_aproved;
            if (strpos($option_monthly_9_slugCookieValue, 'delfin') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_delfin_de_rio;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'elefantes') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_elefante;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'jaguar') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_jaguar;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_oso;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-panda') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_oso_panda;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'tortuga') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_tortuga;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'apoyanos') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_apoya_la_causa_wwf;
            } elseif (strpos($option_monthly_9_slugCookieValue, 'fondo-incendios') !== false) {
                $option_monthly_9_urlRedirect = $option_monthly_9_fondo_incendios;
            }

            option_monthly_9_enviar_correo($option_monthly_9_correoCookieValue, $option_monthly_9_slugCookieValue, $option_monthly_9_nombreCookieValue, false, false);
            echo $option_monthly_9_urlRedirect;
            wp_redirect($option_monthly_9_urlRedirect);
        } else if ($_REQUEST['transactionState'] == "6" || $_REQUEST['transactionState'] == "104") {
            wp_redirect($option_monthly_9_error);
        }
        if ($_REQUEST['transactionState'] == "5") {
            wp_redirect($option_monthly_9_expired);
        }
        if ($_REQUEST['transactionState'] == "7") {
            wp_redirect($option_monthly_9_pending);
        }

        exit;
    }
}

// Nombre de la tabla
$option_monthly_9_table_name_values = $wpdb->prefix . 'values_monthly';

// Consulta SQL para obtener los valores de las filas 1, 2 y 3
$option_monthly_9_sql = "SELECT * FROM $option_monthly_9_table_name_values WHERE id = 1";

$form_type = "option_monthly_9";

$id_to_search = intval(substr($form_type, -1));

$option_monthly_9_sql = $wpdb->prepare("SELECT * FROM $option_monthly_9_table_name_values WHERE id = %d",$id_to_search);

// Ejecutar la consulta
$option_monthly_9_result = $wpdb->get_row($option_monthly_9_sql);

// Crear un array asociativo para almacenar los resultados
$option_monthly_9_values = array();

if ($option_monthly_9_result){
    $option_monthly_9_values[1] = $option_monthly_9_result->value_1;
    $option_monthly_9_values[2] = $option_monthly_9_result->value_2;
    $option_monthly_9_values[3] = $option_monthly_9_result->value_3;
    $option_monthly_9_values[4] = $option_monthly_9_result->value_1;
    $option_monthly_9_values[5] = $option_monthly_9_result->value_2;
    $option_monthly_9_values[6] = $option_monthly_9_result->value_3;
}

// Codificar el array en formato JSON para usarlo en JavaScript
$option_monthly_9_values_json = json_encode($option_monthly_9_values);

$option_monthly_9_timezone = new DateTimeZone('America/Bogota');
$option_monthly_9_date = new DateTime('now', $option_monthly_9_timezone);
$option_monthly_9_reference = $option_monthly_9_date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$option_monthly_9_cookie = "";
// Nombre de la cookie
$option_monthly_9_cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$option_monthly_9_cookieName])) {
    // Obtiene el valor de la cookie
    $option_monthly_9_cookie = $_COOKIE[$option_monthly_9_cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $option_monthly_9_cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($option_monthly_9_cookieName, '', time() - 3600, '/'); // Borra la cookie
        $option_monthly_9_newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($option_monthly_9_cookieName, $option_monthly_9_newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $option_monthly_9_sessionId = session_id();
    setcookie($option_monthly_9_cookieName, $option_monthly_9_sessionId, time() + 3600, '/');
    $option_monthly_9_cookie = $_COOKIE[$option_monthly_9_cookieName];
}

$option_monthly_9_deviceSessionId = md5($option_monthly_9_cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$option_monthly_9_table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$option_monthly_9_sql = "SELECT * FROM $option_monthly_9_table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$option_monthly_9_results = $wpdb->get_results($option_monthly_9_sql);

// Crear un array asociativo para almacenar los resultados
$option_monthly_9_merchantId = "";
$option_monthly_9_accountId = "";
$option_monthly_9_ApiKey = "";
$option_monthly_9_ApiLogin = "";
$option_monthly_9_testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($option_monthly_9_results as $option_monthly_9_result) {
    $option_monthly_9_merchantId = $option_monthly_9_result->merchantId;
    $option_monthly_9_accountId = $option_monthly_9_result->accountId;
    $option_monthly_9_ApiKey = $option_monthly_9_result->apiKey;
    $option_monthly_9_ApiLogin = $option_monthly_9_result->apiLogin;
    $option_monthly_9_testMode = $option_monthly_9_result->testMode ? "1" : "0";
}

$option_monthly_9_setTest = "";
$option_monthly_9_url = "";
$option_monthly_9_tokenURL = "";
// URL de la API
if ($option_monthly_9_testMode == "1") {
    $option_monthly_9_setTest = true;
    $option_monthly_9_url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $option_monthly_9_tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $option_monthly_9_setTest = false;
    $option_monthly_9_url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $option_monthly_9_tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$option_monthly_9_data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $option_monthly_9_ApiLogin,
        'apiKey' => $option_monthly_9_ApiKey
    ),
    'test' => $option_monthly_9_setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$option_monthly_9_json_data_bank_list = json_encode($option_monthly_9_data_bank_list);

// Configuración de la solicitud cURL
$option_monthly_9_ch_bank_list = curl_init($option_monthly_9_url);
curl_setopt($option_monthly_9_ch_bank_list, CURLOPT_POST, 1);
curl_setopt($option_monthly_9_ch_bank_list, CURLOPT_POSTFIELDS, $option_monthly_9_json_data_bank_list);
curl_setopt($option_monthly_9_ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($option_monthly_9_ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$option_monthly_9_response_bank_list = curl_exec($option_monthly_9_ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($option_monthly_9_ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($option_monthly_9_ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($option_monthly_9_ch_bank_list);

// Decodificar la respuesta XML
$option_monthly_9_response_data_bank_list_xml = simplexml_load_string($option_monthly_9_response_bank_list);

// Convertir SimpleXMLElement a array
$option_monthly_9_response_data_bank_list_array = json_decode(json_encode($option_monthly_9_response_data_bank_list_xml), true);

$option_monthly_9_json_result_bank_list = json_encode($option_monthly_9_response_data_bank_list_array);

$option_monthly_9_array_result_bank_list = json_decode($option_monthly_9_json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($option_monthly_9_array_result_bank_list['banks']['bank']) && is_array($option_monthly_9_array_result_bank_list['banks']['bank'])) {
    foreach ($option_monthly_9_array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['option_monthly_9_payu'])) {
    $option_monthly_9_amount = sanitize_text_field($_POST['option_monthly_9_amount']);
    //$reference = 'abcde475674675';
    $option_monthly_9_reference = sanitize_text_field($_POST['option_monthly_9_referenceCode']);
    $option_monthly_9_description = sanitize_text_field($_POST['option_monthly_9_description']);
    $option_monthly_9_notifyUrl = sanitize_text_field($_POST['option_monthly_9_responseUrl']);
    $option_monthly_9_fullName = sanitize_text_field($_POST['option_monthly_9_payerFullName']) . ' ' . sanitize_text_field($_POST['option_monthly_9_payerLastName']);

    $option_monthly_9_tipoIdentificacionPayu = sanitize_text_field($_POST['option_monthly_9_tipoIdentificacionPayu']);

    $option_monthly_9_emailAddress = sanitize_text_field($_POST['option_monthly_9_buyerEmail']);
    $option_monthly_9_contactPhone = sanitize_text_field($_POST['option_monthly_9_payerPhone']);
    $option_monthly_9_creditCardNumber = sanitize_text_field($_POST['option_monthly_9_card_number']);
    $option_monthly_9_creditCardSecurityCode = sanitize_text_field($_POST['option_monthly_9_cvv_card']);
    $option_monthly_9_creditCardExpirationDate = sanitize_text_field($_POST['option_monthly_9_expiration_year']) . '/' . sanitize_text_field($_POST['option_monthly_9_expiration_month']);
    $option_monthly_9_creditCardName = $option_monthly_9_fullName;
    $option_monthly_9_paymentMethod = sanitize_text_field($_POST['option_monthly_9_payment_method_1']);
    $option_monthly_9_identification = sanitize_text_field($_POST['option_monthly_9_numeroIdentificacionPayu']);

    $option_monthly_9_gift_email_payu = sanitize_text_field($_POST['option_monthly_9_gift_email_payu']);
    $option_monthly_9_gift_name_payu = sanitize_text_field($_POST['option_monthly_9_gift_name_payu']);
    $option_monthly_9_gift_message_payu = sanitize_text_field($_POST['option_monthly_9_gift_message_payu']);
    $option_monthly_9_is_gift_payu_string = sanitize_text_field($_POST['option_monthly_9_is_gift_payu']);

    $option_monthly_9_monthly_payu_string = sanitize_text_field($_POST['option_monthly_9_monthly_payu']);

    $option_monthly_9_monthly_payu_bool = false;
    if ($option_monthly_9_monthly_payu_string == "1") {
        $option_monthly_9_monthly_payu_bool = true;
    } else {
        $option_monthly_9_monthly_payu_bool = false;
    }

    $option_monthly_9_is_gift_payu_bool = false;
    if ($option_monthly_9_is_gift_payu_string == "1") {
        $option_monthly_9_is_gift_payu_bool = true;
    } else {
        $option_monthly_9_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_monthly_9_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($option_monthly_9_monthly_payu_bool == true) {
        $option_monthly_9_tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $option_monthly_9_ApiLogin,
                "apiKey" => $option_monthly_9_ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $option_monthly_9_identification,
                "name" => $option_monthly_9_fullName,
                "identificationNumber" => $option_monthly_9_identification,
                "paymentMethod" => $option_monthly_9_paymentMethod,
                "number" => $option_monthly_9_creditCardNumber,
                "expirationDate" => $option_monthly_9_creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $option_monthly_9_json_data = json_encode($option_monthly_9_tokenData);

        // Configuración de la solicitud cURL
        $option_monthly_9_ch = curl_init($option_monthly_9_tokenURL);
        curl_setopt($option_monthly_9_ch, CURLOPT_POST, 1);
        curl_setopt($option_monthly_9_ch, CURLOPT_POSTFIELDS, $option_monthly_9_json_data);
        curl_setopt($option_monthly_9_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($option_monthly_9_ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $option_monthly_9_response = curl_exec($option_monthly_9_ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($option_monthly_9_ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($option_monthly_9_ch);
        }

        // Cerrar la conexión cURL
        curl_close($option_monthly_9_ch);

        // Decodificar la respuesta XML
        $option_monthly_9_response_data_xml = simplexml_load_string($option_monthly_9_response);

        // Convertir SimpleXMLElement a array
        $option_monthly_9_response_data_array = json_decode(json_encode($option_monthly_9_response_data_xml), true);

        $option_monthly_9_json_result = json_encode($option_monthly_9_response_data_array);

        $option_monthly_9_array_result = json_decode($option_monthly_9_json_result, true);

        $option_monthly_9_creditCardToken = "";
        if ($option_monthly_9_array_result['creditCardToken']['creditCardTokenId']) {
            $option_monthly_9_creditCardToken = $option_monthly_9_array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($option_monthly_9_creditCardToken != "") {

            $option_monthly_9_format = array('%s');

            $option_monthly_9_table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $option_monthly_9_table_name_token,
                array(
                    'document' => $option_monthly_9_identification,
                    'token_card' => $option_monthly_9_creditCardToken,
                    'amount_to_discount' => $option_monthly_9_amount,
                    'discount_day' => date('d'),
                    'payer_name' => $option_monthly_9_fullName,
                    'phone_number' => $option_monthly_9_contactPhone,
                    'payer_email' => $option_monthly_9_emailAddress,
                    'cvv_card' => $option_monthly_9_creditCardSecurityCode,
                    'paymentMethod' => $option_monthly_9_paymentMethod
                ),
                $option_monthly_9_format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $option_monthly_9_preSignature = $option_monthly_9_ApiKey . '~' . $option_monthly_9_merchantId . '~' . $option_monthly_9_reference . '~' . $option_monthly_9_amount . '~' . 'COP';

    $option_monthly_9_signature = option_monthly_9_sha256($option_monthly_9_preSignature);

    //----------------------------------------------

    $option_monthly_9_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_monthly_9_ApiKey,
            'apiLogin' => $option_monthly_9_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_monthly_9_accountId,
                'referenceCode' => $option_monthly_9_reference,
                'description' => $option_monthly_9_description,
                'language' => 'es',
                'signature' => $option_monthly_9_signature,
                'notifyUrl' => $option_monthly_9_notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $option_monthly_9_amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_monthly_9_fullName,
                'emailAddress' => $option_monthly_9_emailAddress,
                'contactPhone' => $option_monthly_9_contactPhone
            ),
            'creditCard' => array(
                'number' => $option_monthly_9_creditCardNumber,
                'securityCode' => $option_monthly_9_creditCardSecurityCode,
                'expirationDate' => $option_monthly_9_creditCardExpirationDate,
                'name' => $option_monthly_9_creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $option_monthly_9_paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_monthly_9_deviceSessionId,
            'ipAddress' => $option_monthly_9_ipAddress,
            'cookie' => $option_monthly_9_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_monthly_9_setTest
    );

    // Convertir datos a formato JSON
    $option_monthly_9_json_data = json_encode($option_monthly_9_data);

    // Configuración de la solicitud cURL
    $option_monthly_9_ch = curl_init($option_monthly_9_url);
    curl_setopt($option_monthly_9_ch, CURLOPT_POST, 1);
    curl_setopt($option_monthly_9_ch, CURLOPT_POSTFIELDS, $option_monthly_9_json_data);
    curl_setopt($option_monthly_9_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_monthly_9_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_monthly_9_response = curl_exec($option_monthly_9_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_monthly_9_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_monthly_9_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_monthly_9_ch);

    // Decodificar la respuesta XML
    $option_monthly_9_response_data_xml = simplexml_load_string($option_monthly_9_response);

    // Convertir SimpleXMLElement a array
    $option_monthly_9_response_data_array = json_decode(json_encode($option_monthly_9_response_data_xml), true);

    $option_monthly_9_json_result = json_encode($option_monthly_9_response_data_array);

    $option_monthly_9_array_result = json_decode($option_monthly_9_json_result, true);

    $option_monthly_9_stateValue = $option_monthly_9_array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $option_monthly_9_aproved = "";
    $option_monthly_9_error = "";
    $option_monthly_9_pending = "";
    $option_monthly_9_expired = "";
    $option_monthly_9_delfin_de_rio = "";
    $option_monthly_9_elefante = "";
    $option_monthly_9_jaguar = "";
    $option_monthly_9_oso = "";
    $option_monthly_9_oso_panda = "";
    $option_monthly_9_tortuga = "";
    $option_monthly_9_apoya_la_causa_wwf = "";
    $option_monthly_9_fondo_incendios = "";

    $option_monthly_9_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_monthly_9_sql = "SELECT * FROM $option_monthly_9_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_monthly_9_results = $wpdb->get_results($option_monthly_9_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_monthly_9_results as $option_monthly_9_result) {
        $option_monthly_9_aproved = $option_monthly_9_result->aproved;
        $option_monthly_9_error = $option_monthly_9_result->error;
        $option_monthly_9_pending = $option_monthly_9_result->pending;
        $option_monthly_9_expired = $roption_monthly_9_esult->expired;
        $option_monthly_9_delfin_de_rio = $option_monthly_9_result->delfin_de_rio;
        $option_monthly_9_elefante = $option_monthly_9_result->elefante;
        $option_monthly_9_jaguar = $option_monthly_9_result->jaguar;
        $option_monthly_9_oso = $option_monthly_9_result->oso;
        $option_monthly_9_oso_panda = $option_monthly_9_result->oso_panda;
        $option_monthly_9_tortuga = $option_monthly_9_result->tortuga;
        $option_monthly_9_apoya_la_causa_wwf = $option_monthly_9_result->apoya_la_causa_wwf;
        $option_monthly_9_fondo_incendios = $option_monthly_9_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_monthly_9_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_monthly_9_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_slugCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_slugCookieValue = $_COOKIE[$option_monthly_9_slugCookie];
    }

    if ($option_monthly_9_stateValue == "APPROVED") {

        $option_monthly_9_nombreCookie = "proyecto_donaciones_colombia_nombre";
        $option_monthly_9_nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_monthly_9_nombreCookie])) {
            // Obtener el valor de la cookie
            $option_monthly_9_nombreCookieValue = $_COOKIE[$option_monthly_9_nombreCookie];
        }

        $option_monthly_9_correoCookie = "proyecto_donaciones_colombia_correo";
        $option_monthly_9_correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_monthly_9_correoCookie])) {
            // Obtener el valor de la cookie
            $option_monthly_9_correoCookieValue = $_COOKIE[$option_monthly_9_correoCookie];
        }

        $option_monthly_9_urlRedirect = $option_monthly_9_aproved;
        if (strpos($option_monthly_9_slugCookieValue, 'delfin') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_delfin_de_rio;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'elefantes') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_elefante;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'jaguar') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_jaguar;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_oso;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-panda') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_oso_panda;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'tortuga') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_tortuga;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'apoyanos') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_apoya_la_causa_wwf;
        } elseif (strpos($option_monthly_9_slugCookieValue, 'fondo-incendios') !== false) {
            $option_monthly_9_urlRedirect = $option_monthly_9_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_monthly_9_timezone = new DateTimeZone('America/Bogota');
        $option_monthly_9_date = new DateTime('now', $option_monthly_9_timezone);
        $option_monthly_9_date_formatted = $option_monthly_9_date->format('Y-m-d H:i:s');

        $option_monthly_9_day = $option_monthly_9_date->format('d');
        $option_monthly_9_month = $option_monthly_9_date->format('m');
        $option_monthly_9_year = $option_monthly_9_date->format('Y');

        $option_monthly_9_total_date = $option_monthly_9_day . '-' . $option_monthly_9_month . '-' . $option_monthly_9_year;

        $inserted_id = $wpdb->insert_id;

        $option_monthly_9_donation_data = [$option_monthly_9_monthly_payu_bool, $option_monthly_9_amount, $inserted_id, $option_monthly_9_total_date, $option_monthly_9_tipoIdentificacionPayu . ': ' . $option_monthly_9_identification];

        option_monthly_9_enviar_correo($option_monthly_9_emailAddress, $option_monthly_9_slugCookieValue, $option_monthly_9_fullName, "", "", "", false, "payu", $option_monthly_9_donation_data);

        if ($option_monthly_9_is_gift_payu_bool == true) {
            option_monthly_9_enviar_correo($option_monthly_9_gift_email_payu, $option_monthly_9_slugCookieValue, $option_monthly_9_gift_name_payu, $option_monthly_9_gift_name_payu, $option_monthly_9_gift_message_payu, $option_monthly_9_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_monthly_9_urlRedirect."');</script>";
        //wp_redirect($option_monthly_9_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_monthly_9_error."');</script>";
        //wp_redirect($option_monthly_9_error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $option_monthly_9_timezone = new DateTimeZone('America/Bogota');
    $option_monthly_9_date = new DateTime('now', $option_monthly_9_timezone);
    $option_monthly_9_date_formatted = $option_monthly_9_date->format('Y-m-d H:i:s');

    $option_monthly_9_monthly = "NO";
    if($option_monthly_9_monthly_payu_bool){
        $option_monthly_9_monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($option_monthly_9_stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($option_monthly_9_slugCookieValue, 'delfin') !== false) {
        $option_monthly_9_description = "DELFIN DE RIO";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'elefantes') !== false) {
        $option_monthly_9_description = "ELEFANTES";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'jaguar') !== false) {
        $option_monthly_9_description = "JAGUAR";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_monthly_9_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-panda') !== false) {
        $option_monthly_9_description = "OSO PANDA";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'tortuga') !== false) {
        $option_monthly_9_description = "TORTUGA MARINA";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'apoyanos') !== false) {
        $option_monthly_9_description = "DONACION GENERAL";
    } elseif (strpos($option_monthly_9_slugCookieValue, 'fondo-incendios') !== false) {
        $option_monthly_9_description = "FONDO DE INCENDIOS";
    } else {
        $option_monthly_9_description = "DONACION GENERAL";
    }

    $option_monthly_9_format = array('%s');

    $option_monthly_9_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_monthly_9_table_logs,
        array(
            'name' => $option_monthly_9_fullName,
            'payment_method' => "PAYU",
            'id_type' => $option_monthly_9_tipoIdentificacionPayu,
            'id_number' => $option_monthly_9_identification,
            'phone_number' => $option_monthly_9_contactPhone,
            'email' => $option_monthly_9_emailAddress,
            'amount' => $option_monthly_9_amount,
            'payment_description' => $option_monthly_9_description,
            'date_in' => $option_monthly_9_date_formatted,
            'monthly' => $option_monthly_9_monthly,
            'final_result' => $final_status
        ),
        $option_monthly_9_format
    );

    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['option_monthly_9_payu_pse'])) {
    $option_monthly_9_person_type_pse = sanitize_text_field($_POST['option_monthly_9_person_type_pse']);
    $option_monthly_9_nombreBanco_pse = sanitize_text_field($_POST['option_monthly_9_nombreBanco_pse']);
    $option_monthly_9_amount = sanitize_text_field($_POST['option_monthly_9_amount_pse']);
    //$reference = 'abcde475674675';
    $option_monthly_9_reference = sanitize_text_field($_POST['option_monthly_9_referenceCode_pse']);
    $option_monthly_9_description = sanitize_text_field($_POST['option_monthly_9_description_pse']);
    $option_monthly_9_responseUrl = sanitize_text_field($_POST['option_monthly_9_responseUrl_pse']);
    $option_monthly_9_fullName = sanitize_text_field($_POST['option_monthly_9_payerFullName_pse']) . ' ' . sanitize_text_field($_POST['option_monthly_9_payerLastName_pse']);

    $option_monthly_9_tipoIdentificacionPayu = sanitize_text_field($_POST['option_monthly_9_tipoIdentificacionPayu_pse']);

    $option_monthly_9_emailAddress = sanitize_text_field($_POST['option_monthly_9_buyerEmail_pse']);
    $option_monthly_9_contactPhone = sanitize_text_field($_POST['option_monthly_9_payerPhone_pse']);
    $option_monthly_9_identification = sanitize_text_field($_POST['option_monthly_9_numeroIdentificacionPayu_pse']);

    $option_monthly_9_gift_email_payu = sanitize_text_field($_POST['option_monthly_9_gift_email_payu_pse']);
    $option_monthly_9_gift_name_payu = sanitize_text_field($_POST['option_monthly_9_gift_name_payu_pse']);
    $option_monthly_9_gift_message_payu = sanitize_text_field($_POST['option_monthly_9_gift_message_payu_pse']);
    $option_monthly_9_is_gift_payu_string = sanitize_text_field($_POST['option_monthly_9_is_gift_payu_pse']);

    $option_monthly_9_monthly_payu_string = sanitize_text_field($_POST['option_monthly_9_monthly_payu_pse']);

    $option_monthly_9_monthly_payu_bool = false;
    if ($option_monthly_9_monthly_payu_string == "1") {
        $option_monthly_9_monthly_payu_bool = true;
    } else {
        $option_monthly_9_monthly_payu_bool = false;
    }

    $option_monthly_9_is_gift_payu_bool = false;
    if ($option_monthly_9_is_gift_payu_string == "1") {
        $option_monthly_9_is_gift_payu_bool = true;
    } else {
        $option_monthly_9_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_monthly_9_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------

    $option_monthly_9_preSignature = $option_monthly_9_ApiKey . '~' . $option_monthly_9_merchantId . '~' . $option_monthly_9_reference . '~' . $option_monthly_9_amount . '~' . 'COP';

    //$option_monthly_9_signature = option_monthly_9_sha256($option_monthly_9_preSignature);
    $option_monthly_9_signature = md5($option_monthly_9_preSignature);

    //----------------------------------------------

    $option_monthly_9_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_monthly_9_ApiKey,
            'apiLogin' => $option_monthly_9_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_monthly_9_accountId,
                'referenceCode' => $option_monthly_9_reference,
                'description' => $option_monthly_9_reference,
                'language' => 'es',
                'signature' => $option_monthly_9_signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($option_monthly_9_amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_monthly_9_fullName,
                'emailAddress' => $option_monthly_9_emailAddress,
                'contactPhone' => $option_monthly_9_contactPhone,
                'dniType' => $option_monthly_9_tipoIdentificacionPayu,
                'dniNumber' => $option_monthly_9_identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $option_monthly_9_responseUrl,
                'PSE_REFERENCE1' => $option_monthly_9_ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $option_monthly_9_nombreBanco_pse,
                'USER_TYPE' => $option_monthly_9_person_type_pse,
                'PSE_REFERENCE2' => $option_monthly_9_tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $option_monthly_9_identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_monthly_9_deviceSessionId,
            'ipAddress' => $option_monthly_9_ipAddress,
            'cookie' => $option_monthly_9_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_monthly_9_setTest
    );

    // Convertir datos a formato JSON
    $option_monthly_9_json_data = json_encode($option_monthly_9_data);

    echo "<script>console.log('".$option_monthly_9_json_data."')</script>";

    echo "<script>console.log('---------------------------------')</script>";

    // Configuración de la solicitud cURL
    $option_monthly_9_ch = curl_init($option_monthly_9_url);
    curl_setopt($option_monthly_9_ch, CURLOPT_POST, 1);
    curl_setopt($option_monthly_9_ch, CURLOPT_POSTFIELDS, $option_monthly_9_json_data);
    curl_setopt($option_monthly_9_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_monthly_9_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_monthly_9_response = curl_exec($option_monthly_9_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_monthly_9_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_monthly_9_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_monthly_9_ch);

    // Decodificar la respuesta XML
    $option_monthly_9_response_data_xml = simplexml_load_string($option_monthly_9_response);

    // Convertir SimpleXMLElement a array
    $option_monthly_9_response_data_array = json_decode(json_encode($option_monthly_9_response_data_xml), true);

    $option_monthly_9_json_result = json_encode($option_monthly_9_response_data_array);

    echo "<script>console.log('".$option_monthly_9_json_result."')</script>";

    $option_monthly_9_array_result = json_decode($option_monthly_9_json_result, true);

    if (isset($option_monthly_9_array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($option_monthly_9_array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['option_monthly_9_guardar'])) {
    // Obtener los valores del formulario
    $option_monthly_9_monthly_bank = sanitize_text_field($_POST['option_monthly_9_monthly_bank']);
    $option_monthly_9_monto_form = sanitize_text_field($_POST['option_monthly_9_monto_form']);
    $option_monthly_9_name = sanitize_text_field($_POST['option_monthly_9_nombre']) . ' ' . sanitize_text_field($_POST['option_monthly_9_apellido']);
    $option_monthly_9_account_type = sanitize_text_field($_POST['option_monthly_9_tipoCuenta']);
    $option_monthly_9_account_number = sanitize_text_field($_POST['option_monthly_9_numeroCuenta']);
    $option_monthly_9_bank_name = sanitize_text_field($_POST['option_monthly_9_nombreBanco']);
    $option_monthly_9_id_type = sanitize_text_field($_POST['option_monthly_9_tipoIdentificacion']);
    $option_monthly_9_id_number = sanitize_text_field($_POST['option_monthly_9_numeroIdentificacion']);
    $option_monthly_9_phone_number = sanitize_text_field($_POST['option_monthly_9_numeroTelefono']);
    $option_monthly_9_email = sanitize_text_field($_POST['option_monthly_9_correoElectronico']);
    $option_monthly_9_description = sanitize_text_field($_POST['option_monthly_9_description_bank']);

    $option_monthly_9_gift_email_bank = sanitize_text_field($_POST['option_monthly_9_gift_email_bank']);
    $option_monthly_9_gift_name_bank = sanitize_text_field($_POST['option_monthly_9_gift_name_bank']);
    $option_monthly_9_gift_message_bank = sanitize_text_field($_POST['option_monthly_9_gift_message_bank']);
    $option_monthly_9_is_gift_bank_string = sanitize_text_field($_POST['option_monthly_9_is_gift_bank']);

    $option_monthly_9_is_gift_bank_bool = false;
    if ($option_monthly_9_is_gift_bank_string == "1") {
        $option_monthly_9_is_gift_bank_bool = true;
    } else {
        $option_monthly_9_is_gift_bank_bool = false;
    }

    $option_monthly_9_monthly = "NO";
    if ($option_monthly_9_monthly_bank == "1") {
        $option_monthly_9_monthly = "SI";
    } else {
        $option_monthly_9_monthly = "NO";
    }

    if (strpos($option_monthly_9_description, 'delfin') !== false) {
        $option_monthly_9_description = "DELFIN DE RIO";
    } elseif (strpos($option_monthly_9_description, 'elefantes') !== false) {
        $option_monthly_9_description = "ELEFANTES";
    } elseif (strpos($option_monthly_9_description, 'jaguar') !== false) {
        $option_monthly_9_description = "JAGUAR";
    } elseif (strpos($option_monthly_9_description, 'oso-de-anteojos') !== false) {
        $option_monthly_9_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_monthly_9_description, 'oso-panda') !== false) {
        $option_monthly_9_description = "OSO PANDA";
    } elseif (strpos($option_monthly_9_description, 'tortuga') !== false) {
        $option_monthly_9_description = "TORTUGA MARINA";
    } elseif (strpos($option_monthly_9_description, 'apoyanos') !== false) {
        $option_monthly_9_description = "DONACION GENERAL";
    } elseif (strpos($option_monthly_9_description, 'fondo-incendios') !== false) {
        $option_monthly_9_description = "FONDO DE INCENDIOS";
    } else {
        $option_monthly_9_description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $option_monthly_9_timezone = new DateTimeZone('America/Bogota');
    $option_monthly_9_date = new DateTime('now', $option_monthly_9_timezone);
    $option_monthly_9_date_formatted = $option_monthly_9_date->format('Y-m-d H:i:s');

    $option_monthly_9_day = $option_monthly_9_date->format('d');
    $option_monthly_9_month = $option_monthly_9_date->format('m');
    $option_monthly_9_year = $option_monthly_9_date->format('Y');

    $option_monthly_9_total_date = $option_monthly_9_day . '-' . $option_monthly_9_month . '-' . $option_monthly_9_year;

    $option_monthly_9_format = array('%s');

    $option_monthly_9_table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_monthly_9_table_name_bank_accounts,
        array(
            'name' => $option_monthly_9_name,
            'account_type' => $option_monthly_9_account_type,
            'account_number' => $option_monthly_9_account_number,
            'bank_name' => $option_monthly_9_bank_name,
            'id_type' => $option_monthly_9_id_type,
            'id_number' => $option_monthly_9_id_number,
            'phone_number' => $option_monthly_9_phone_number,
            'email' => $option_monthly_9_email,
            'amount' => $option_monthly_9_monto_form,
            'date_in' => $option_monthly_9_date_formatted,
            'payment_description' => $option_monthly_9_description,
            'monthly' => $option_monthly_9_monthly,
        ),
        $option_monthly_9_format
    );

    $inserted_id = $wpdb->insert_id;

    $option_monthly_9_donation_data = [$option_monthly_9_monthly, $option_monthly_9_monto_form, $inserted_id, $option_monthly_9_total_date];

    $option_monthly_9_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_monthly_9_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_nombreCookieValue = $_COOKIE[$option_monthly_9_nombreCookie];
    }

    $option_monthly_9_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_monthly_9_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_correoCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_correoCookieValue = $_COOKIE[$option_monthly_9_correoCookie];
    }

    $option_monthly_9_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_monthly_9_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_monthly_9_slugCookie])) {
        // Obtener el valor de la cookie
        $option_monthly_9_slugCookieValue = $_COOKIE[$option_monthly_9_slugCookie];
    }

    //----------------------------------------------------------------------------
    $option_monthly_9_aproved = "";
    $option_monthly_9_error = "";
    $option_monthly_9_pending = "";
    $option_monthly_9_expired = "";
    $option_monthly_9_delfin_de_rio = "";
    $option_monthly_9_elefante = "";
    $option_monthly_9_jaguar = "";
    $option_monthly_9_oso = "";
    $option_monthly_9_oso_panda = "";
    $option_monthly_9_tortuga = "";
    $option_monthly_9_apoya_la_causa_wwf = "";
    $option_monthly_9_fondo_incendios = "";

    $option_monthly_9_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_monthly_9_sql = "SELECT * FROM $option_monthly_9_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_monthly_9_results = $wpdb->get_results($option_monthly_9_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_monthly_9_results as $option_monthly_9_result) {
        $option_monthly_9_aproved = $option_monthly_9_result->aproved;
        $option_monthly_9_error = $option_monthly_9_result->error;
        $option_monthly_9_pending = $option_monthly_9_result->pending;
        $option_monthly_9_expired = $option_monthly_9_result->expired;
        $option_monthly_9_delfin_de_rio = $option_monthly_9_result->delfin_de_rio;
        $option_monthly_9_elefante = $option_monthly_9_result->elefante;
        $option_monthly_9_jaguar = $option_monthly_9_result->jaguar;
        $option_monthly_9_oso = $option_monthly_9_result->oso;
        $option_monthly_9_oso_panda = $option_monthly_9_result->oso_panda;
        $option_monthly_9_tortuga = $option_monthly_9_result->tortuga;
        $option_monthly_9_apoya_la_causa_wwf = $option_monthly_9_result->apoya_la_causa_wwf;
        $option_monthly_9_fondo_incendios = $option_monthly_9_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_monthly_9_urlRedirect = $option_monthly_9_aproved;
    if (strpos($option_monthly_9_slugCookieValue, 'delfin') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_delfin_de_rio;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'elefantes') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_elefante;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'jaguar') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_jaguar;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_oso;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'oso-panda') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_oso_panda;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'tortuga') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_tortuga;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'apoyanos') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_apoya_la_causa_wwf;
    } elseif (strpos($option_monthly_9_slugCookieValue, 'fondo-incendios') !== false) {
        $option_monthly_9_urlRedirect = $option_monthly_9_fondo_incendios;
    }

    option_monthly_9_enviar_correo($option_monthly_9_email, $option_monthly_9_slugCookieValue, $option_monthly_9_name, "", "", "", false, "bank_account", $option_monthly_9_donation_data);

    if ($option_monthly_9_is_gift_bank_bool == true) {
        option_monthly_9_enviar_correo($option_monthly_9_gift_email_bank, $option_monthly_9_slugCookieValue, $option_monthly_9_gift_name_bank, $option_monthly_9_gift_name_bank, $option_monthly_9_gift_message_bank, $option_monthly_9_gift_email_bank, true, "", false);
    }

    echo "<script>window.location.assign('".$option_monthly_9_urlRedirect."');</script>";

    //wp_redirect($option_monthly_9_urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html_monthly/html_option_monthly_9.php');

include(plugin_dir_path(__FILE__) . '../css_monthly/css_option_monthly_9.php');
