<?php
global $wpdb;

include_once(plugin_dir_path(__FILE__) . '../functions_option_unique/functions_option_unique_5.php');
//--------------------------------------------------------------------------------------------
if (isset($_GET['transactionState']) && !empty($_GET['transactionState'])) {
    $option_unique_5_aproved = "";
    $option_unique_5_error = "";
    $option_unique_5_pending = "";
    $option_unique_5_expired = "";
    $option_unique_5_delfin_de_rio = "";
    $option_unique_5_elefante = "";
    $option_unique_5_jaguar = "";
    $option_unique_5_oso = "";
    $option_unique_5_oso_panda = "";
    $option_unique_5_tortuga = "";
    $option_unique_5_apoya_la_causa_wwf = "";
    $option_unique_5_fondo_incendios = "";

    $option_unique_5_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_5_sql = "SELECT * FROM $option_unique_5_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_5_results = $wpdb->get_results($option_unique_5_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_5_results as $option_unique_5_result) {
        $option_unique_5_aproved = $option_unique_5_result->aproved;
        $option_unique_5_error = $option_unique_5_result->error;
        $option_unique_5_pending = $option_unique_5_result->pending;
        $option_unique_5_expired = $roption_unique_5_esult->expired;
        $option_unique_5_delfin_de_rio = $option_unique_5_result->delfin_de_rio;
        $option_unique_5_elefante = $option_unique_5_result->elefante;
        $option_unique_5_jaguar = $option_unique_5_result->jaguar;
        $option_unique_5_oso = $option_unique_5_result->oso;
        $option_unique_5_oso_panda = $option_unique_5_result->oso_panda;
        $option_unique_5_tortuga = $option_unique_5_result->tortuga;
        $option_unique_5_apoya_la_causa_wwf = $option_unique_5_result->apoya_la_causa_wwf;
        $option_unique_5_fondo_incendios = $option_unique_5_result->fondo_incendios;
    }

    //--------------------------------------------------------------------------
    $option_unique_5_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_unique_5_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_nombreCookieValue = $_COOKIE[$option_unique_5_nombreCookie];
    }
    //--------------------------------------------------------------------------
    $option_unique_5_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_unique_5_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_correoCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_correoCookieValue = $_COOKIE[$option_unique_5_correoCookie];
    }
    //--------------------------------------------------------------------------
    $option_unique_5_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_unique_5_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_slugCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_slugCookieValue = $_COOKIE[$option_unique_5_slugCookie];
    }
    //--------------------------------------------------------------------------
    $option_unique_5_monthly_Cookie = "option_unique_5_monthly_payu_pse";
    $option_unique_5_monthly_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_monthly_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_monthly_CookieValue = $_COOKIE[$option_unique_5_monthly_Cookie];
    }
    $option_unique_5_monthly_payu_bool = false;
    /*
    if ($option_unique_5_monthly_CookieValue == "1") {
        $option_unique_5_monthly_payu_bool = true;
    } else {
        $option_unique_5_monthly_payu_bool = false;
    }
    */
    //--------------------------------------------------------------------------
    $option_unique_5_amount_Cookie = "option_unique_5_amount_payu_pse";
    $option_unique_5_amount_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_amount_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_amount_CookieValue = $_COOKIE[$option_unique_5_amount_Cookie];
    }
    $option_unique_5_amount = $option_unique_5_amount_CookieValue;
    //--------------------------------------------------------------------------
    $option_unique_5_tipoIdentificacion_Cookie = "option_unique_5_tipoIdentificacionPayu_pse";
    $option_unique_5_tipoIdentificacion_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_tipoIdentificacion_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_tipoIdentificacion_CookieValue = $_COOKIE[$option_unique_5_tipoIdentificacion_Cookie];
    }
    $option_unique_5_tipoIdentificacionPayu = $option_unique_5_tipoIdentificacion_CookieValue;
    //--------------------------------------------------------------------------
    $option_unique_5_numeroIdentificacion_Cookie = "option_unique_5_numeroIdentificacionPayu_pse";
    $option_unique_5_numeroIdentificacion_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_numeroIdentificacion_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_numeroIdentificacion_CookieValue = $_COOKIE[$option_unique_5_numeroIdentificacion_Cookie];
    }
    $option_unique_5_identification = $option_unique_5_numeroIdentificacion_CookieValue;
    //--------------------------------------------------------------------------
    $option_unique_5_gift_email_Cookie = "option_unique_5_gift_email_payu_pse";
    $option_unique_5_gift_email_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_gift_email_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_gift_email_CookieValue = $_COOKIE[$option_unique_5_gift_email_Cookie];
    }
    $option_unique_5_gift_email_payu = $option_unique_5_gift_email_CookieValue;
    //--------------------------------------------------------------------------
    $option_unique_5_gift_name_Cookie = "option_unique_5_gift_name_payu_pse";
    $option_unique_5_gift_name_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_gift_name_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_gift_name_CookieValue = $_COOKIE[$option_unique_5_gift_name_Cookie];
    }
    $option_unique_5_gift_name_payu = $option_unique_5_gift_name_CookieValue;
    //--------------------------------------------------------------------------
    $option_unique_5_gift_message_Cookie = "option_unique_5_gift_message_payu_pse";
    $option_unique_5_gift_message_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_gift_message_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_gift_message_CookieValue = $_COOKIE[$option_unique_5_gift_message_Cookie];
    }
    $option_unique_5_gift_message_payu = $option_unique_5_gift_message_CookieValue;
    //--------------------------------------------------------------------------
    $option_unique_5_is_gift_Cookie = "option_unique_5_is_gift_payu_pse";
    $option_unique_5_is_gift_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_is_gift_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_is_gift_CookieValue = $_COOKIE[$option_unique_5_is_gift_Cookie];
    }

    $option_unique_5_is_gift_payu_bool = false;
    if ($option_unique_5_is_gift_CookieValue == "1") {
        $option_unique_5_is_gift_payu_bool = true;
    } else {
        $option_unique_5_is_gift_payu_bool = false;
    }
    //--------------------------------------------------------------------------
    $option_unique_5_phone_Cookie = "option_unique_5_payerPhone_pse";
    $option_unique_5_phone_CookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_phone_Cookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_phone_CookieValue = $_COOKIE[$option_unique_5_phone_Cookie];
    }

    //--------------------------------------------------------------------------
    $option_unique_5_stateValue = sanitize_text_field($_GET['transactionState']);
    //--------------------------------------------------------------------------
    if ($option_unique_5_stateValue == "4" || $option_unique_5_stateValue == 4) {
        $option_unique_5_urlRedirect = $option_unique_5_aproved;
        if (strpos($option_unique_5_slugCookieValue, 'delfin') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_delfin_de_rio;
        } elseif (strpos($option_unique_5_slugCookieValue, 'elefantes') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_elefante;
        } elseif (strpos($option_unique_5_slugCookieValue, 'jaguar') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_jaguar;
        } elseif (strpos($option_unique_5_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_oso;
        } elseif (strpos($option_unique_5_slugCookieValue, 'oso-panda') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_oso_panda;
        } elseif (strpos($option_unique_5_slugCookieValue, 'tortuga') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_tortuga;
        } elseif (strpos($option_unique_5_slugCookieValue, 'apoyanos') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_apoya_la_causa_wwf;
        } elseif (strpos($option_unique_5_slugCookieValue, 'fondo-incendios') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_unique_5_timezone = new DateTimeZone('America/Bogota');
        $option_unique_5_date = new DateTime('now', $option_unique_5_timezone);
        $option_unique_5_date_formatted = $option_unique_5_date->format('Y-m-d H:i:s');

        $option_unique_5_day = $option_unique_5_date->format('d');
        $option_unique_5_month = $option_unique_5_date->format('m');
        $option_unique_5_year = $option_unique_5_date->format('Y');

        $option_unique_5_total_date = $option_unique_5_day . '-' . $option_unique_5_month . '-' . $option_unique_5_year;

        $inserted_id = "";

        $option_unique_5_donation_data = [$option_unique_5_monthly_payu_bool, $option_unique_5_amount, $inserted_id, $option_unique_5_total_date, $option_unique_5_tipoIdentificacionPayu . ': ' . $option_unique_5_identification];

        option_unique_5_enviar_correo($option_unique_5_correoCookieValue, $option_unique_5_slugCookieValue, $option_unique_5_nombreCookieValue, "", "", "", false, "payu", $option_unique_5_donation_data);

        if ($option_unique_5_is_gift_payu_bool == true) {
            option_unique_5_enviar_correo($option_unique_5_gift_email_payu, $option_unique_5_slugCookieValue, $option_unique_5_gift_name_payu, $option_unique_5_gift_name_payu, $option_unique_5_gift_message_payu, $option_unique_5_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_unique_5_urlRedirect."');</script>";
        //wp_redirect($option_unique_5_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_unique_5_error."');</script>";
        //wp_redirect($option_unique_5_error);
    }

    //----------------------------------------------------------------------------------------
    // Obtener la fecha actual en la zona horaria -5
    $option_unique_5_timezone = new DateTimeZone('America/Bogota');
    $option_unique_5_date = new DateTime('now', $option_unique_5_timezone);
    $option_unique_5_date_formatted = $option_unique_5_date->format('Y-m-d H:i:s');

    $final_status = "No Aprobada";
    if ($option_unique_5_stateValue == "4" || $option_unique_5_stateValue == 4){
        $final_status = "Aprobada";
    }

    $option_unique_5_description = "DONACION GENERAL";
    if (strpos($option_unique_5_slugCookieValue, 'delfin') !== false) {
        $option_unique_5_description = "DELFIN DE RIO";
    } elseif (strpos($option_unique_5_slugCookieValue, 'elefantes') !== false) {
        $option_unique_5_description = "ELEFANTES";
    } elseif (strpos($option_unique_5_slugCookieValue, 'jaguar') !== false) {
        $option_unique_5_description = "JAGUAR";
    } elseif (strpos($option_unique_5_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_unique_5_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_unique_5_slugCookieValue, 'oso-panda') !== false) {
        $option_unique_5_description = "OSO PANDA";
    } elseif (strpos($option_unique_5_slugCookieValue, 'tortuga') !== false) {
        $option_unique_5_description = "TORTUGA MARINA";
    } elseif (strpos($option_unique_5_slugCookieValue, 'apoyanos') !== false) {
        $option_unique_5_description = "DONACION GENERAL";
    } elseif (strpos($option_unique_5_slugCookieValue, 'fondo-incendios') !== false) {
        $option_unique_5_description = "FONDO DE INCENDIOS";
    } else {
        $option_unique_5_description = "DONACION GENERAL";
    }

    $option_unique_5_format = array('%s');

    $option_unique_5_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_unique_5_table_logs,
        array(
            'name' => $option_unique_5_nombreCookieValue,
            'payment_method' => "PSE",
            'id_type' => $option_unique_5_tipoIdentificacionPayu,
            'id_number' => $option_unique_5_identification,
            'phone_number' => $option_unique_5_phone_CookieValue,
            'email' => $option_unique_5_correoCookieValue,
            'amount' => $option_unique_5_amount,
            'payment_description' => $option_unique_5_description,
            'date_in' => $option_unique_5_date_formatted,
            'monthly' => "NO",
            'final_result' => $final_status
        ),
        $option_unique_5_format
    );
    //----------------------------------------------------------------------------------------
    exit;
}
//--------------------------------------------------------------------------------------------
if (isset($_REQUEST['transactionState'])) {
    $option_unique_5_aproved = "";
    $option_unique_5_error = "";
    $option_unique_5_pending = "";
    $option_unique_5_expired = "";
    $option_unique_5_delfin_de_rio = "";
    $option_unique_5_elefante = "";
    $option_unique_5_jaguar = "";
    $option_unique_5_oso = "";
    $option_unique_5_oso_panda = "";
    $option_unique_5_tortuga = "";
    $option_unique_5_apoya_la_causa_wwf = "";
    $option_unique_5_fondo_incendios = "";

    $option_unique_5_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_5_sql = "SELECT * FROM $option_unique_5_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_5_results = $wpdb->get_results($option_unique_5_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_5_results as $option_unique_5_result) {
        $option_unique_5_aproved = $option_unique_5_result->aproved;
        $option_unique_5_error = $option_unique_5_result->error;
        $option_unique_5_pending = $option_unique_5_result->pending;
        $option_unique_5_expired = $option_unique_5_result->expired;
        $option_unique_5_delfin_de_rio = $option_unique_5_result->delfin_de_rio;
        $option_unique_5_elefante = $option_unique_5_result->elefante;
        $option_unique_5_jaguar = $option_unique_5_result->jaguar;
        $option_unique_5_oso = $option_unique_5_result->oso;
        $option_unique_5_oso_panda = $option_unique_5_result->oso_panda;
        $option_unique_5_tortuga = $option_unique_5_result->tortuga;
        $option_unique_5_apoya_la_causa_wwf = $option_unique_5_result->apoya_la_causa_wwf;
        $option_unique_5_fondo_incendios = $option_unique_5_result->fondo_incendios;
    }

    if ($_REQUEST['transactionState']) {

        if ($_REQUEST['transactionState'] == "4") {

            $option_unique_5_nombreCookie = "proyecto_donaciones_colombia_nombre";
            $option_unique_5_nombreCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_unique_5_nombreCookie])) {
                // Obtener el valor de la cookie
                $option_unique_5_nombreCookieValue = $_COOKIE[$option_unique_5_nombreCookie];
            }

            $option_unique_5_correoCookie = "proyecto_donaciones_colombia_correo";
            $option_unique_5_correoCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_unique_5_correoCookie])) {
                // Obtener el valor de la cookie
                $option_unique_5_correoCookieValue = $_COOKIE[$option_unique_5_correoCookie];
            }

            $option_unique_5_slugCookie = "proyecto_donaciones_colombia_slug";
            $option_unique_5_slugCookieValue = '';
            // Verificar si la cookie existe
            if (isset($_COOKIE[$option_unique_5_slugCookie])) {
                // Obtener el valor de la cookie
                $option_unique_5_slugCookieValue = $_COOKIE[$option_unique_5_slugCookie];
            }

            $option_unique_5_urlRedirect = $option_unique_5_aproved;
            if (strpos($option_unique_5_slugCookieValue, 'delfin') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_delfin_de_rio;
            } elseif (strpos($option_unique_5_slugCookieValue, 'elefantes') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_elefante;
            } elseif (strpos($option_unique_5_slugCookieValue, 'jaguar') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_jaguar;
            } elseif (strpos($option_unique_5_slugCookieValue, 'oso-de-anteojos') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_oso;
            } elseif (strpos($option_unique_5_slugCookieValue, 'oso-panda') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_oso_panda;
            } elseif (strpos($option_unique_5_slugCookieValue, 'tortuga') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_tortuga;
            } elseif (strpos($option_unique_5_slugCookieValue, 'apoyanos') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_apoya_la_causa_wwf;
            } elseif (strpos($option_unique_5_slugCookieValue, 'fondo-incendios') !== false) {
                $option_unique_5_urlRedirect = $option_unique_5_fondo_incendios;
            }

            option_unique_5_enviar_correo($option_unique_5_correoCookieValue, $option_unique_5_slugCookieValue, $option_unique_5_nombreCookieValue, false, false);
            echo $option_unique_5_urlRedirect;
            wp_redirect($option_unique_5_urlRedirect);
        } else if ($_REQUEST['transactionState'] == "6" || $_REQUEST['transactionState'] == "104") {
            wp_redirect($option_unique_5_error);
        }
        if ($_REQUEST['transactionState'] == "5") {
            wp_redirect($option_unique_5_expired);
        }
        if ($_REQUEST['transactionState'] == "7") {
            wp_redirect($option_unique_5_pending);
        }

        exit;
    }
}

// Nombre de la tabla
$option_unique_5_table_name_values = $wpdb->prefix . 'values_unique';

// Consulta SQL para obtener los valores de las filas 1, 2 y 3
$option_unique_5_sql = "SELECT * FROM $option_unique_5_table_name_values WHERE id = 1";

$form_type = "option_unique_5";

$id_to_search = intval(substr($form_type, -1));

$option_unique_5_sql = $wpdb->prepare("SELECT * FROM $option_unique_5_table_name_values WHERE id = %d",$id_to_search);

// Ejecutar la consulta
$option_unique_5_result = $wpdb->get_row($option_unique_5_sql);

// Crear un array asociativo para almacenar los resultados
$option_unique_5_values = array();

if ($option_unique_5_result){
    $option_unique_5_values[1] = $option_unique_5_result->value_1;
    $option_unique_5_values[2] = $option_unique_5_result->value_2;
    $option_unique_5_values[3] = $option_unique_5_result->value_3;
    $option_unique_5_values[4] = $option_unique_5_result->value_1;
    $option_unique_5_values[5] = $option_unique_5_result->value_2;
    $option_unique_5_values[6] = $option_unique_5_result->value_3;
}

// Codificar el array en formato JSON para usarlo en JavaScript
$option_unique_5_values_json = json_encode($option_unique_5_values);

$option_unique_5_timezone = new DateTimeZone('America/Bogota');
$option_unique_5_date = new DateTime('now', $option_unique_5_timezone);
$option_unique_5_reference = $option_unique_5_date->format('YmdHis');

//---------------------------------------------------------
// Inicia la sesión
session_start();

$option_unique_5_cookie = "";
// Nombre de la cookie
$option_unique_5_cookieName = 'proyecto_donaciones_colombia';

// Verifica si la cookie existe
if (isset($_COOKIE[$option_unique_5_cookieName])) {
    // Obtiene el valor de la cookie
    $option_unique_5_cookie = $_COOKIE[$option_unique_5_cookieName];

    // Verifica si la sesión asociada a la cookie está activa
    if (session_status() == PHP_SESSION_ACTIVE && $option_unique_5_cookie == session_id()) {
        //echo "La cookie de sesión existe y está activa.";
    } else {
        // La cookie está vencida o no es válida, la borramos y creamos una nueva
        setcookie($option_unique_5_cookieName, '', time() - 3600, '/'); // Borra la cookie
        $option_unique_5_newSessionId = session_regenerate_id(true); // Genera un nuevo ID de sesión
        setcookie($option_unique_5_cookieName, $option_unique_5_newSessionId, time() + 3600, '/'); // Crea una nueva cookie
    }
} else {
    // La cookie no existe, la creamos
    $option_unique_5_sessionId = session_id();
    setcookie($option_unique_5_cookieName, $option_unique_5_sessionId, time() + 3600, '/');
    $option_unique_5_cookie = $_COOKIE[$option_unique_5_cookieName];
}

$option_unique_5_deviceSessionId = md5($option_unique_5_cookie . microtime());

//DConfiguración PAYU---------------------------------------------------------
$option_unique_5_table_payu_settings = $wpdb->prefix . 'payu_settings';
// Consulta SQL para obtener los valores
$option_unique_5_sql = "SELECT * FROM $option_unique_5_table_payu_settings WHERE id = 1";

// Ejecutar la consulta
$option_unique_5_results = $wpdb->get_results($option_unique_5_sql);

// Crear un array asociativo para almacenar los resultados
$option_unique_5_merchantId = "";
$option_unique_5_accountId = "";
$option_unique_5_ApiKey = "";
$option_unique_5_ApiLogin = "";
$option_unique_5_testMode = "";

// Recorrer los resultados y asignar los valores al array
foreach ($option_unique_5_results as $option_unique_5_result) {
    $option_unique_5_merchantId = $option_unique_5_result->merchantId;
    $option_unique_5_accountId = $option_unique_5_result->accountId;
    $option_unique_5_ApiKey = $option_unique_5_result->apiKey;
    $option_unique_5_ApiLogin = $option_unique_5_result->apiLogin;
    $option_unique_5_testMode = $option_unique_5_result->testMode ? "1" : "0";
}

$option_unique_5_setTest = "";
$option_unique_5_url = "";
$option_unique_5_tokenURL = "";
// URL de la API
if ($option_unique_5_testMode == "1") {
    $option_unique_5_setTest = true;
    $option_unique_5_url = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
    $option_unique_5_tokenURL = 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi';
} else {
    $option_unique_5_setTest = false;
    $option_unique_5_url = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
    $option_unique_5_tokenURL = 'https://api.payulatam.com/payments-api/4.0/service.cgi';
}
//Consultar lista de bancos--------------------------------
$option_unique_5_data_bank_list = array(
    'language' => 'es',
    'command' => 'GET_BANKS_LIST',
    'merchant' => array(
        'apiLogin' => $option_unique_5_ApiLogin,
        'apiKey' => $option_unique_5_ApiKey
    ),
    'test' => $option_unique_5_setTest,
    'bankListInformation' => array(
        'paymentMethod' => "PSE",
        'paymentCountry' => 'CO'
    )
);

// Convertir datos a formato JSON
$option_unique_5_json_data_bank_list = json_encode($option_unique_5_data_bank_list);

// Configuración de la solicitud cURL
$option_unique_5_ch_bank_list = curl_init($option_unique_5_url);
curl_setopt($option_unique_5_ch_bank_list, CURLOPT_POST, 1);
curl_setopt($option_unique_5_ch_bank_list, CURLOPT_POSTFIELDS, $option_unique_5_json_data_bank_list);
curl_setopt($option_unique_5_ch_bank_list, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
curl_setopt($option_unique_5_ch_bank_list, CURLOPT_RETURNTRANSFER, true);

// Ejecutar la solicitud cURL y obtener la respuesta
$option_unique_5_response_bank_list = curl_exec($option_unique_5_ch_bank_list);

// Verificar errores en la solicitud cURL
if (curl_errno($option_unique_5_ch_bank_list)) {
    echo 'Error en la solicitud cURL: ' . curl_error($option_unique_5_ch_bank_list);
}

// Cerrar la conexión cURL
curl_close($option_unique_5_ch_bank_list);

// Decodificar la respuesta XML
$option_unique_5_response_data_bank_list_xml = simplexml_load_string($option_unique_5_response_bank_list);

// Convertir SimpleXMLElement a array
$option_unique_5_response_data_bank_list_array = json_decode(json_encode($option_unique_5_response_data_bank_list_xml), true);

$option_unique_5_json_result_bank_list = json_encode($option_unique_5_response_data_bank_list_array);

$option_unique_5_array_result_bank_list = json_decode($option_unique_5_json_result_bank_list, true);

$pseCode = array();
$description = array();

if (isset($option_unique_5_array_result_bank_list['banks']['bank']) && is_array($option_unique_5_array_result_bank_list['banks']['bank'])) {
    foreach ($option_unique_5_array_result_bank_list['banks']['bank'] as $bank) {
        if (isset($bank['pseCode']) && isset($bank['description'])) {
            $pseCodes[] = $bank['pseCode'];
            $descriptions[] = $bank['description'];
        }
    }
}

//---------------------------------------------------------
if (isset($_POST['option_unique_5_payu'])) {
    $option_unique_5_amount = sanitize_text_field($_POST['option_unique_5_amount']);
    //$reference = 'abcde475674675';
    $option_unique_5_reference = sanitize_text_field($_POST['option_unique_5_referenceCode']);
    $option_unique_5_description = sanitize_text_field($_POST['option_unique_5_description']);
    $option_unique_5_notifyUrl = sanitize_text_field($_POST['option_unique_5_responseUrl']);
    $option_unique_5_fullName = sanitize_text_field($_POST['option_unique_5_payerFullName']) . ' ' . sanitize_text_field($_POST['option_unique_5_payerLastName']);

    $option_unique_5_tipoIdentificacionPayu = sanitize_text_field($_POST['option_unique_5_tipoIdentificacionPayu']);

    $option_unique_5_emailAddress = sanitize_text_field($_POST['option_unique_5_buyerEmail']);
    $option_unique_5_contactPhone = sanitize_text_field($_POST['option_unique_5_payerPhone']);
    $option_unique_5_creditCardNumber = sanitize_text_field($_POST['option_unique_5_card_number']);
    $option_unique_5_creditCardSecurityCode = sanitize_text_field($_POST['option_unique_5_cvv_card']);
    $option_unique_5_creditCardExpirationDate = sanitize_text_field($_POST['option_unique_5_expiration_year']) . '/' . sanitize_text_field($_POST['option_unique_5_expiration_month']);
    $option_unique_5_creditCardName = $option_unique_5_fullName;
    $option_unique_5_paymentMethod = sanitize_text_field($_POST['option_unique_5_payment_method_1']);
    $option_unique_5_identification = sanitize_text_field($_POST['option_unique_5_numeroIdentificacionPayu']);

    $option_unique_5_gift_email_payu = sanitize_text_field($_POST['option_unique_5_gift_email_payu']);
    $option_unique_5_gift_name_payu = sanitize_text_field($_POST['option_unique_5_gift_name_payu']);
    $option_unique_5_gift_message_payu = sanitize_text_field($_POST['option_unique_5_gift_message_payu']);
    $option_unique_5_is_gift_payu_string = sanitize_text_field($_POST['option_unique_5_is_gift_payu']);

    $option_unique_5_monthly_payu_string = sanitize_text_field($_POST['option_unique_5_monthly_payu']);

    $option_unique_5_monthly_payu_bool = false;
    if ($option_unique_5_monthly_payu_string == "1") {
        $option_unique_5_monthly_payu_bool = true;
    } else {
        $option_unique_5_monthly_payu_bool = false;
    }

    $option_unique_5_is_gift_payu_bool = false;
    if ($option_unique_5_is_gift_payu_string == "1") {
        $option_unique_5_is_gift_payu_bool = true;
    } else {
        $option_unique_5_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_unique_5_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------
    //Inscribir tarjeta
    if ($option_unique_5_monthly_payu_bool == true) {
        $option_unique_5_tokenData = array(
            "language" => "es",
            "command" => "CREATE_TOKEN",
            "merchant" => array(
                "apiLogin" => $option_unique_5_ApiLogin,
                "apiKey" => $option_unique_5_ApiKey
            ),
            "creditCardToken" => array(
                "payerId" => $option_unique_5_identification,
                "name" => $option_unique_5_fullName,
                "identificationNumber" => $option_unique_5_identification,
                "paymentMethod" => $option_unique_5_paymentMethod,
                "number" => $option_unique_5_creditCardNumber,
                "expirationDate" => $option_unique_5_creditCardExpirationDate
            )
        );

        // Convertir datos a formato JSON
        $option_unique_5_json_data = json_encode($option_unique_5_tokenData);

        // Configuración de la solicitud cURL
        $option_unique_5_ch = curl_init($option_unique_5_tokenURL);
        curl_setopt($option_unique_5_ch, CURLOPT_POST, 1);
        curl_setopt($option_unique_5_ch, CURLOPT_POSTFIELDS, $option_unique_5_json_data);
        curl_setopt($option_unique_5_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($option_unique_5_ch, CURLOPT_RETURNTRANSFER, true);

        // Ejecutar la solicitud cURL y obtener la respuesta
        $option_unique_5_response = curl_exec($option_unique_5_ch);

        // Verificar errores en la solicitud cURL
        if (curl_errno($option_unique_5_ch)) {
            echo 'Error en la solicitud cURL: ' . curl_error($option_unique_5_ch);
        }

        // Cerrar la conexión cURL
        curl_close($option_unique_5_ch);

        // Decodificar la respuesta XML
        $option_unique_5_response_data_xml = simplexml_load_string($option_unique_5_response);

        // Convertir SimpleXMLElement a array
        $option_unique_5_response_data_array = json_decode(json_encode($option_unique_5_response_data_xml), true);

        $option_unique_5_json_result = json_encode($option_unique_5_response_data_array);

        $option_unique_5_array_result = json_decode($option_unique_5_json_result, true);

        $option_unique_5_creditCardToken = "";
        if ($option_unique_5_array_result['creditCardToken']['creditCardTokenId']) {
            $option_unique_5_creditCardToken = $option_unique_5_array_result['creditCardToken']['creditCardTokenId'];
        }

        if ($option_unique_5_creditCardToken != "") {

            $option_unique_5_format = array('%s');

            $option_unique_5_table_name_token = $wpdb->prefix . 'tokensCards';
            // Insertar los datos en la tabla
            $wpdb->insert(
                $option_unique_5_table_name_token,
                array(
                    'document' => $option_unique_5_identification,
                    'token_card' => $option_unique_5_creditCardToken,
                    'amount_to_discount' => $option_unique_5_amount,
                    'discount_day' => date('d'),
                    'payer_name' => $option_unique_5_fullName,
                    'phone_number' => $option_unique_5_contactPhone,
                    'payer_email' => $option_unique_5_emailAddress,
                    'cvv_card' => $option_unique_5_creditCardSecurityCode,
                    'paymentMethod' => $option_unique_5_paymentMethod
                ),
                $option_unique_5_format
            );
        }
    }

    //----------------------------------------------------------------------------------------------

    $option_unique_5_preSignature = $option_unique_5_ApiKey . '~' . $option_unique_5_merchantId . '~' . $option_unique_5_reference . '~' . $option_unique_5_amount . '~' . 'COP';

    $option_unique_5_signature = option_unique_5_sha256($option_unique_5_preSignature);

    //----------------------------------------------

    $option_unique_5_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_unique_5_ApiKey,
            'apiLogin' => $option_unique_5_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_unique_5_accountId,
                'referenceCode' => $option_unique_5_reference,
                'description' => $option_unique_5_description,
                'language' => 'es',
                'signature' => $option_unique_5_signature,
                'notifyUrl' => $option_unique_5_notifyUrl,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => $option_unique_5_amount,
                        'currency' => 'COP'
                    ),
                    'TX_TAX' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    ),
                    'TX_TAX_RETURN_BASE' => array(
                        'value' => 0,
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_unique_5_fullName,
                'emailAddress' => $option_unique_5_emailAddress,
                'contactPhone' => $option_unique_5_contactPhone
            ),
            'creditCard' => array(
                'number' => $option_unique_5_creditCardNumber,
                'securityCode' => $option_unique_5_creditCardSecurityCode,
                'expirationDate' => $option_unique_5_creditCardExpirationDate,
                'name' => $option_unique_5_creditCardName
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => $option_unique_5_paymentMethod,
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_unique_5_deviceSessionId,
            'ipAddress' => $option_unique_5_ipAddress,
            'cookie' => $option_unique_5_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_unique_5_setTest
    );

    // Convertir datos a formato JSON
    $option_unique_5_json_data = json_encode($option_unique_5_data);

    // Configuración de la solicitud cURL
    $option_unique_5_ch = curl_init($option_unique_5_url);
    curl_setopt($option_unique_5_ch, CURLOPT_POST, 1);
    curl_setopt($option_unique_5_ch, CURLOPT_POSTFIELDS, $option_unique_5_json_data);
    curl_setopt($option_unique_5_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_unique_5_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_unique_5_response = curl_exec($option_unique_5_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_unique_5_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_unique_5_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_unique_5_ch);

    // Decodificar la respuesta XML
    $option_unique_5_response_data_xml = simplexml_load_string($option_unique_5_response);

    // Convertir SimpleXMLElement a array
    $option_unique_5_response_data_array = json_decode(json_encode($option_unique_5_response_data_xml), true);

    $option_unique_5_json_result = json_encode($option_unique_5_response_data_array);

    $option_unique_5_array_result = json_decode($option_unique_5_json_result, true);

    $option_unique_5_stateValue = $option_unique_5_array_result['transactionResponse']['state'];

    //----------------------------------------------------------------------------
    $option_unique_5_aproved = "";
    $option_unique_5_error = "";
    $option_unique_5_pending = "";
    $option_unique_5_expired = "";
    $option_unique_5_delfin_de_rio = "";
    $option_unique_5_elefante = "";
    $option_unique_5_jaguar = "";
    $option_unique_5_oso = "";
    $option_unique_5_oso_panda = "";
    $option_unique_5_tortuga = "";
    $option_unique_5_apoya_la_causa_wwf = "";
    $option_unique_5_fondo_incendios = "";

    $option_unique_5_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_5_sql = "SELECT * FROM $option_unique_5_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_5_results = $wpdb->get_results($option_unique_5_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_5_results as $option_unique_5_result) {
        $option_unique_5_aproved = $option_unique_5_result->aproved;
        $option_unique_5_error = $option_unique_5_result->error;
        $option_unique_5_pending = $option_unique_5_result->pending;
        $option_unique_5_expired = $roption_unique_5_esult->expired;
        $option_unique_5_delfin_de_rio = $option_unique_5_result->delfin_de_rio;
        $option_unique_5_elefante = $option_unique_5_result->elefante;
        $option_unique_5_jaguar = $option_unique_5_result->jaguar;
        $option_unique_5_oso = $option_unique_5_result->oso;
        $option_unique_5_oso_panda = $option_unique_5_result->oso_panda;
        $option_unique_5_tortuga = $option_unique_5_result->tortuga;
        $option_unique_5_apoya_la_causa_wwf = $option_unique_5_result->apoya_la_causa_wwf;
        $option_unique_5_fondo_incendios = $option_unique_5_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_unique_5_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_unique_5_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_slugCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_slugCookieValue = $_COOKIE[$option_unique_5_slugCookie];
    }

    if ($option_unique_5_stateValue == "APPROVED") {

        $option_unique_5_nombreCookie = "proyecto_donaciones_colombia_nombre";
        $option_unique_5_nombreCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_unique_5_nombreCookie])) {
            // Obtener el valor de la cookie
            $option_unique_5_nombreCookieValue = $_COOKIE[$option_unique_5_nombreCookie];
        }

        $option_unique_5_correoCookie = "proyecto_donaciones_colombia_correo";
        $option_unique_5_correoCookieValue = '';
        // Verificar si la cookie existe
        if (isset($_COOKIE[$option_unique_5_correoCookie])) {
            // Obtener el valor de la cookie
            $option_unique_5_correoCookieValue = $_COOKIE[$option_unique_5_correoCookie];
        }

        $option_unique_5_urlRedirect = $option_unique_5_aproved;
        if (strpos($option_unique_5_slugCookieValue, 'delfin') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_delfin_de_rio;
        } elseif (strpos($option_unique_5_slugCookieValue, 'elefantes') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_elefante;
        } elseif (strpos($option_unique_5_slugCookieValue, 'jaguar') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_jaguar;
        } elseif (strpos($option_unique_5_slugCookieValue, 'oso-de-anteojos') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_oso;
        } elseif (strpos($option_unique_5_slugCookieValue, 'oso-panda') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_oso_panda;
        } elseif (strpos($option_unique_5_slugCookieValue, 'tortuga') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_tortuga;
        } elseif (strpos($option_unique_5_slugCookieValue, 'apoyanos') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_apoya_la_causa_wwf;
        } elseif (strpos($option_unique_5_slugCookieValue, 'fondo-incendios') !== false) {
            $option_unique_5_urlRedirect = $option_unique_5_fondo_incendios;
        }

        // Obtener la fecha actual en la zona horaria -5
        $option_unique_5_timezone = new DateTimeZone('America/Bogota');
        $option_unique_5_date = new DateTime('now', $option_unique_5_timezone);
        $option_unique_5_date_formatted = $option_unique_5_date->format('Y-m-d H:i:s');

        $option_unique_5_day = $option_unique_5_date->format('d');
        $option_unique_5_month = $option_unique_5_date->format('m');
        $option_unique_5_year = $option_unique_5_date->format('Y');

        $option_unique_5_total_date = $option_unique_5_day . '-' . $option_unique_5_month . '-' . $option_unique_5_year;

        $inserted_id = $wpdb->insert_id;

        $option_unique_5_donation_data = [$option_unique_5_monthly_payu_bool, $option_unique_5_amount, $inserted_id, $option_unique_5_total_date, $option_unique_5_tipoIdentificacionPayu . ': ' . $option_unique_5_identification];

        option_unique_5_enviar_correo($option_unique_5_emailAddress, $option_unique_5_slugCookieValue, $option_unique_5_fullName, "", "", "", false, "payu", $option_unique_5_donation_data);

        if ($option_unique_5_is_gift_payu_bool == true) {
            option_unique_5_enviar_correo($option_unique_5_gift_email_payu, $option_unique_5_slugCookieValue, $option_unique_5_gift_name_payu, $option_unique_5_gift_name_payu, $option_unique_5_gift_message_payu, $option_unique_5_gift_email_payu, true, "", false);
        }

        echo "<script>window.location.assign('".$option_unique_5_urlRedirect."');</script>";
        //wp_redirect($option_unique_5_urlRedirect);
    } else {
        echo "<script>window.location.assign('".$option_unique_5_error."');</script>";
        //wp_redirect($option_unique_5_error);
    }

    // Obtener la fecha actual en la zona horaria -5
    $option_unique_5_timezone = new DateTimeZone('America/Bogota');
    $option_unique_5_date = new DateTime('now', $option_unique_5_timezone);
    $option_unique_5_date_formatted = $option_unique_5_date->format('Y-m-d H:i:s');

    $option_unique_5_monthly = "NO";
    if($option_unique_5_monthly_payu_bool){
        $option_unique_5_monthly = "SI";
    }

    $final_status = "No Aprobada";
    if($option_unique_5_stateValue == "APPROVED"){
        $final_status = "Aprobada";
    }

    if (strpos($option_unique_5_slugCookieValue, 'delfin') !== false) {
        $option_unique_5_description = "DELFIN DE RIO";
    } elseif (strpos($option_unique_5_slugCookieValue, 'elefantes') !== false) {
        $option_unique_5_description = "ELEFANTES";
    } elseif (strpos($option_unique_5_slugCookieValue, 'jaguar') !== false) {
        $option_unique_5_description = "JAGUAR";
    } elseif (strpos($option_unique_5_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_unique_5_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_unique_5_slugCookieValue, 'oso-panda') !== false) {
        $option_unique_5_description = "OSO PANDA";
    } elseif (strpos($option_unique_5_slugCookieValue, 'tortuga') !== false) {
        $option_unique_5_description = "TORTUGA MARINA";
    } elseif (strpos($option_unique_5_slugCookieValue, 'apoyanos') !== false) {
        $option_unique_5_description = "DONACION GENERAL";
    } elseif (strpos($option_unique_5_slugCookieValue, 'fondo-incendios') !== false) {
        $option_unique_5_description = "FONDO DE INCENDIOS";
    } else {
        $option_unique_5_description = "DONACION GENERAL";
    }

    $option_unique_5_format = array('%s');

    $option_unique_5_table_logs = $wpdb->prefix . 'bank_accounts_logs';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_unique_5_table_logs,
        array(
            'name' => $option_unique_5_fullName,
            'payment_method' => "PAYU",
            'id_type' => $option_unique_5_tipoIdentificacionPayu,
            'id_number' => $option_unique_5_identification,
            'phone_number' => $option_unique_5_contactPhone,
            'email' => $option_unique_5_emailAddress,
            'amount' => $option_unique_5_amount,
            'payment_description' => $option_unique_5_description,
            'date_in' => $option_unique_5_date_formatted,
            'monthly' => "NO",
            'final_result' => $final_status
        ),
        $option_unique_5_format
    );

    exit;
}
//Payu PSE----------------------------------------------
if (isset($_POST['option_unique_5_payu_pse'])) {
    $option_unique_5_person_type_pse = sanitize_text_field($_POST['option_unique_5_person_type_pse']);
    $option_unique_5_nombreBanco_pse = sanitize_text_field($_POST['option_unique_5_nombreBanco_pse']);
    $option_unique_5_amount = sanitize_text_field($_POST['option_unique_5_amount_pse']);
    //$reference = 'abcde475674675';
    $option_unique_5_reference = sanitize_text_field($_POST['option_unique_5_referenceCode_pse']);
    $option_unique_5_description = sanitize_text_field($_POST['option_unique_5_description_pse']);
    $option_unique_5_responseUrl = sanitize_text_field($_POST['option_unique_5_responseUrl_pse']);
    $option_unique_5_fullName = sanitize_text_field($_POST['option_unique_5_payerFullName_pse']) . ' ' . sanitize_text_field($_POST['option_unique_5_payerLastName_pse']);

    $option_unique_5_tipoIdentificacionPayu = sanitize_text_field($_POST['option_unique_5_tipoIdentificacionPayu_pse']);

    $option_unique_5_emailAddress = sanitize_text_field($_POST['option_unique_5_buyerEmail_pse']);
    $option_unique_5_contactPhone = sanitize_text_field($_POST['option_unique_5_payerPhone_pse']);
    $option_unique_5_identification = sanitize_text_field($_POST['option_unique_5_numeroIdentificacionPayu_pse']);

    $option_unique_5_gift_email_payu = sanitize_text_field($_POST['option_unique_5_gift_email_payu_pse']);
    $option_unique_5_gift_name_payu = sanitize_text_field($_POST['option_unique_5_gift_name_payu_pse']);
    $option_unique_5_gift_message_payu = sanitize_text_field($_POST['option_unique_5_gift_message_payu_pse']);
    $option_unique_5_is_gift_payu_string = sanitize_text_field($_POST['option_unique_5_is_gift_payu_pse']);

    $option_unique_5_monthly_payu_string = sanitize_text_field($_POST['option_unique_5_monthly_payu_pse']);

    $option_unique_5_monthly_payu_bool = false;
    if ($option_unique_5_monthly_payu_string == "1") {
        $option_unique_5_monthly_payu_bool = true;
    } else {
        $option_unique_5_monthly_payu_bool = false;
    }

    $option_unique_5_is_gift_payu_bool = false;
    if ($option_unique_5_is_gift_payu_string == "1") {
        $option_unique_5_is_gift_payu_bool = true;
    } else {
        $option_unique_5_is_gift_payu_bool = false;
    }

    //$deviceSessionId = 'vghs6tvkcle931686k1900o6e1';
    $option_unique_5_ipAddress = $_SERVER['REMOTE_ADDR'];
    //$cookie = 'pt1t38347bs6jc9ruv2ecpv7o2';

    //----------------------------------------------------------------------------------------------

    $option_unique_5_preSignature = $option_unique_5_ApiKey . '~' . $option_unique_5_merchantId . '~' . $option_unique_5_reference . '~' . $option_unique_5_amount . '~' . 'COP';

    //$option_unique_5_signature = option_unique_5_sha256($option_unique_5_preSignature);
    $option_unique_5_signature = md5($option_unique_5_preSignature);

    //----------------------------------------------

    $option_unique_5_data = array(
        'language' => 'es',
        'command' => 'SUBMIT_TRANSACTION',
        'merchant' => array(
            'apiKey' => $option_unique_5_ApiKey,
            'apiLogin' => $option_unique_5_ApiLogin
        ),
        'transaction' => array(
            'order' => array(
                'accountId' => $option_unique_5_accountId,
                'referenceCode' => $option_unique_5_reference,
                'description' => $option_unique_5_reference,
                'language' => 'es',
                'signature' => $option_unique_5_signature,
                'additionalValues' => array(
                    'TX_VALUE' => array(
                        'value' => intval($option_unique_5_amount),
                        'currency' => 'COP'
                    )
                )
            ),
            'payer' => array(
                'fullName' => $option_unique_5_fullName,
                'emailAddress' => $option_unique_5_emailAddress,
                'contactPhone' => $option_unique_5_contactPhone,
                'dniType' => $option_unique_5_tipoIdentificacionPayu,
                'dniNumber' => $option_unique_5_identification
            ),
            'extraParameters' => array(
                'RESPONSE_URL' => $option_unique_5_responseUrl,
                'PSE_REFERENCE1' => $option_unique_5_ipAddress,
                'FINANCIAL_INSTITUTION_CODE' => $option_unique_5_nombreBanco_pse,
                'USER_TYPE' => $option_unique_5_person_type_pse,
                'PSE_REFERENCE2' => $option_unique_5_tipoIdentificacionPayu,
                'PSE_REFERENCE3' => $option_unique_5_identification
            ),
            'type' => 'AUTHORIZATION_AND_CAPTURE',
            'paymentMethod' => "PSE",
            'paymentCountry' => 'CO',
            'deviceSessionId' => $option_unique_5_deviceSessionId,
            'ipAddress' => $option_unique_5_ipAddress,
            'cookie' => $option_unique_5_cookie,
            'userAgent' => 'Mozilla/5.0 (Windows NT 5.1; rv:18.0) Gecko/20100101 Firefox/18.0'
        ),
        'test' => $option_unique_5_setTest
    );

    // Convertir datos a formato JSON
    $option_unique_5_json_data = json_encode($option_unique_5_data);

    echo "<script>console.log('".$option_unique_5_json_data."')</script>";

    echo "<script>console.log('---------------------------------')</script>";

    // Configuración de la solicitud cURL
    $option_unique_5_ch = curl_init($option_unique_5_url);
    curl_setopt($option_unique_5_ch, CURLOPT_POST, 1);
    curl_setopt($option_unique_5_ch, CURLOPT_POSTFIELDS, $option_unique_5_json_data);
    curl_setopt($option_unique_5_ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($option_unique_5_ch, CURLOPT_RETURNTRANSFER, true);

    // Ejecutar la solicitud cURL y obtener la respuesta
    $option_unique_5_response = curl_exec($option_unique_5_ch);

    // Verificar errores en la solicitud cURL
    if (curl_errno($option_unique_5_ch)) {
        echo 'Error en la solicitud cURL: ' . curl_error($option_unique_5_ch);
    }

    // Cerrar la conexión cURL
    curl_close($option_unique_5_ch);

    // Decodificar la respuesta XML
    $option_unique_5_response_data_xml = simplexml_load_string($option_unique_5_response);

    // Convertir SimpleXMLElement a array
    $option_unique_5_response_data_array = json_decode(json_encode($option_unique_5_response_data_xml), true);

    $option_unique_5_json_result = json_encode($option_unique_5_response_data_array);

    echo "<script>console.log('".$option_unique_5_json_result."')</script>";

    $option_unique_5_array_result = json_decode($option_unique_5_json_result, true);

    if (isset($option_unique_5_array_result['transactionResponse']['extraParameters']['entry'])) {
        $bankUrl = null;

        foreach ($option_unique_5_array_result['transactionResponse']['extraParameters']['entry'] as $entry) {
            if ($entry['string'][0] == 'BANK_URL') {
                $bankUrl = $entry['string'][1];
                break;
            }
        }
        if ($bankUrl !== null) {
            echo "<script>window.location.href = '$bankUrl';</script>";
            exit;
        }
    }
    //----------------------------------------------------------------------------
}
//Fin Payu PSE----------------------------------------------

if (isset($_POST['option_unique_5_guardar'])) {
    // Obtener los valores del formulario
    $option_unique_5_monthly_bank = sanitize_text_field($_POST['option_unique_5_monthly_bank']);
    $option_unique_5_monto_form = sanitize_text_field($_POST['option_unique_5_monto_form']);
    $option_unique_5_name = sanitize_text_field($_POST['option_unique_5_nombre']) . ' ' . sanitize_text_field($_POST['option_unique_5_apellido']);
    $option_unique_5_account_type = sanitize_text_field($_POST['option_unique_5_tipoCuenta']);
    $option_unique_5_account_number = sanitize_text_field($_POST['option_unique_5_numeroCuenta']);
    $option_unique_5_bank_name = sanitize_text_field($_POST['option_unique_5_nombreBanco']);
    $option_unique_5_id_type = sanitize_text_field($_POST['option_unique_5_tipoIdentificacion']);
    $option_unique_5_id_number = sanitize_text_field($_POST['option_unique_5_numeroIdentificacion']);
    $option_unique_5_phone_number = sanitize_text_field($_POST['option_unique_5_numeroTelefono']);
    $option_unique_5_email = sanitize_text_field($_POST['option_unique_5_correoElectronico']);
    $option_unique_5_description = sanitize_text_field($_POST['option_unique_5_description_bank']);

    $option_unique_5_gift_email_bank = sanitize_text_field($_POST['option_unique_5_gift_email_bank']);
    $option_unique_5_gift_name_bank = sanitize_text_field($_POST['option_unique_5_gift_name_bank']);
    $option_unique_5_gift_message_bank = sanitize_text_field($_POST['option_unique_5_gift_message_bank']);
    $option_unique_5_is_gift_bank_string = sanitize_text_field($_POST['option_unique_5_is_gift_bank']);

    $option_unique_5_is_gift_bank_bool = false;
    if ($option_unique_5_is_gift_bank_string == "1") {
        $option_unique_5_is_gift_bank_bool = true;
    } else {
        $option_unique_5_is_gift_bank_bool = false;
    }

    $option_unique_5_monthly = "NO";
    if ($option_unique_5_monthly_bank == "1") {
        $option_unique_5_monthly = "SI";
    } else {
        $option_unique_5_monthly = "NO";
    }

    if (strpos($option_unique_5_description, 'delfin') !== false) {
        $option_unique_5_description = "DELFIN DE RIO";
    } elseif (strpos($option_unique_5_description, 'elefantes') !== false) {
        $option_unique_5_description = "ELEFANTES";
    } elseif (strpos($option_unique_5_description, 'jaguar') !== false) {
        $option_unique_5_description = "JAGUAR";
    } elseif (strpos($option_unique_5_description, 'oso-de-anteojos') !== false) {
        $option_unique_5_description = "OSO DE ANTEOJOS";
    } elseif (strpos($option_unique_5_description, 'oso-panda') !== false) {
        $option_unique_5_description = "OSO PANDA";
    } elseif (strpos($option_unique_5_description, 'tortuga') !== false) {
        $option_unique_5_description = "TORTUGA MARINA";
    } elseif (strpos($option_unique_5_description, 'apoyanos') !== false) {
        $option_unique_5_description = "DONACION GENERAL";
    } elseif (strpos($option_unique_5_description, 'fondo-incendios') !== false) {
        $option_unique_5_description = "FONDO DE INCENDIOS";
    } else {
        $option_unique_5_description = "DONACION GENERAL";
    }
    

    // Obtener la fecha actual en la zona horaria -5
    $option_unique_5_timezone = new DateTimeZone('America/Bogota');
    $option_unique_5_date = new DateTime('now', $option_unique_5_timezone);
    $option_unique_5_date_formatted = $option_unique_5_date->format('Y-m-d H:i:s');

    $option_unique_5_day = $option_unique_5_date->format('d');
    $option_unique_5_month = $option_unique_5_date->format('m');
    $option_unique_5_year = $option_unique_5_date->format('Y');

    $option_unique_5_total_date = $option_unique_5_day . '-' . $option_unique_5_month . '-' . $option_unique_5_year;

    $option_unique_5_format = array('%s');

    $option_unique_5_table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
    // Insertar los datos en la tabla
    $wpdb->insert(
        $option_unique_5_table_name_bank_accounts,
        array(
            'name' => $option_unique_5_name,
            'account_type' => $option_unique_5_account_type,
            'account_number' => $option_unique_5_account_number,
            'bank_name' => $option_unique_5_bank_name,
            'id_type' => $option_unique_5_id_type,
            'id_number' => $option_unique_5_id_number,
            'phone_number' => $option_unique_5_phone_number,
            'email' => $option_unique_5_email,
            'amount' => $option_unique_5_monto_form,
            'date_in' => $option_unique_5_date_formatted,
            'payment_description' => $option_unique_5_description,
            'monthly' => "NO",
        ),
        $option_unique_5_format
    );

    $inserted_id = $wpdb->insert_id;

    $option_unique_5_donation_data = [$option_unique_5_monthly, $option_unique_5_monto_form, $inserted_id, $option_unique_5_total_date];

    $option_unique_5_nombreCookie = "proyecto_donaciones_colombia_nombre";
    $option_unique_5_nombreCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_nombreCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_nombreCookieValue = $_COOKIE[$option_unique_5_nombreCookie];
    }

    $option_unique_5_correoCookie = "proyecto_donaciones_colombia_correo";
    $option_unique_5_correoCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_correoCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_correoCookieValue = $_COOKIE[$option_unique_5_correoCookie];
    }

    $option_unique_5_slugCookie = "proyecto_donaciones_colombia_slug";
    $option_unique_5_slugCookieValue = '';
    // Verificar si la cookie existe
    if (isset($_COOKIE[$option_unique_5_slugCookie])) {
        // Obtener el valor de la cookie
        $option_unique_5_slugCookieValue = $_COOKIE[$option_unique_5_slugCookie];
    }

    //----------------------------------------------------------------------------
    $option_unique_5_aproved = "";
    $option_unique_5_error = "";
    $option_unique_5_pending = "";
    $option_unique_5_expired = "";
    $option_unique_5_delfin_de_rio = "";
    $option_unique_5_elefante = "";
    $option_unique_5_jaguar = "";
    $option_unique_5_oso = "";
    $option_unique_5_oso_panda = "";
    $option_unique_5_tortuga = "";
    $option_unique_5_apoya_la_causa_wwf = "";
    $option_unique_5_fondo_incendios = "";

    $option_unique_5_table_urls = $wpdb->prefix . 'urls';
    // Consulta SQL para obtener los valores
    $option_unique_5_sql = "SELECT * FROM $option_unique_5_table_urls WHERE id = 1";

    // Ejecutar la consulta
    $option_unique_5_results = $wpdb->get_results($option_unique_5_sql);

    // Recorrer los resultados y asignar los valores al array
    foreach ($option_unique_5_results as $option_unique_5_result) {
        $option_unique_5_aproved = $option_unique_5_result->aproved;
        $option_unique_5_error = $option_unique_5_result->error;
        $option_unique_5_pending = $option_unique_5_result->pending;
        $option_unique_5_expired = $option_unique_5_result->expired;
        $option_unique_5_delfin_de_rio = $option_unique_5_result->delfin_de_rio;
        $option_unique_5_elefante = $option_unique_5_result->elefante;
        $option_unique_5_jaguar = $option_unique_5_result->jaguar;
        $option_unique_5_oso = $option_unique_5_result->oso;
        $option_unique_5_oso_panda = $option_unique_5_result->oso_panda;
        $option_unique_5_tortuga = $option_unique_5_result->tortuga;
        $option_unique_5_apoya_la_causa_wwf = $option_unique_5_result->apoya_la_causa_wwf;
        $option_unique_5_fondo_incendios = $option_unique_5_result->fondo_incendios;
    }
    //----------------------------------------------------------------------------

    $option_unique_5_urlRedirect = $option_unique_5_aproved;
    if (strpos($option_unique_5_slugCookieValue, 'delfin') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_delfin_de_rio;
    } elseif (strpos($option_unique_5_slugCookieValue, 'elefantes') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_elefante;
    } elseif (strpos($option_unique_5_slugCookieValue, 'jaguar') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_jaguar;
    } elseif (strpos($option_unique_5_slugCookieValue, 'oso-de-anteojos') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_oso;
    } elseif (strpos($option_unique_5_slugCookieValue, 'oso-panda') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_oso_panda;
    } elseif (strpos($option_unique_5_slugCookieValue, 'tortuga') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_tortuga;
    } elseif (strpos($option_unique_5_slugCookieValue, 'apoyanos') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_apoya_la_causa_wwf;
    } elseif (strpos($option_unique_5_slugCookieValue, 'fondo-incendios') !== false) {
        $option_unique_5_urlRedirect = $option_unique_5_fondo_incendios;
    }

    option_unique_5_enviar_correo($option_unique_5_email, $option_unique_5_slugCookieValue, $option_unique_5_name, "", "", "", false, "bank_account", $option_unique_5_donation_data);

    if ($option_unique_5_is_gift_bank_bool == true) {
        option_unique_5_enviar_correo($option_unique_5_gift_email_bank, $option_unique_5_slugCookieValue, $option_unique_5_gift_name_bank, $option_unique_5_gift_name_bank, $option_unique_5_gift_message_bank, $option_unique_5_gift_email_bank, true, "", false);
    }

    echo "<script>window.location.assign('".$option_unique_5_urlRedirect."');</script>";

    //wp_redirect($option_unique_5_urlRedirect);
    exit;
}

//-------------------------------------------------------------------------------

include(plugin_dir_path(__FILE__) . '../html_unique/html_option_unique_5.php');

include(plugin_dir_path(__FILE__) . '../css_unique/css_option_unique_5.php');
