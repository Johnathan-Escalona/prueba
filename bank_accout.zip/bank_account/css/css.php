<style>
input {
    margin: 5px 0px 0px 0px;
}

div#video-form video {
    height: 150px;
    object-fit: cover;
    border-radius: 15px;
}

/*----------------------------------------------------------------------*/
/* Estilos generales para botones y contenedores */
div#values_container {
    max-width: 480px;
    margin: 0 auto;
    text-align:center;
    transition:all .3s ease-in-out;
}

.fav {
    text-align: center;
    background: #FFF3D7;
    border: 2px dotted #FCBB29;
    border-radius: 20px;
    padding: 5px;
}
.fav span {
    font-family: Open Sans;
    font-size: 11px;
    font-weight: 700;
    color: #D29A1A;
}
/* estilos de pasos*/
#pasosContainer{
    min-height: 40px;
    transition: all .3s linear;
    margin-bottom:10px;
}
#pasosContainer .container-steps{
      display: grid;
    grid-template-columns: 10% 90%;
    gap: 0;
    align-items: center;
    justify-items: center;
}
.container-steps .botones a{
border: 1px solid #000;
    padding: .2em .5em;
    border-radius: 50%;
    cursor: pointer;
}
.container-steps .botones a:hover {
    color: #fcbb29;
    border-color: #fcbb29;
}
.text-pasos h3 {
    font-family: "WWF", Sans-serif;
    font-size: 22px;
    font-weight: 400;
    margin: 0;
    text-align:center;
    color: #000;
}
@media (max-width:425px){
    .text-pasos h3 {
        font-size: 16px;
    }
}
.buttonContainer .myButton {
   min-width: 115px;
    max-width: 130px;
    padding: 10px 3px;
    margin: 5px 0;
}
.buttonContainer.tabs {
    position: relative;
    gap: 0;
    margin-bottom: 15px;
    border-radius: 20px;
    border: 1px solid #00000069;
}
.buttonContainer.tabs .myButton_1 {
    overflow: visible;
    margin: 0;
    border-radius: 0;
    position: relative;
        width: 100%;
}
.buttonContainer.tabs .content-tab {
    width: 100%;
    position: relative;
}
.buttonContainer.tabs button#button1 {
    border-radius: 20px 0 0 20px;
}
.buttonContainer.tabs button#button2 {
    border-radius: 0 20px 20px 0;
}


input#monto{
    width:100%;
}
input#monto {
    border: 2px solid #fcbb29;
}
div#gift_container input, div#gift_container textarea {
    text-align: left;
    padding: 4px 15px;
    border-radius: 10px;
    font-size: 14px;
}

h5.titulos-form {
    font-family: "WWF", sans-serif !important;
    font-size:22px;
    text-align:center;
    margin:0;
}
h3.titular{
    font-family: "WWF", Sans-serif;
    font-size: 25px;
    font-weight: 400;
}

.buttonContainer,
.formButtonContainer {
    display: flex;
    justify-content: center;
    align-items: center;
}

.buttonContainer {
    flex-direction: row;
    align-items: flex-end;
    gap: 5px;
}

.formButtonContainer {
    flex-direction: column;
    margin-block-start: 0rem;
}

.myButton, .myButton_1 {
    font-family: 'Open Sans', sans serif !important;
    width: 90%;
    background-color: rgba(255, 255, 255, 1);
    box-shadow: 0px 3px 8px 0px rgba(0, 0, 0, 0.25);
    color: black;
    border: none;
    font-size: 14px;    
    font-weight: 700;
}

/* nuevas reglas */ 


div#values_container, .formContainer, .formContainer4{
font-family: 'Open Sans', sans serif !important;
}

.otroValor {
    width: 90% !important;
    margin: 0 !important;
}
.divisor{
    width:100%;
    height:1px;
    background: rgb(199 199 199 / 48%);
    margin: 10px 0;
}
.formContainer select,
div#form3 select, 
div#form2 select,
div#form4 select{
    -webkit-appearance: none; /* Ajuste para Safari */
    padding: 10px 15px; /* Ajuste para Safari */
    text-align: center;
    color:#333333d1;
}


div#values_container input, 
.formContainer input,
.formContainer select,
.formContainer4 input,
div#form3 input,
div#form3 select, 
div#form2 input,
div#form2 select,
div#form4 input,
div#form4 select{
    border-radius: 30px;
    font-size: 14px;
    margin-top: 6px;
    min-height: 45px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 2px 11px 0px rgba(0, 0, 0, 0.19) inset;
}

div#values_container input:focus, 
.tipoIdentificacion_1:focus,
.formContainer input:focus, 
.formContainer select:focus, 
.formContainer4 input:focus, 
div#values_container textarea:focus,
div#form3 form input:focus,
div#form3 form select:focus,
div#form2 form input:focus,
div#form2 form select:focus,
div#form4 form input:focus,
div#form4 form select:focus {
    border-color: #fcbb29;
    outline: #fcbb29;
}
input[type="text"]:focus, input[type="password"]:focus, select, textarea, .tipoIdentificacion_1 {
    border-color:#cfcfcf;
    outline: 0;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
}

div#data_user {
    width: 100%;
    display: block;
    text-align: center;
    margin: auto;
}


.titulo-form-2 h5.titulos-form {
    margin-left: -50px;
}

.formButton:hover,
.saveButton:hover {
    background-color: #8fef6c;
}
/* //---------------- paso 2 */
div#form3 form, div#form2 form {
    width: 90% !important;
    margin: 0 auto;
    text-align: left;
}
.titulo-form-2{
    display:grid;
    grid-template-columns: 100%;
    justify-content: center;
    align-items: center;
}

.contForm-nombre, .contForm-tarjerta{
    display: flex;
    gap: 13px;
    justify-content: center;
}
.contForm-tarjerta input{
    width: 33%;
}
.contForm-nombre input {
    width: 50%;
}
.checkbox-T\&C {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 10px;
}
label.politicas {
    font-weight: 600;
    text-align: left;
    font-size: 0.8rem;
}
label.politicas a{
    text-decoration: underline;
    color: #000;
    font-family: Open Sans;
}
.checkbox-T\&C {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 10px;
}
h5.info {
    font-family: Open Sans;
    text-align: left;
    color: #000;
   font-weight: 700;
    font-size: 16px;
    padding: 0 10px;
    margin: 10px 0;
}
h5.info span {
    color:#1257BE;
    font-weight: 700;
}
.formButton,
.saveButton {
    min-width:150px;
    width:100%;
    background-color: #7cde00;
    color: black;
    font-size: 25px;
}

.myButton, .myButton_1,
.formButton,
.saveButton {

    border-radius: 30px;
    margin: 5px;
    padding: 5px 30px;
    transition: background-color 0.3s, color 0.3s; /* Agregamos transición para el cambio de color */
}
[type=button]:focus, [type=button]:hover, [type=submit]:focus, [type=submit]:hover, button:focus, button:hover {
    background-color: inherit;
    border:none;
}

.myButton.active, .myButton_1.active{
    border: none;
    background: rgba(252, 187, 41, 1);
}
[type=button], [type=submit], button{
    border: none;
    outline: none;
}
.myButton:focus, .myButton_1:focus, .formButton:focus , .saveButton:focus{
    border: none;
    outline: none;
}
.formButton.active,
.saveButton.active {
    background-color: #6fb300;
    color: black;
    border: 1px solid lightgrey;
}

.myButton:active, .myButton_1:active,
.formButton:active,
.saveButton:active {
    filter: brightness(80%); /* Cambiamos el brillo al ser presionado */
}

.myButton:hover, .myButton_1:hover {
    background-color: #fcbb29; /* Reemplaza 'your_hover_color' con el color que desees */
    color: black;
}

.formButton.payuButton, button#payu_1 {
    width:100%; /* Este estilo permite que el ancho del botón se ajuste automáticamente al contenido */
    padding: 5px 30px;
    margin:10px auto;
        background: #7cde00;
}

/*----------------------------------------------------------------------*/
/* Estilos específicos para dispositivos con una anchura máxima de 600px (por ejemplo, vista de celular) */
@media (max-width: 768px) {
 .buttonContainer .myButton{
        min-width: 100px !important;
        padding: 8px !important;
        margin: 0 !important;
    }
    .buttonContainer, .formButtonContainer {
        flex-direction: row;
        gap: 5px;
        justify-content: space-evenly;
    }
    .fav{
        padding: 3px 5px;
    }.fav span {
         font-size: 10px;
    }
    .divisor{
        margin: 5px 0;
    }
     
}
/*----------------------------------------------------------------------*/
/* Estilos para formularios y animaciones */
.formContainer,
.formContainer4 {
    justify-content: center;
    align-items: center;
    flex-direction: column;
    text-align: center;
    margin-top: 0px;
    line-height: 1;
}

.formContainer4 {
    display: flex;
    animation: slideDown 0.5s;
}

.formContainer form,
.formContainer4 form {
    background-color: white;
    color: black;
    border-radius: 12px;
    margin: 0px;
    font-size: 15px;
    padding: 0px;
    line-height: 1;
}

/*----------------------------------------------------------------------*/
input[type="text"], input[type="password"], select, textarea{
  background-color: #fff; /* fondo blanco */
  border: 2px solid #ccc; /* borde sólido con un color gris claro */
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.2); /* sombra interior más pronunciada para el estado normal */
  border-radius: 4px; /* bordes redondeados */
  padding: 8px 12px; /* un poco de relleno para hacer que el texto no esté demasiado pegado al borde */
  font-size: 16px; /* un tamaño de fuente legible */
  color: #333; /* color de texto oscuro para contraste con el fondo */
  width: 100%; /* para que ocupe el ancho del contenedor padre */
  box-sizing: border-box; /* asegurarse de que el padding y border no aumenten el ancho total */
  margin-bottom: 10px; /* espacio debajo del input */
  text-align: center; /* centra el texto dentro del input */
}


/*--------------------------------Botones--------------------------------------*/
.donation-options {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.donation-button {
  background-color: #ffffff; /* Botón de fondo blanco */
  color: #333333; /* Texto oscuro para contraste */
  border: 2px solid #cccccc; /* Borde sólido de color gris claro */
  border-radius: 20px; /* Bordes redondeados para estilo de píldora */
  padding: 10px 20px; /* Relleno horizontal y vertical */
  font-size: 16px; /* Tamaño de fuente legible */
  cursor: pointer; /* Cursor de mano para indicar que es un botón */
  margin-right: 10px; /* Espacio entre los botones */
  transition: background-color 0.3s, color 0.3s; /* Transición suave para efectos de hover */
}

.donation-button:last-child {
  margin-right: 0; /* No hay margen a la derecha del último botón */
}

.donation-button:hover {
  background-color: #f5f5f5; /* Color de fondo ligeramente más oscuro en hover */
}

.donation-button-active {
  background-color: #f8d64e; /* Color de fondo amarillo para el botón activo */
  color: #ffffff; /* Texto blanco para contraste */
  border-color: #f8d64e; /* Borde del mismo color que el fondo para el botón activo */
}

/* Estilo para el corazón en el botón Mensual */
.donation-button-active:after {
  content: " ♥"; /* Agrega un corazón después del texto */
  color: #ffffff; /* Color del corazón blanco */
}

.checkbox-container {
    display: flex;
    align-items: center;
}
.checkbox-container svg {
    margin-right: 10px;
}

/* Espaciado entre el checkbox y el texto */
.checkbox-container label {
    font-size: 14px;
    margin-left: 8px;
    font-weight:900;
}

/*----------------------------------------------------------------------*/
@keyframes slideDown {
    0% {
        transform: translateY(-100%);
    }
    100% {
        transform: translateY(0);
    }
}

</style>

<noscript>
   <iframe style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;" src="https://maf.pagosonline.net/ws/fp/tags.js?id=<?php echo $deviceSessionId; ?>80200"></iframe>
</noscript>

<script>
// Convertir el JSON a un objeto de JavaScript
var values = <?php echo $values_json; ?>;

var payment_button_selected = 0;

var payment_method_brand_card_error = document.getElementById("payment_method_brand_card_error");
var payment_method_type_card_error = document.getElementById("payment_method_type_card_error");

var payment_method_type_card = document.getElementById("payment_method_type_card");
var payment_method_brand_card = document.getElementById("payment_method_brand_card");

var button1 = document.getElementById("button1");
var button2 = document.getElementById("button2");
var button3 = document.getElementById("button3");

var buttonSelected = 1;
var buttonSelected_1 = 1;

var monthly_payu = document.getElementById('monthly_payu');
var monthly_bank = document.getElementById('monthly_bank');

var gift_email_bank = document.getElementById('gift_email_bank');
var gift_name_bank = document.getElementById('gift_name_bank');
var gift_message_bank = document.getElementById('gift_message_bank');
var is_gift_bank = document.getElementById('is_gift_bank');

var gift_email_payu = document.getElementById('gift_email_payu');
var gift_name_payu = document.getElementById('gift_name_payu');
var gift_message_payu = document.getElementById('gift_message_payu');
var is_gift_payu = document.getElementById('is_gift_payu');
var is_gift_payu_pse = document.getElementById('is_gift_payu_pse');

var checkbox = document.getElementById('giftCheck');
var giftContainer = document.getElementById('gift_container');
var containerVideo = document.getElementById('video-form');
var giftEmail = document.getElementById('giftEmail');
var whoName = document.getElementById('whoName');
var message = document.getElementById('message');

var monto_form_1 = document.getElementById('monto_form_1');
var monto_form = document.getElementById('monto_form');
var montoInput = document.getElementById('monto');
var montoInputPayu = document.getElementById('amount_payu');
var taxReturnBase =  document.getElementById('taxReturnBase');

var nombre_1 = document.getElementById('nombre_1');
var apellido_1 = document.getElementById('apellido_1');
var tipoIdentificacion_1 = document.getElementById('tipoIdentificacion_1');
var numeroIdentificacion_1 = document.getElementById('numeroIdentificacion_1');
var numeroTelefono_1 = document.getElementById('numeroTelefono_1');
var correoElectronico_1 = document.getElementById('correoElectronico_1');

var name_form = document.getElementById('nombre');
var apellido = document.getElementById('apellido');
var nameInputPayu = document.getElementById('payerFullName');
var lastNameInputPayu = document.getElementById('payerLastName');
var valorDonacion = document.getElementById('valorDonacion');
var valorDonacion_bank = document.getElementById('valorDonacion_bank');

var email_form = document.getElementById('correoElectronico');
var emailInputPayu = document.getElementById('email');

var phone_form = document.getElementById('numeroTelefono');
var phoneInputPayu = document.getElementById('payerPhone');

var payerPhone_pse = document.getElementById('payerPhone_pse');
var email_pse = document.getElementById('email_pse');
var error_person_type = document.getElementById('error_person_type');

var referenceCode = document.getElementById('referenceCode');
var amount_payu = document.getElementById('amount_payu');
var currency = document.getElementById('currency');
var description = document.getElementById('description');
var description_bank = document.getElementById('description_bank');

var values_container = document.getElementById('values_container');

var data_user = document.getElementById('data_user');

var payment_method = document.getElementById('payment_method');
var payment_method_1 = document.getElementById('payment_method_1');
var next_step = document.getElementById('next_step');
var next_step_1 = document.getElementById('next_step_1');
var cvv = document.getElementById('cvv');
/* nuevas variables para titulos de pasos */
var customTitle = document.getElementById('customTitle');
var pasosContainer = document.getElementById('pasosContainer');
var paso_text1 = document.getElementById('paso-text1');
var paso_text2 = document.getElementById('paso-text2');
/**/

var amount_payu_pse = document.getElementById('amount_payu_pse');

var gift_name_payu_pse = document.getElementById('gift_name_payu_pse');

var payerFullName_pse = document.getElementById('payerFullName_pse');
var payerLastName_pse = document.getElementById('payerLastName_pse');

var form2 = document.getElementById('form2');
var form3 = document.getElementById('form3');
var form4 = document.getElementById('form4');

var person_type = document.getElementById('person_type');
var person_type_pse = document.getElementById('person_type_pse');

var info_form = document.getElementById('info_form');

var guardar = document.getElementById('guardar');
var guardar_1 = document.getElementById('guardar_1');
var guardar_2 = document.getElementById('guardar_2');
var atras = document.getElementById('atras');

var nombreBanco_pse = document.getElementById('nombreBanco_pse');

var numeroCuenta = document.getElementById('numeroCuenta');
var nombreBanco = document.getElementById('nombreBanco');
var nombreBanco_1 = document.getElementById('nombreBanco_1');
var numeroIdentificacion = document.getElementById('numeroIdentificacion');

var payu = document.getElementById('payu');
var payu_1 = document.getElementById('payu_1');
var payu_2 = document.getElementById('payu_2');
var payu_2_form = document.getElementById('payu_2_form');

var payu_pse = document.getElementById('payu_pse');

var numeroIdentificacionPayu = document.getElementById('numeroIdentificacionPayu');

var numeroIdentificacionPayu_pse = document.getElementById('numeroIdentificacionPayu_pse');

var responseUrl = document.getElementById('responseUrl');
var responseUrl_pse = document.getElementById('responseUrl_pse');
var confirmationUrl = document.getElementById('confirmationUrl');

var card_number = document.getElementById('card_number');
var cvv_card = document.getElementById('cvv_card');
var expiration_month = document.getElementById('expiration_month');
var expiration_year = document.getElementById('expiration_year');
var tyc = document.getElementById('t&c');
var tyc_form = document.getElementById('t&c_form');
var tyc_bank = document.getElementById('t&c_bank');
var info_payu = document.getElementById('info_payu');
var info_bank = document.getElementById('info_bank');

var error_nombreBanco_1 = document.getElementById('error_nombreBanco_1');

var error_email_gift_1 = document.getElementById('error_email_gift_1');
var error_email_gift_2 = document.getElementById('error_email_gift_2');
var error_whoName_gift = document.getElementById('error_whoName_gift');
var error_message_gift = document.getElementById('error_message_gift');

var gift_email_payu_pse = document.getElementById('gift_email_payu_pse');

var error_monto_1 = document.getElementById('error_monto_1');
var error_monto_2 = document.getElementById('error_monto_2');
var error_monto_3 = document.getElementById('error_monto_3');
var error_monto_4 = document.getElementById('error_monto_4');

var error_nombre_1 = document.getElementById('error_nombre_1');
var error_nombre_2 = document.getElementById('error_nombre_2');

var error_numeroCuenta_1 = document.getElementById('error_numeroCuenta_1');
var error_numeroCuenta_2 = document.getElementById('error_numeroCuenta_2');

var error_numeroIdentificacion_1 = document.getElementById('error_numeroIdentificacion_1');
var error_numeroIdentificacion_2 = document.getElementById('error_numeroIdentificacion_2');

var error_numeroTelefono_1 = document.getElementById('error_numeroTelefono_1');
var error_numeroTelefono_2 = document.getElementById('error_numeroTelefono_2');
var error_numeroTelefono_3 = document.getElementById('error_numeroTelefono_3');

var error_correoElectronico_1 = document.getElementById('error_correoElectronico_1');
var error_correoElectronico_2 = document.getElementById('error_correoElectronico_2');
var error_checkbox_TyC_1 = document.getElementById('error_checkbox-T&C_1');

var error_payerFullName_1 = document.getElementById('error_payerFullName_1');
var error_payerFullName_2 = document.getElementById('error_payerFullName_2');

var error_numeroIdentificacionPayu_1 = document.getElementById('error_numeroIdentificacionPayu_1');
var error_numeroIdentificacionPayu_2 = document.getElementById('error_numeroIdentificacionPayu_2');

var error_payerPhone_1 = document.getElementById('error_payerPhone_1');
var error_payerPhone_2 = document.getElementById('error_payerPhone_2');

var error_email_1 = document.getElementById('error_email_1');
var error_email_2 = document.getElementById('error_email_2');

var error_card_number_1 = document.getElementById('error_card_number_1');
var error_card_number_2 = document.getElementById('error_card_number_2');

var error_cvv_card_1 = document.getElementById('error_cvv_card_1');
var error_cvv_card_2 = document.getElementById('error_cvv_card_2');

var error_expiration_month_1 = document.getElementById('error_expiration_month_1');
var error_expiration_month_2 = document.getElementById('error_expiration_month_2');
var error_expiration_month_3 = document.getElementById('error_expiration_month_3');
var error_expiration_month_4 = document.getElementById('error_expiration_month_4');

var tipoIdentificacionPayu_pse = document.getElementById('tipoIdentificacionPayu_pse');

var error_expiration_year_1 = document.getElementById('error_expiration_year_1');
var error_expiration_year_2 = document.getElementById('error_expiration_year_2');
var error_expiration_year_3 = document.getElementById('error_expiration_year_3');

var error_tyc = document.getElementById('error_t&c');

var error_tyc_form = document.getElementById('error_t&c_form');

var error_expired_card = document.getElementById('error_expired_card');

var error_payment_method = document.getElementById('error_payment_method');

var monthly_payu_pse = document.getElementById('monthly_payu_pse');

var tipoIdentificacionPayu = document.getElementById('tipoIdentificacionPayu');
var error_id_type_payu = document.getElementById('error_id_type_payu');

var tipoCuenta = document.getElementById('tipoCuenta');
var error_account_type = document.getElementById('error_account_type');

var error_bank_name = document.getElementById('error_bank_name');

var tipoIdentificacion = document.getElementById('tipoIdentificacion');
var error_id_type_bank = document.getElementById('error_id_type_bank');

var checkbox_TyC_form = document.getElementById('checkbox-T&C_form');

responseUrl.value = window.location.href;
responseUrl_pse.value = window.location.href;
confirmationUrl.value = window.location.href;

var currentUrl = window.location.href;
currentUrl = currentUrl.replace("https://", "");
var tokens = currentUrl.split("/");

//------------------------------------------
button1.innerHTML = '$ ' + parseInt(values[1 + payment_button_selected], 10).toLocaleString('es-ES');
button2.innerHTML = '$ ' + parseInt(values[2 + payment_button_selected], 10).toLocaleString('es-ES');
button3.innerHTML = '$ ' + parseInt(values[3 + payment_button_selected], 10).toLocaleString('es-ES');

description.value = tokens[tokens.length - 2];
description_bank.value = tokens[tokens.length - 2];

payment_method_1.value = payment_method.value;

// Verificar si la cookie existe
var cookieExistente = getCookie("proyecto_donaciones_colombia_slug");

// Eliminar la cookie existente si hay una
if (cookieExistente) {
    document.cookie = "proyecto_donaciones_colombia_slug=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
}

// Crear la nueva cookie
document.cookie = "proyecto_donaciones_colombia_slug=" + encodeURIComponent(tokens[tokens.length - 2]) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";

var buttons = document.querySelectorAll('.myButton');
buttons[1].classList.add('active');
buttons.forEach((button) => {
    button.addEventListener('click', (event) => {
        buttons.forEach((button) => {
            button.classList.remove('active');
        });
        event.target.classList.add('active');

        montoInput.style.borderColor = "#FCBB29";
        error_monto_1.style.display = "none";
        error_monto_2.style.display = "none";
        error_monto_3.style.display = "none";
        error_monto_4.style.display = "none";

        buttonSelected = Array.from(buttons).indexOf(event.target);
        if(buttonSelected >= 0 && buttonSelected < 3){
            montoInput.value = "";
            monto_form.value = values[buttonSelected+1+payment_button_selected];
            monto_form_1.value = values[buttonSelected+1+payment_button_selected];
            montoInputPayu.value = values[buttonSelected+1+payment_button_selected];
            amount_payu_pse.value = values[buttonSelected+1+payment_button_selected];
            //taxReturnBase.value =  values[buttonSelected+1];
        }
        //------------------------------------------
    });
});
//-------------------------------------------------------------------------------
montoInput.addEventListener('click', () => {

    buttons.forEach((button) => {
        button.classList.remove('active');
    });
    buttonSelected = 3;
    monto_form.value = montoInput.value;
    monto_form_1.value = montoInput.value;
    montoInputPayu.value = montoInput.value;
    amount_payu_pse.value = montoInput.value;
    //taxReturnBase.value =  montoInput.value;

});
//-------------------------------------------------------------------------------
var buttons_1 = document.querySelectorAll('.myButton_1');

buttons_1[1].classList.add('active');
buttons_1.forEach((button) => {
    button.addEventListener('click', (event) => {
        buttons_1.forEach((button) => {
            button.classList.remove('active');
        });
        event.target.classList.add('active');
        buttonSelected_1 = Array.from(buttons_1).indexOf(event.target);
        
        if (buttonSelected_1 == 1){
            payment_button_selected = 0;

            montoInput.style.borderColor = "#FCBB29";
            error_monto_3.style.display = "none";
            error_monto_4.style.display = "none";

            nombreBanco.innerHTML = '';
            var options = [
                {text: 'BANCO DE BOGOTÁ', value: 'BANCO DE BOGOTÁ'},
                {text: 'BANCO POPULAR', value: 'BANCO POPULAR'},
                {text: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCOLOMBIA S.A.', value: 'BANCOLOMBIA S.A.'},
                {text: 'BANCO GNB SUDAMERIS S.A.', value: 'BANCO GNB SUDAMERIS S.A.'},
                {text: 'BBVA COLOMBIA', value: 'BBVA COLOMBIA'},
                {text: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCO COLPATRIA', value: 'BANCO COLPATRIA'},
                {text: 'BANCO DE OCCIDENTE', value: 'BANCO DE OCCIDENTE'},
                {text: 'BANCOLDEX', value: 'BANCOLDEX'},
                {text: 'BANCO CAJA SOCIAL - BCSC S.A.', value: 'BANCO CAJA SOCIAL - BCSC S.A.'},
                {text: 'BANCO AGRARIO DE COLOMBIA S.A.', value: 'BANCO AGRARIO DE COLOMBIA S.A.'},
                {text: 'BANCO DAVIVIENDA S.A.', value: 'BANCO DAVIVIENDA S.A.'},
                {text: 'BANCO AV VILLAS', value: 'BANCO AV VILLAS'},
                {text: 'BANCOOMEVA', value: 'BANCOOMEVA'},
                {text: 'BANCO FALABELLA S.A.', value: 'BANCO FALABELLA S.A.'},
                {text: 'BANCO MUNDO MUJER', value: 'BANCO MUNDO MUJER'},
                {text: 'BANCO MULTIBANK', value: 'BANCO MULTIBANK'},
                {text: 'BANCO SANTANDER NEGOCIOS COLOMBIA', value: 'BANCO SANTANDER NEGOCIOS COLOMBIA'},
                {text: 'BANCO COOPERATIVO COOPENTRAL', value: 'BANCO COOPERATIVO COOPENTRAL'},
                {text: 'BANCO COMPARTIR SA', value: 'BANCO COMPARTIR SA'},
                {text: 'BANCO SERFINANZA SA', value: 'BANCO SERFINANZA SA'},
                {text: 'FINANCIERA JURISCOOP', value: 'FINANCIERA JURISCOOP'},
                {text: 'COOPERATIVA FINANCIERA ANTIOQUIA', value: 'COOPERATIVA FINANCIERA ANTIOQUIA'},
                {text: 'CONTRAFA', value: 'CONTRAFA'},
                {text: 'BANCO CONFIAR', value: 'BANCO CONFIAR'},
                {text: 'COLTEFINANCIERA', value: 'COLTEFINANCIERA'},
                {text: 'Deceval S.A', value: 'Deceval S.A'},
                {text: 'DTN', value: 'DTN'},
                {text: 'DGCPTN SISTEMA GENERAL DE REGALIAS', value: 'DGCPTN SISTEMA GENERAL DE REGALIAS'},
            ];

            for (var i = 0; i < options.length; i++) {
                var option = document.createElement('option');
                option.value = options[i].value;
                option.text = options[i].text;
                nombreBanco.appendChild(option);
            }

            payment_method.innerHTML = '';

            var defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.text = "Seleccione el método de pago";
            defaultOption.disabled = true;
            defaultOption.selected = true;
            payment_method.appendChild(defaultOption);

            var options_payment = [
                {text: 'tarjeta', value: 'Tarjeta'},
                {text: 'Cuenta Bancaria', value: 'Cuenta de banco'},
            ];

            for (var i = 0; i < options_payment.length; i++) {
                var option = document.createElement('option');
                option.value = options_payment[i].value;
                option.text = options_payment[i].text;
                payment_method.appendChild(option);
            }
        }
        else
        {
            payment_button_selected = 3;

            montoInput.style.borderColor = "#FCBB29";
            error_monto_3.style.display = "none";
            error_monto_4.style.display = "none";

            nombreBanco.innerHTML = '';
            var options = [
                {text: 'BANCO DE BOGOTÁ', value: 'BANCO DE BOGOTÁ'},
                {text: 'BANCO POPULAR', value: 'BANCO POPULAR'},
                {text: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCOLOMBIA S.A.', value: 'BANCOLOMBIA S.A.'},
                {text: 'BANCO GNB SUDAMERIS S.A.', value: 'BANCO GNB SUDAMERIS S.A.'},
                {text: 'BBVA COLOMBIA', value: 'BBVA COLOMBIA'},
                {text: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCO COLPATRIA', value: 'BANCO COLPATRIA'},
                {text: 'BANCO DE OCCIDENTE', value: 'BANCO DE OCCIDENTE'},
                {text: 'BANCOLDEX', value: 'BANCOLDEX'},
                {text: 'BANCO CAJA SOCIAL - BCSC S.A.', value: 'BANCO CAJA SOCIAL - BCSC S.A.'},
                {text: 'BANCO AGRARIO DE COLOMBIA S.A.', value: 'BANCO AGRARIO DE COLOMBIA S.A.'},
                {text: 'BANCO DAVIVIENDA S.A.', value: 'BANCO DAVIVIENDA S.A.'},
                {text: 'BANCO AV VILLAS', value: 'BANCO AV VILLAS'},
                {text: 'BANCOOMEVA', value: 'BANCOOMEVA'},
                {text: 'BANCO FALABELLA S.A.', value: 'BANCO FALABELLA S.A.'},
                {text: 'BANCO MUNDO MUJER', value: 'BANCO MUNDO MUJER'},
                {text: 'BANCO MULTIBANK', value: 'BANCO MULTIBANK'},
                {text: 'BANCO SANTANDER NEGOCIOS COLOMBIA', value: 'BANCO SANTANDER NEGOCIOS COLOMBIA'},
                {text: 'BANCO COOPERATIVO COOPENTRAL', value: 'BANCO COOPERATIVO COOPENTRAL'},
                {text: 'BANCO COMPARTIR SA', value: 'BANCO COMPARTIR SA'},
                {text: 'BANCO SERFINANZA SA', value: 'BANCO SERFINANZA SA'},
                {text: 'FINANCIERA JURISCOOP', value: 'FINANCIERA JURISCOOP'},
                {text: 'RAPPIPAY', value: 'RAPPIPAY'},
                {text: 'COOPERATIVA FINANCIERA ANTIOQUIA', value: 'COOPERATIVA FINANCIERA ANTIOQUIA'},
                {text: 'CONTRAFA', value: 'CONTRAFA'},
                {text: 'BANCO CONFIAR', value: 'BANCO CONFIAR'},
                {text: 'COLTEFINANCIERA', value: 'COLTEFINANCIERA'},
                {text: 'NEQUI BANCOLOMBIA', value: 'NEQUI BANCOLOMBIA'},
                {text: 'Deceval S.A', value: 'Deceval S.A'},
                {text: 'DAVIPLATA', value: 'DAVIPLATA'},
                {text: 'DTN', value: 'DTN'},
                {text: 'DGCPTN SISTEMA GENERAL DE REGALIAS', value: 'DGCPTN SISTEMA GENERAL DE REGALIAS'},
            ];

            for (var i = 0; i < options.length; i++) {
                var option = document.createElement('option');
                option.value = options[i].value;
                option.text = options[i].text;
                nombreBanco.appendChild(option);
            }

            payment_method.innerHTML = '';

            var defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.text = "Seleccione el método de pago";
            defaultOption.disabled = true;
            defaultOption.selected = true;
            payment_method.appendChild(defaultOption);

            var options_payment = [
                {text: 'tarjeta', value: 'Tarjeta'},
                {text: 'Cuenta Bancaria', value: 'Cuenta de banco'},
                {text: 'PSE', value: 'PSE'},
            ];

            for (var i = 0; i < options_payment.length; i++) {
                var option = document.createElement('option');
                option.value = options_payment[i].value;
                option.text = options_payment[i].text;
                payment_method.appendChild(option);
            }
        }

        button1.innerHTML = '$ ' + parseInt(values[1 + payment_button_selected], 10).toLocaleString('es-ES');
        button2.innerHTML = '$ ' + parseInt(values[2 + payment_button_selected], 10).toLocaleString('es-ES');
        button3.innerHTML = '$ ' + parseInt(values[3 + payment_button_selected], 10).toLocaleString('es-ES');

        monthly_payu.value = buttonSelected_1.toString();

        monthly_bank.value = buttonSelected_1.toString();

    });
});
//-------------------------------------------------------------------------------
checkbox.addEventListener('change', function() {
    // Verificar si el checkbox está marcado
    if (checkbox.checked) {
        // Mostrar el contenedor del regalo
        giftContainer.style.display = 'block';
        containerVideo.style.display = 'none';
        is_gift_bank.value = "1";
        is_gift_payu.value = "1";
        is_gift_payu_pse.value = "1";
    } else {
        // Ocultar el contenedor del regalo
        giftContainer.style.display = 'none';
        containerVideo.style.display = 'block';
        is_gift_bank.value = "0";
        is_gift_payu.value = "0";
        is_gift_payu_pse.value = "0";
    }
});
//-------------------------------------------------------------------------------
buttons.forEach((button, index) => {
    button.addEventListener('click', (event) => {
        buttons.forEach((button) => {
            button.classList.remove('active');
        });
        event.target.classList.add('active');

        buttonSelected = index;  // Aseguramos que buttonSelected refleje el índice del botón general seleccionado
    });
});
//-------------------------------------------------------------------------------
montoInput.addEventListener("input", function() {
    if (buttonSelected === 3){

        montoInput.style.borderColor = "#FCBB29";
        error_monto_1.style.display = "none";
        error_monto_2.style.display = "none";
        error_monto_3.style.display = "none";
        error_monto_4.style.display = "none";

        var value = montoInput.value;

        // Remover caracteres que no sean números o punto
        value = value.replace(/[^0-9]/g, '');

        // Formatear el número con puntos de miles
        value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');

        // Añadir el signo de pesos al principio
        montoInput.value = '$' + value;

        monto_form.value = montoInput.value.replace(/\$|\./g, '');
        montoInputPayu.value = montoInput.value.replace(/\$|\./g, '');
        amount_payu_pse.value = montoInput.value.replace(/\$|\./g, '');
        //taxReturnBase.value =  montoInput.value;

        montoInput.focus()
        montoInput.setSelectionRange(montoInput.value.length, montoInput.value.length);

    }
    //------------------------------------------
});
//-------------------------------------------------------------------------------
nombre_1.addEventListener("input", function() {
    // Verificar si la cookie existe
    var cookieExistente = getCookie("proyecto_donaciones_colombia_nombre");

    // Eliminar la cookie existente si hay una
    if (cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_nombre=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_nombre=" + encodeURIComponent(nombre_1.value + " " + apellido_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
});
//-------------------------------------------------------------------------------
apellido_1.addEventListener("input", function() {
    // Verificar si la cookie existe
    var cookieExistente = getCookie("proyecto_donaciones_colombia_nombre");

    // Eliminar la cookie existente si hay una
    if (cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_nombre=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_nombre=" + encodeURIComponent(nombre_1.value + " " + apellido_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
});
//-------------------------------------------------------------------------------
correoElectronico_1.addEventListener("input", function() {

    // Verificar si la cookie existe
    var cookieExistente = getCookie("proyecto_donaciones_colombia_correo");

    // Eliminar la cookie existente si hay una
    if (cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_correo=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_correo=" + encodeURIComponent(correoElectronico_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";

});
//-------------------------------------------------------------------------------
correoElectronico_1.addEventListener("input", function() {

    // Verificar si la cookie existe
    var cookieExistente = getCookie("proyecto_donaciones_colombia_correo");

    // Eliminar la cookie existente si hay una
    if (cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_correo=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_correo=" + encodeURIComponent(correoElectronico_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";

});
//-------------------------------------------------------------------------------
next_step.addEventListener('click', () => {
    
    if (checkbox.checked) {
        if(giftEmail.value === ""){
            giftEmail.style.borderColor = "red";
            error_email_gift_1.style.display = "block";
            return;
        }
        else{
            giftEmail.style.borderColor = "#cfcfcf";
            error_email_gift_1.style.display = "none";
        }

        var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (patronEmail.test(giftEmail.value) === false){
            giftEmail.style.borderColor = "red";
            error_email_gift_2.style.display = "block";
            return;
        }
        else{
            giftEmail.style.borderColor = "#cfcfcf";
            error_email_gift_2.style.display = "none";
        }

        if(whoName.value === ""){
            whoName.style.borderColor = "red";
            error_whoName_gift.style.display = "block";
            return;
        }
        else{
            whoName.style.borderColor = "#cfcfcf";
            error_whoName_gift.style.display = "none";
        }

        /*
        if(message.value === ""){
            message.style.borderColor = "red";
            error_message_gift.style.display = "block";
            return;
        }
        else{
            message.style.borderColor = "#cfcfcf";
            error_message_gift.style.display = "none";
        }
        */
    }

    if(buttonSelected === 3){
        if (montoInput.value === ""){
            montoInput.style.borderColor = "red";
            error_monto_1.style.display = "block";
            return;
        }
        else{
            montoInput.style.borderColor = "#FCBB29";
            error_monto_1.style.display = "none";
        }

        var regex = /^\$\d{1,3}(?:\.\d{3})*$/;

        if (!regex.test(montoInput.value)) {
            montoInput.style.borderColor = "red";
            error_monto_2.style.display = "block";
            return;
        }
        else{
            montoInput.style.borderColor = "#FCBB29";
            error_monto_2.style.display = "none";
        }

        if (parseInt(montoInput.value.replace(/\$|\./g, ''), 10) < values[1 + payment_button_selected] && buttonSelected_1 == 1){
            montoInput.style.borderColor = "red";
            error_monto_3.textContent = "El monto a donar debe ser mayor a " + parseInt(values[1 + payment_button_selected], 10).toLocaleString('es-ES') + " COP";

            error_monto_3.style.display = "block";
            return;
        }
        if (parseInt(montoInput.value.replace(/\$|\./g, ''), 10) < values[1 + payment_button_selected] && buttonSelected_1 == 0){
            montoInput.style.borderColor = "red";
            error_monto_4.textContent = "El monto a donar debe ser mayor a " + parseInt(values[1 + payment_button_selected], 10).toLocaleString('es-ES') + " COP";
            error_monto_4.style.display = "block";
            return;
        }
        else{
            montoInput.style.borderColor = "#FCBB29";
            error_monto_3.style.display = "none";
            error_monto_4.style.display = "none";
        }
    }

    var string_1 = '';
    if(buttonSelected >= 0 && buttonSelected < 3){
        var number_1 = parseInt(values[buttonSelected+1+payment_button_selected])
        string_1 = number_1.toLocaleString('es-ES') + ' COP';
    }
    else{
        var number_1 = parseInt(montoInput.value.replace(/\$|\./g, ''));
        string_1 = number_1.toLocaleString('es-ES') + ' COP';
    }

    if (buttonSelected_1 == 0){
        info_payu.innerHTML = 'Estas donando: <span id="valorDonacion">'+string_1+'</span>';
        info_bank.innerHTML = 'Estas donando: <span id="valorDonacion_bank">'+string_1+'</span>';
        info_form.innerHTML = 'Estas donando: <span id="valorDonacion_form">'+string_1+'</span>';
        
    }
    else{
        info_payu.innerHTML = 'Estas donando mensualmente: <span id="valorDonacion">'+string_1+'</span>';
        info_bank.innerHTML = 'Estas donando mensualmente: <span id="valorDonacion_bank">'+string_1+'</span>';
        info_form.innerHTML = 'Estas donando mensualmente: <span id="valorDonacion_form">'+string_1+'</span>';
    }

    values_container.style.display = 'none';
    form4.style.display = 'block';
    pasosContainer.style.display = 'block';
    customTitle.style.display='none';
    paso_text1.style.display='block'; 


});
//-------------------------------------------------------------------------------
atras.addEventListener('click', () => {
    if(form2.style.display == 'block' || form3.style.display == 'block'){
        form4.style.display = 'block';
        paso_text1.style.display = 'block';
        form2.style.display = 'none';
        form3.style.display = 'none';
        paso_text2.style.display = 'none';
    }
    else{
        values_container.style.display = 'block';
        customTitle.style.display='block'
        form4.style.display = 'none';        
        pasosContainer.style.display = 'none';
    }
});
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
payu_1.addEventListener('click', () => {

    if (nameInputPayu.value === ""){
        nameInputPayu.style.borderColor = "red";
        error_payerFullName_1.style.display = "block";
        return;
    }
    else{
        nameInputPayu.style.borderColor = "#cfcfcf";
        error_payerFullName_1.style.display = "none";
    }

    if (lastNameInputPayu.value === ""){
        lastNameInputPayu.style.borderColor = "red";
        error_payerFullName_2.style.display = "block";
        return;
    }
    else{
        lastNameInputPayu.style.borderColor = "#cfcfcf";
        error_payerFullName_2.style.display = "none";
    }

    if (tipoIdentificacionPayu.value === ""){
        tipoIdentificacionPayu.style.borderColor = "red";
        error_id_type_payu.style.display = "block";
        return;
    }
    else{
        tipoIdentificacionPayu.style.borderColor = "#cfcfcf";
        error_id_type_payu.style.display = "none";
    }

    if(numeroIdentificacionPayu.value === ""){
        numeroIdentificacionPayu.style.borderColor = "red";
        error_numeroIdentificacionPayu_1.style.display = "block";
        return;
    }
    else{
        numeroIdentificacionPayu.style.borderColor = "#cfcfcf";
        error_numeroIdentificacionPayu_1.style.display = "none";
    }

    if(isNaN(numeroIdentificacionPayu.value) && tipoIdentificacionPayu.value != "Pasaporte"){
        numeroIdentificacionPayu.style.borderColor = "red";
        error_numeroIdentificacionPayu_2.style.display = "block";
        return;
    }
    else{
        numeroIdentificacionPayu.style.borderColor = "#cfcfcf";
        error_numeroIdentificacionPayu_2.style.display = "none";
    }

    if(phoneInputPayu.value === ""){
        phoneInputPayu.style.borderColor = "red";
        error_payerPhone_1.style.display = "block";
        return;
    }
    else{
        phoneInputPayu.style.borderColor = "#cfcfcf";
        error_payerPhone_1.style.display = "none";
    }

    var patronTelefono = /^3\d{9}$/;
    if (patronTelefono.test(phoneInputPayu.value) === false){
        phoneInputPayu.style.borderColor = "red";
        error_payerPhone_2.style.display = "block";
        return;
    }
    else{
        phoneInputPayu.style.borderColor = "#cfcfcf";
        error_payerPhone_2.style.display = "none";
    }

    if(emailInputPayu.value === ""){
        emailInputPayu.style.borderColor = "red";
        error_email_1.style.display = "block";
        return;
    }
    else{
        emailInputPayu.style.borderColor = "#cfcfcf";
        error_email_1.style.display = "none";
    }

    var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (patronEmail.test(emailInputPayu.value) === false){
        emailInputPayu.style.borderColor = "red";
        error_email_2.style.display = "block";
        return;
    }
    else{
        emailInputPayu.style.borderColor = "#cfcfcf";
        error_email_2.style.display = "none";
    }

    if (payment_method_type_card.value == ""){
        payment_method_type_card.style.borderColor = "red";
        payment_method_type_card_error.style.display = "block";
        return;
    }
    else{
        payment_method_type_card.style.borderColor = "#cfcfcf";
        payment_method_type_card_error.style.display = "none";
    }

    if (payment_method_brand_card.value == ""){
        payment_method_brand_card.style.borderColor = "red";
        payment_method_brand_card_error.style.display = "block";
        return;
    }
    else{
        payment_method_brand_card.style.borderColor = "#cfcfcf";
        payment_method_brand_card_error.style.display = "none";
    }

    if (card_number.value === ""){
        card_number.style.borderColor = "red";
        error_card_number_1.style.display = "block";
        return;
    }
    else{
        card_number.style.borderColor = "#cfcfcf";
        error_card_number_1.style.display = "none";
    }

    var numeroLimpiado = card_number.value.replace(/[\s-]/g, '');
    if (/^\d{16}$/.test(numeroLimpiado) === false || isNaN(numeroLimpiado) ) {
        card_number.style.borderColor = "red";
        error_card_number_2.style.display = "block";
        return;
    }
    else{
        card_number.style.borderColor = "#cfcfcf";
        error_card_number_2.style.display = "none";
    }

    if (cvv_card.value === ""){
        cvv_card.style.borderColor = "red";
        error_cvv_card_1.style.display = "block";
        return;
    }
    else{
        cvv_card.style.borderColor = "#cfcfcf";
        error_cvv_card_1.style.display = "none";
    }

    if (cvv_card.value.length != 3 || isNaN(cvv_card.value) ) {
        cvv_card.style.borderColor = "red";
        error_cvv_card_2.style.display = "block";
        return;
    }
    else{
        cvv_card.style.borderColor = "#cfcfcf";
        error_cvv_card_2.style.display = "none";
    }

    if (expiration_month.value === ""){
        expiration_month.style.borderColor = "red";
        error_expiration_month_1.style.display = "block";
        return;
    }
    else{
        expiration_month.style.borderColor = "#cfcfcf";
        error_expiration_month_1.style.display = "none";
    }

    if(isNaN(expiration_month.value)){
        expiration_month.style.borderColor = "red";
        error_expiration_month_2.style.display = "block";
        return;
    }
    else{
        expiration_month.style.borderColor = "#cfcfcf";
        error_expiration_month_2.style.display = "none";
    }

    if (expiration_month.value.length != 2){
        expiration_month.style.borderColor = "red";
        error_expiration_month_3.style.display = "block";
        return;
    }
    else{
        expiration_month.style.borderColor = "#cfcfcf";
        error_expiration_month_3.style.display = "none";
    }

    if (parseInt(expiration_month.value, 10) > 12 || parseInt(expiration_month.value, 10) < 1){
        expiration_month.style.borderColor = "red";
        error_expiration_month_4.style.display = "block";
        return;
    }
    else{
        expiration_month.style.borderColor = "#cfcfcf";
        error_expiration_month_4.style.display = "none";
    }

    if (expiration_year.value === ""){
        expiration_year.style.borderColor = "red";
        error_expiration_year_1.style.display = "block";
        return;
    }
    else{
        expiration_year.style.borderColor = "#cfcfcf";
        error_expiration_year_1.style.display = "none";
    }

    if(isNaN(expiration_year.value)){
        expiration_year.style.borderColor = "red";
        error_expiration_year_2.style.display = "block";
        return;
    }
    else{
        expiration_year.style.borderColor = "#cfcfcf";
        error_expiration_year_2.style.display = "none";
    }

    if (expiration_year.value.length != 4){
        expiration_year.style.borderColor = "red";
        error_expiration_year_3.style.display = "block";
        return;
    }
    else{
        expiration_year.style.borderColor = "#cfcfcf";
        error_expiration_year_3.style.display = "none";
    }

    if(!tyc.checked){
        tyc.style.borderColor = "red";
        error_tyc.style.display = "block";
        return;
    }
    else{
        tyc.style.borderColor = "#cfcfcf";
        error_tyc.style.display = "none";
    }

    var fechaActual = new Date();

    var fechaPropuesta = new Date(parseInt(expiration_year.value, 10), parseInt(expiration_month.value, 10) - 1);

    if (fechaPropuesta < fechaActual) {
        expiration_month.style.borderColor = "red";
        expiration_year.style.borderColor = "red";
        error_expired_card.style.display = "block";
        return;
    }
    else{
        expiration_month.style.borderColor = "#cfcfcf";
        expiration_year.style.borderColor = "#cfcfcf";
        error_expired_card.style.display = "none";
    }

    payu_1.style.display = "none";
    payu_2.style.display = "block";

    payu.click();
});
//-------------------------------------------------------------------------------
payment_method.addEventListener('change', () => {
    if(payment_method.value == "PSE"){
        nombreBanco_1.style.display = 'block';
        checkbox_TyC_form.style.display = 'flex';
        info_form.style.display = 'block';
        next_step_1.innerText = '¡Confirmar donación! 🤍';
    }
    else{
        nombreBanco_1.style.display = 'none';
        checkbox_TyC_form.style.display = 'none';
        info_form.style.display = 'none';
        next_step_1.innerText = 'Siguiente';
    }
    //payment_method_1.value = payment_method.value;
    payment_method.style.borderColor = "#cfcfcf";
    tyc.style.borderColor = "#cfcfcf";
    error_tyc.style.display = "none";
    error_payment_method.style.display = "none";
});
//-------------------------------------------------------------------------------
guardar_1.addEventListener('click', () => {
    var error_guardar = false;

    if(name_form.value === ""){
        error_guardar = true;
        name_form.style.borderColor = "red";
        error_nombre_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        name_form.style.borderColor = "#cfcfcf";
        error_nombre_1.style.display = "none";
    }

    if(apellido.value === ""){
        error_guardar = true;
        apellido.style.borderColor = "red";
        error_nombre_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        apellido.style.borderColor = "#cfcfcf";
        error_nombre_2.style.display = "none";
    }

    if(tipoCuenta.value === ""){
        error_guardar = true;
        tipoCuenta.style.borderColor = "red";
        error_account_type.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        tipoCuenta.style.borderColor = "#cfcfcf";
        error_account_type.style.display = "none";
    }

    if(numeroCuenta.value === ""){
        error_guardar = true;
        numeroCuenta.style.borderColor = "red";
        error_numeroCuenta_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroCuenta.style.borderColor = "#cfcfcf";
        error_numeroCuenta_1.style.display = "none";
    }

    if(isNaN(numeroCuenta.value)){
        error_guardar = true;
        numeroCuenta.style.borderColor = "red";
        error_numeroCuenta_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroCuenta.style.borderColor = "#cfcfcf";
        error_numeroCuenta_2.style.display = "none";
    }

    if(nombreBanco.value === ""){
        error_guardar = true;
        nombreBanco.style.borderColor = "red";
        error_bank_name.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        nombreBanco.style.borderColor = "#cfcfcf";
        error_bank_name.style.display = "none";
    }

    if(tipoIdentificacion.value === ""){
        error_guardar = true;
        tipoIdentificacion.style.borderColor = "red";
        error_id_type_bank.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        tipoIdentificacion.style.borderColor = "#cfcfcf";
        error_id_type_bank.style.display = "none";
    }

    if(numeroIdentificacion.value === ""){
        error_guardar = true;
        numeroIdentificacion.style.borderColor = "red";
        error_numeroIdentificacion_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroIdentificacion.style.borderColor = "#cfcfcf";
        error_numeroIdentificacion_1.style.display = "none";
    }

    if(isNaN(numeroIdentificacion.value) && tipoIdentificacion.value === ""){
        error_guardar = true;
        numeroIdentificacion.style.borderColor = "red";
        error_numeroIdentificacion_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroIdentificacion.style.borderColor = "#cfcfcf";
        error_numeroIdentificacion_2.style.display = "none";
    }

    if(cvv.value !== "" && isNaN(parseFloat(cvv.value)) && isFinite(cvv.value)){
        error_guardar = true;
        alert('El campo "CVV" solo puede contener números');
        return;
    }
    else{
        error_guardar = false;
    }

    if(phone_form.value === ""){
        error_guardar = true;
        phone_form.style.borderColor = "red";
        error_numeroTelefono_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        phone_form.style.borderColor = "#cfcfcf";
        error_numeroTelefono_1.style.display = "none";
    }

    if(isNaN(phone_form.value)){
        error_guardar = true;
        phone_form.style.borderColor = "red";
        error_numeroTelefono_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        phone_form.style.borderColor = "#cfcfcf";
        error_numeroTelefono_2.style.display = "none";
    }

    var patronTelefono = /^3\d{9}$/;
    if (patronTelefono.test(phone_form.value) === false){
        error_guardar = true;
        phone_form.style.borderColor = "red";
        error_numeroTelefono_3.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        phone_form.style.borderColor = "#cfcfcf";
        error_numeroTelefono_3.style.display = "none";
    }

    if(email_form.value === ""){
        error_guardar = true;
        email_form.style.borderColor = "red";
        error_correoElectronico_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        email_form.style.borderColor = "#cfcfcf";
        error_correoElectronico_1.style.display = "none";
    }

    var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (patronEmail.test(email_form.value) === false){
        error_guardar = true;
        email_form.style.borderColor = "red";
        error_correoElectronico_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        email_form.style.borderColor = "#cfcfcf";
        error_correoElectronico_2.style.display = "none";
    }

    if(!tyc_bank.checked){
        error_guardar = true;
        tyc_bank.style.borderColor = "red";
        error_checkbox_TyC_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        tyc_bank.style.borderColor = "#cfcfcf";
        error_checkbox_TyC_1.style.display = "none";
    }

    if (error_guardar === false){
        guardar_1.style.display = "none";
        guardar_2.style.display = "block";
        guardar.click();
    }
});
//-------------------------------------------------------------------------------
next_step_1.addEventListener('click', () => {
    var error_guardar = false;

    if(nombre_1.value === ""){
        error_guardar = true;
        nombre_1.style.borderColor = "red";
        error_nombre_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        nombre_1.style.borderColor = "#cfcfcf";
        error_nombre_1.style.display = "none";
    }

    if(apellido_1.value === ""){
        error_guardar = true;
        apellido_1.style.borderColor = "red";
        error_nombre_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        apellido_1.style.borderColor = "#cfcfcf";
        error_nombre_2.style.display = "none";
    }

    if(person_type.value === ""){
        person_type.style.borderColor = "red";
        error_person_type.style.display = "block";
        return;
    }
    else{
        person_type.style.borderColor = "#cfcfcf";
        error_person_type.style.display = "none";
    }

    if(tipoIdentificacion_1.value === ""){
        error_guardar = true;
        tipoIdentificacion_1.style.borderColor = "red";
        error_id_type_bank.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        tipoIdentificacion_1.style.borderColor = "#cfcfcf";
        error_id_type_bank.style.display = "none";
    }

    if(numeroIdentificacion_1.value === ""){
        error_guardar = true;
        numeroIdentificacion_1.style.borderColor = "red";
        error_numeroIdentificacion_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroIdentificacion_1.style.borderColor = "#cfcfcf";
        error_numeroIdentificacion_1.style.display = "none";
    }

    if(isNaN(numeroIdentificacion_1.value) && tipoIdentificacion_1.value != "Pasaporte"){
        error_guardar = true;
        numeroIdentificacion_1.style.borderColor = "red";
        error_numeroIdentificacion_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroIdentificacion_1.style.borderColor = "#cfcfcf";
        error_numeroIdentificacion_2.style.display = "none";
    }

    if(numeroTelefono_1.value === ""){
        error_guardar = true;
        numeroTelefono_1.style.borderColor = "red";
        error_numeroTelefono_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroTelefono_1.style.borderColor = "#cfcfcf";
        error_numeroTelefono_1.style.display = "none";
    }

    if(isNaN(numeroTelefono_1.value)){
        error_guardar = true;
        numeroTelefono_1.style.borderColor = "red";
        error_numeroTelefono_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroTelefono_1.style.borderColor = "#cfcfcf";
        error_numeroTelefono_2.style.display = "none";
    }

    var patronTelefono = /^3\d{9}$/;
    if (patronTelefono.test(numeroTelefono_1.value) === false){
        error_guardar = true;
        numeroTelefono_1.style.borderColor = "red";
        error_numeroTelefono_3.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        numeroTelefono_1.style.borderColor = "#cfcfcf";
        error_numeroTelefono_3.style.display = "none";
    }

    if(correoElectronico_1.value === ""){
        error_guardar = true;
        correoElectronico_1.style.borderColor = "red";
        error_correoElectronico_1.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        correoElectronico_1.style.borderColor = "#cfcfcf";
        error_correoElectronico_1.style.display = "none";
    }

    var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (patronEmail.test(correoElectronico_1.value) === false){
        error_guardar = true;
        correoElectronico_1.style.borderColor = "red";
        error_correoElectronico_2.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        correoElectronico_1.style.borderColor = "#cfcfcf";
        error_correoElectronico_2.style.display = "none";
    }

    if (payment_method.value === ""){
        error_guardar = true;
        payment_method.style.borderColor = "red";
        error_payment_method.style.display = "block";
        return;
    }
    else{
        error_guardar = false;
        payment_method.style.borderColor = "#cfcfcf";
        error_payment_method.style.display = "none";
    }

    if (payment_method.value === "Cuenta de banco"){
        form4.style.display = 'none';
        paso_text1.style.display = 'none';
        form2.style.display = 'block';
        paso_text2.style.display = 'block';
        
    }
    else if(payment_method.value === "PSE"){

        if (nombreBanco_1.value === "0"){
            nombreBanco_1.style.borderColor = "red";
            error_nombreBanco_1.style.display = "block";
            return;
        }
        else{
            nombreBanco_1.style.borderColor = "#cfcfcf";
            error_nombreBanco_1.style.display = "none";
        }

        if(!tyc_form.checked){
            tyc_form.style.borderColor = "red";
            error_tyc_form.style.display = "block";
            return;
        }
        else{
            tyc_form.style.borderColor = "#cfcfcf";
            error_tyc_form.style.display = "none";
            next_step_1.style.display = "none";
            payu_2_form.style.display = "block";
            var cookieExistente;
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("monthly_payu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "monthly_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "monthly_payu_pse=" + encodeURIComponent(monthly_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("amount_payu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "amount_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "amount_payu_pse=" + encodeURIComponent(amount_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("tipoIdentificacionPayu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "tipoIdentificacionPayu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "tipoIdentificacionPayu_pse=" + encodeURIComponent(tipoIdentificacionPayu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("numeroIdentificacionPayu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "numeroIdentificacionPayu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "numeroIdentificacionPayu_pse=" + encodeURIComponent(numeroIdentificacionPayu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("gift_email_payu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "gift_email_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "gift_email_payu_pse=" + encodeURIComponent(gift_email_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("gift_name_payu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "gift_name_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "gift_name_payu_pse=" + encodeURIComponent(gift_name_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("gift_message_payu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "gift_message_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "gift_message_payu_pse=" + encodeURIComponent(gift_message_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("is_gift_payu_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "is_gift_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "is_gift_payu_pse=" + encodeURIComponent(is_gift_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            cookieExistente = getCookie("payerPhone_pse");

            // Eliminar la cookie existente si hay una
            if (cookieExistente) {
                document.cookie = "payerPhone_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "payerPhone_pse=" + encodeURIComponent(payerPhone_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            
            payu_pse.click();
        }

    }
    else{
        values_container.style.display = 'none';
        form4.style.display = 'none';
        paso_text1.style.display = 'none';
        form3.style.display = 'block';
        paso_text2.style.display = 'block';
    }

});
//-------------------------------------------------------------------------------
giftEmail.addEventListener("input", function() {
    gift_email_bank.value = giftEmail.value;
    gift_email_payu.value = giftEmail.value;
    gift_email_payu_pse.value = giftEmail.value;
    giftEmail.style.borderColor = "#cfcfcf";
    error_email_gift_1.style.display = "none";
    error_email_gift_2.style.display = "none";
});
//-------------------------------------------------------------------------------
whoName.addEventListener("input", function() {
    gift_name_bank.value = whoName.value;
    gift_name_payu.value = whoName.value;
    gift_name_payu_pse.value = whoName.value;
    whoName.style.borderColor = "#cfcfcf";
    error_whoName_gift.style.display = "none";
});
//-------------------------------------------------------------------------------
message.addEventListener("input", function() {
    gift_message_bank.value = message.value;
    gift_message_payu.value = message.value;
    gift_message_payu_pse.value = message.value;
    message.style.borderColor = "#cfcfcf";
    error_message_gift.style.display = "none";
});
//-------------------------------------------------------------------------------
nombre_1.addEventListener("input", function() {
    name_form.value = nombre_1.value;
    nameInputPayu.value = nombre_1.value;
    payerFullName_pse.value = nombre_1.value;
    nombre_1.style.borderColor = "#cfcfcf";
    error_nombre_1.style.display = "none";
});
//-------------------------------------------------------------------------------
apellido_1.addEventListener("input", function() {
    apellido.value = apellido_1.value;
    lastNameInputPayu.value = apellido_1.value;
    payerLastName_pse.value  = apellido_1.value;
    apellido_1.style.borderColor = "#cfcfcf";
    error_nombre_2.style.display = "none";
});
//-------------------------------------------------------------------------------
tipoIdentificacion_1.addEventListener('change', () => {
    tipoIdentificacion.value = tipoIdentificacion_1.value;
    tipoIdentificacionPayu.value = tipoIdentificacion_1.value;
    tipoIdentificacionPayu_pse.value = tipoIdentificacion_1.value;
    tipoIdentificacion_1.style.borderColor = "#cfcfcf";
    error_id_type_bank.style.display = "none";
});
//-------------------------------------------------------------------------------
person_type.addEventListener('change', () => {
    person_type_pse.value = person_type.value;
    person_type.style.borderColor = "#cfcfcf";
    error_person_type.style.display = "none";
});
//-------------------------------------------------------------------------------
nombreBanco_1.addEventListener('change', () => {
    nombreBanco_pse.value = nombreBanco_1.value;
    nombreBanco_1.style.borderColor = "#cfcfcf";
    error_person_type.style.display = "none";
});
//-------------------------------------------------------------------------------
numeroIdentificacion_1.addEventListener("input", function() {
    numeroIdentificacion.value = numeroIdentificacion_1.value;
    numeroIdentificacionPayu.value = numeroIdentificacion_1.value;
    numeroIdentificacionPayu_pse.value = numeroIdentificacion_1.value;
    numeroIdentificacion_1.style.borderColor = "#cfcfcf";
    error_numeroIdentificacion_1.style.display = "none";
    error_numeroIdentificacion_2.style.display = "none";
});
//-------------------------------------------------------------------------------
numeroTelefono_1.addEventListener("input", function() {
    phone_form.value = numeroTelefono_1.value;
    phoneInputPayu.value = numeroTelefono_1.value;
    payerPhone_pse.value = numeroTelefono_1.value;
    numeroTelefono_1.style.borderColor = "#cfcfcf";
    error_numeroTelefono_1.style.display = "none";
    error_numeroTelefono_2.style.display = "none";
    error_numeroTelefono_3.style.display = "none";
});
//-------------------------------------------------------------------------------
correoElectronico_1.addEventListener("input", function() {
    email_form.value = correoElectronico_1.value;
    emailInputPayu.value = correoElectronico_1.value;
    email_pse.value = correoElectronico_1.value;
    correoElectronico_1.style.borderColor = "#cfcfcf";
    error_correoElectronico_1.style.display = "none";
    error_correoElectronico_2.style.display = "none";
});
//-------------------------------------------------------------------------------
card_number.addEventListener("input", function() {
    card_number.style.borderColor = "#cfcfcf";
    error_card_number_1.style.display = "none";
    error_card_number_2.style.display = "none";
});
//-------------------------------------------------------------------------------
cvv_card.addEventListener("input", function() {
    cvv_card.style.borderColor = "#cfcfcf";
    error_cvv_card_1.style.display = "none";
    error_cvv_card_2.style.display = "none";
});
//-------------------------------------------------------------------------------
expiration_month.addEventListener("input", function() {
    expiration_month.style.borderColor = "#cfcfcf";
    error_expiration_month_1.style.display = "none";
    error_expiration_month_2.style.display = "none";
    error_expiration_month_3.style.display = "none";
    error_expiration_month_4.style.display = "none";
});
//-------------------------------------------------------------------------------
expiration_year.addEventListener("input", function() {
    expiration_year.style.borderColor = "#cfcfcf";
    error_expiration_year_1.style.display = "none";
    error_expiration_year_2.style.display = "none";
    error_expiration_year_3.style.display = "none";
});
//-------------------------------------------------------------------------------
tipoCuenta.addEventListener("input", function() {
    tipoCuenta.style.borderColor = "#cfcfcf";
    error_account_type.style.display = "none";
});
//-------------------------------------------------------------------------------
numeroCuenta.addEventListener("input", function() {
    numeroCuenta.style.borderColor = "#cfcfcf";
    error_numeroCuenta_1.style.display = "none";
    error_numeroCuenta_2.style.display = "none";
});
//-------------------------------------------------------------------------------
nombreBanco.addEventListener("input", function() {
    nombreBanco.style.borderColor = "#cfcfcf";
    error_bank_name.style.display = "none";
});
//-------------------------------------------------------------------------------
tyc_bank.addEventListener("change", function() {
    tyc_bank.style.borderColor = "#cfcfcf";
    error_checkbox_TyC_1.style.display = "none";
});
//-------------------------------------------------------------------------------
tyc.addEventListener("change", function() {
    tyc.style.borderColor = "#cfcfcf";
    error_tyc.style.display = "none";
});
//-------------------------------------------------------------------------------
tyc_form.addEventListener("change", function() {
    tyc_form.style.borderColor = "#cfcfcf";
    error_tyc_form.style.display = "none";
});
//-------------------------------------------------------------------------------
montoInput.addEventListener("change", function() {
    montoInput.style.borderColor = "#FCBB29";
    error_monto_3.style.display = "none";
    error_monto_4.style.display = "none";
});
//-------------------------------------------------------------------------------
payment_method_type_card.addEventListener("change", function() {
    
    payment_method_type_card.style.borderColor = "#cfcfcf";
    payment_method_type_card_error.style.display = "none";

    if(payment_method_type_card.value == "credito"){
        payment_method_brand_card.innerHTML = '';

        var defaultOption = document.createElement('option');
        defaultOption.value = "";
        defaultOption.text = "Seleccione tarjeta";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        payment_method_brand_card.appendChild(defaultOption);

        var options_payment = [
            {text: 'Tarjeta Crédito Mastercard', value: 'MASTERCARD'},
            {text: 'Tarjeta Crédito VISA', value: 'VISA'},
            {text: 'Tarjeta Crédito American Express', value: 'AMEX'},
            {text: 'Tarjeta Crédito Diners', value: 'DINERS'},
            {text: 'Tarjeta Crédito Argencard', value: 'ARGENCARD'},
            {text: 'BTarjeta Crédito CABAL', value: 'CABAL'},
            {text: 'Tarjeta Crédito Cencosud', value: 'CENCOSUD'},
            {text: 'Tarjeta Crédito Naranja', value: 'NARANJA'},
            {text: 'Tarjeta Crédito Shopping', value: 'SHOPPING'},
        ];

        for (var i = 0; i < options_payment.length; i++) {
            var option = document.createElement('option');
            option.value = options_payment[i].value;
            option.text = options_payment[i].text;
            payment_method_brand_card.appendChild(option);
        }
    }
    else{
        payment_method_brand_card.innerHTML = '';

        var defaultOption = document.createElement('option');
        defaultOption.value = "";
        defaultOption.text = "Seleccione tarjeta";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        payment_method_brand_card.appendChild(defaultOption);

        var options_payment = [
            {text: 'Tarjeta Débito VISA', value: 'VISA_DEBIT'}
        ];

        for (var i = 0; i < options_payment.length; i++) {
            var option = document.createElement('option');
            option.value = options_payment[i].value;
            option.text = options_payment[i].text;
            payment_method_brand_card.appendChild(option);
        }
    }
});
//-------------------------------------------------------------------------------
payment_method_brand_card.addEventListener("change", function() {
    payment_method_brand_card.style.borderColor = "#cfcfcf";
    payment_method_brand_card_error.style.display = "none";
    payment_method_1.value = payment_method_brand_card.value;
});
//-------------------------------------------------------------------------------
function getCookie(nombre) {
    var nombreEQ = nombre + "=";
    var cookies = document.cookie.split(';');
    for(var i = 0; i < cookies.length; i++) {
        var cookie = cookies[i];
        while (cookie.charAt(0) == ' ') cookie = cookie.substring(1, cookie.length);
        if (cookie.indexOf(nombreEQ) == 0) return cookie.substring(nombreEQ.length, cookie.length);
    }
    return null;
}

var mensual = document.querySelector('div#mensual .arrow')
var unica = document.querySelector('div#unica .arrow')

function activarArrow(btnId){
    let btn = document.getElementById(btnId)
        if(btn === "button1"){
            mensual.classList.remove('activeArrow');
            unica.classList.add('activeArrow');
        }else{
            unica.classList.remove('activeArrow');
            mensual.classList.add('activeArrow');
        }
}


</script>
