<style>
input {
    margin: 5px 0px 0px 0px;
}

div#video-form video {
    height: 150px;
    object-fit: cover;
    border-radius: 15px;
}

/*----------------------------------------------------------------------*/
/* Estilos generales para botones y contenedores */
div#option_monthly_5_values_container {
    max-width: 480px;
    margin: 0 auto;
    text-align:center;
    transition:all .3s ease-in-out;
}

.fav {
    text-align: center;
    background: #FFF3D7;
    border: 2px dotted #FCBB29;
    border-radius: 20px;
    padding: 5px;
}
.fav span {
    font-family: Open Sans;
    font-size: 11px;
    font-weight: 700;
    color: #D29A1A;
}
/* estilos de pasos*/
#pasosContainer_optionmonthly5{
    min-height: 40px;
    transition: all .3s linear;
    margin-bottom:10px;
}
#pasosContainer_optionmonthly5 .container-steps{
      display: grid;
    grid-template-columns: 10% 90%;
    gap: 0;
    align-items: center;
    justify-items: center;
}
.container-steps .botones a{
border: 1px solid #000;
    padding: .2em .5em;
    border-radius: 50%;
    cursor: pointer;
}
.container-steps .botones a:hover {
    color: #fcbb29;
    border-color: #fcbb29;
}
.text-pasos h3 {
    font-family: "WWF", Sans-serif;
    font-size: 22px;
    font-weight: 400;
    margin: 0;
    text-align:center;
    color: #000;
}
@media (max-width:425px){
    .text-pasos h3 {
        font-size: 16px;
    }
}
.buttonContainer .option_monthly_5_myButton {
   min-width: 115px;
    max-width: 130px;
    padding: 10px 3px;
    margin: 5px 0;
}
.buttonContainer.tabs {
    position: relative;
    gap: 0;
    margin-bottom: 15px;
    border-radius: 20px;
    border: 1px solid #00000069;
}
.buttonContainer.tabs .option_monthly_5_myButton_1 {
    overflow: visible;
    margin: 0;
    border-radius: 0;
    position: relative;
        width: 100%;
}
.buttonContainer.tabs .content-tab {
    width: 100%;
    position: relative;
}
.buttonContainer.tabs button#button1 {
    border-radius: 20px 0 0 20px;
}
.buttonContainer.tabs button#button2 {
    border-radius: 0 20px 20px 0;
}


input#option_monthly_5_monto{
    width:100%;
}
input#option_monthly_5_monto {
    border: 2px solid #fcbb29;
}
div#option_monthly_5_gift_container input, div#option_monthly_5_gift_container textarea {
    text-align: left;
    padding: 4px 15px;
    border-radius: 10px;
    font-size: 14px;
}

h5.titulos-form {
    font-family: "WWF", sans-serif !important;
    font-size:22px;
    text-align:center;
    margin:0;
}
h3.titular{
    font-family: "WWF", Sans-serif;
    font-size: 25px;
    font-weight: 400;
}

.buttonContainer,
.formButtonContainer {
    display: flex;
    justify-content: center;
    align-items: center;
}

.buttonContainer {
    flex-direction: row;
    align-items: flex-end;
    gap: 5px;
}

.formButtonContainer {
    flex-direction: column;
    margin-block-start: 0rem;
}

.option_monthly_5_myButton, .option_monthly_5_myButton_1 {
    font-family: 'Open Sans', sans serif !important;
    width: 90%;
    background-color: rgba(255, 255, 255, 1);
    box-shadow: 0px 3px 8px 0px rgba(0, 0, 0, 0.25);
    color: black;
    border: none;
    font-size: 14px;    
    font-weight: 700;
}

/* nuevas reglas */ 


div#option_monthly_5_values_container, .formContainer, .formContainer4{
font-family: 'Open Sans', sans serif !important;
}

.otroValor {
    width: 90% !important;
    margin: 0 !important;
}
.divisor{
    width:100%;
    height:1px;
    background: rgb(199 199 199 / 48%);
    margin: 10px 0;
}
.formContainer select,
div#option_monthly_5_form3 select, 
div#option_monthly_5_form2 select,
div#option_monthly_5_form4 select{
    -webkit-appearance: none; /* Ajuste para Safari */
    padding: 10px 15px; /* Ajuste para Safari */
    text-align: center;
    color:#333333d1;
}


div#option_monthly_5_values_container input, 
.formContainer input,
.formContainer select,
.formContainer4 input,
div#option_monthly_5_form3 input,
div#option_monthly_5_form3 select, 
div#option_monthly_5_form2 input,
div#option_monthly_5_form2 select,
div#option_monthly_5_form4 input,
div#option_monthly_5_form4 select{
    border-radius: 30px;
    font-size: 14px;
    margin-top: 6px;
    min-height: 45px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 2px 11px 0px rgba(0, 0, 0, 0.19) inset;
}

div#option_monthly_5_values_container input:focus, 
.option_monthly_5_tipoIdentificacion_1:focus,
.formContainer input:focus, 
.formContainer select:focus, 
.formContainer4 input:focus, 
div#option_monthly_5_values_container textarea:focus,
div#option_monthly_5_form3 form input:focus,
div#option_monthly_5_form3 form select:focus,
div#option_monthly_5_form2 form input:focus,
div#option_monthly_5_form2 form select:focus,
div#option_monthly_5_form4 form input:focus,
div#option_monthly_5_form4 form select:focus {
    border-color: #fcbb29;
    outline: #fcbb29;
}
input[type="text"]:focus, input[type="password"]:focus, select, textarea, .option_monthly_5_tipoIdentificacion_1 {
    border-color:#cfcfcf;
    outline: 0;
    box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
}

div#option_monthly_5_data_user {
    width: 100%;
    display: block;
    text-align: center;
    margin: auto;
}


.titulo-form-2 h5.titulos-form {
    margin-left: -50px;
}

.formButton:hover,
.saveButton:hover {
    background-color: #8fef6c;
}
/* //---------------- paso 2 */
div#option_monthly_5_form3 form, div#option_monthly_5_form2 form {
    width: 90% !important;
    margin: 0 auto;
    text-align: left;
}
.titulo-form-2{
    display:grid;
    grid-template-columns: 100%;
    justify-content: center;
    align-items: center;
}

.contForm-nombre, .contForm-tarjerta{
    display: flex;
    gap: 13px;
    justify-content: center;
}
.contForm-tarjerta input{
    width: 33%;
}
.contForm-nombre input {
    width: 50%;
}
.checkbox-T\&C {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 10px;
}
label.politicas {
    font-weight: 600;
    text-align: left;
    font-size: 0.8rem;
}
label.politicas a{
    text-decoration: underline;
    color: #000;
    font-family: Open Sans;
}
.checkbox-T\&C {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 0 10px;
}
h5.info {
    font-family: Open Sans;
    text-align: left;
    color: #000;
   font-weight: 700;
    font-size: 16px;
    padding: 0 10px;
    margin: 10px 0;
}
h5.info span {
    color:#1257BE;
    font-weight: 700;
}
.formButton,
.saveButton {
    min-width:150px;
    width:100%;
    background-color: #7cde00;
    color: black;
    font-size: 25px;
}

.option_monthly_5_myButton, .option_monthly_5_myButton_1,
.formButton,
.saveButton {

    border-radius: 30px;
    margin: 5px;
    padding: 5px 30px;
    transition: background-color 0.3s, color 0.3s; /* Agregamos transición para el cambio de color */
}
[type=button]:focus, [type=button]:hover, [type=submit]:focus, [type=submit]:hover, button:focus, button:hover {
    background-color: inherit;
    border:none;
}

.option_monthly_5_myButton.active, .option_monthly_5_myButton_1.active{
    border: none;
    background: rgba(252, 187, 41, 1);
}
[type=button], [type=submit], button{
    border: none;
    outline: none;
}
.option_monthly_5_myButton:focus, .option_monthly_5_myButton_1:focus, .formButton:focus , .saveButton:focus{
    border: none;
    outline: none;
}
.formButton.active,
.saveButton.active {
    background-color: #6fb300;
    color: black;
    border: 1px solid lightgrey;
}

.option_monthly_5_myButton:active, .option_monthly_5_myButton_1:active,
.formButton:active,
.saveButton:active {
    filter: brightness(80%); /* Cambiamos el brillo al ser presionado */
}

.option_monthly_5_myButton:hover, .option_monthly_5_myButton_1:hover {
    background-color: #fcbb29; /* Reemplaza 'your_hover_color' con el color que desees */
    color: black;
}

.formButton.payuButton, button#option_monthly_5_payu_1 {
    width:100%; /* Este estilo permite que el ancho del botón se ajuste automáticamente al contenido */
    padding: 5px 30px;
    margin:10px auto;
        background: #7cde00;
}

/*----------------------------------------------------------------------*/
/* Estilos específicos para dispositivos con una anchura máxima de 600px (por ejemplo, vista de celular) */
@media (max-width: 768px) {
 .buttonContainer .option_monthly_5_myButton{
        min-width: 100px !important;
        padding: 8px !important;
        margin: 0 !important;
    }
    .buttonContainer, .formButtonContainer {
        flex-direction: row;
        gap: 5px;
        justify-content: space-evenly;
    }
    .fav{
        padding: 3px 5px;
    }.fav span {
         font-size: 10px;
    }
    .divisor{
        margin: 5px 0;
    }
     
}
/*----------------------------------------------------------------------*/
/* Estilos para formularios y animaciones */
.formContainer,
.formContainer4 {
    justify-content: center;
    align-items: center;
    flex-direction: column;
    text-align: center;
    margin-top: 0px;
    line-height: 1;
}

.formContainer4 {
    display: flex;
    animation: slideDown 0.5s;
}

.formContainer form,
.formContainer4 form {
    background-color: white;
    color: black;
    border-radius: 12px;
    margin: 0px;
    font-size: 15px;
    padding: 0px;
    line-height: 1;
}

/*----------------------------------------------------------------------*/
input[type="text"], input[type="password"], select, textarea{
  background-color: #fff; /* fondo blanco */
  border: 2px solid #ccc; /* borde sólido con un color gris claro */
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.2); /* sombra interior más pronunciada para el estado normal */
  border-radius: 4px; /* bordes redondeados */
  padding: 8px 12px; /* un poco de relleno para hacer que el texto no esté demasiado pegado al borde */
  font-size: 16px; /* un tamaño de fuente legible */
  color: #333; /* color de texto oscuro para contraste con el fondo */
  width: 100%; /* para que ocupe el ancho del contenedor padre */
  box-sizing: border-box; /* asegurarse de que el padding y border no aumenten el ancho total */
  margin-bottom: 10px; /* espacio debajo del input */
  text-align: center; /* centra el texto dentro del input */
}


/*--------------------------------Botones--------------------------------------*/
.donation-options {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.donation-button {
  background-color: #ffffff; /* Botón de fondo blanco */
  color: #333333; /* Texto oscuro para contraste */
  border: 2px solid #cccccc; /* Borde sólido de color gris claro */
  border-radius: 20px; /* Bordes redondeados para estilo de píldora */
  padding: 10px 20px; /* Relleno horizontal y vertical */
  font-size: 16px; /* Tamaño de fuente legible */
  cursor: pointer; /* Cursor de mano para indicar que es un botón */
  margin-right: 10px; /* Espacio entre los botones */
  transition: background-color 0.3s, color 0.3s; /* Transición suave para efectos de hover */
}

.donation-button:last-child {
  margin-right: 0; /* No hay margen a la derecha del último botón */
}

.donation-button:hover {
  background-color: #f5f5f5; /* Color de fondo ligeramente más oscuro en hover */
}

.donation-button-active {
  background-color: #f8d64e; /* Color de fondo amarillo para el botón activo */
  color: #ffffff; /* Texto blanco para contraste */
  border-color: #f8d64e; /* Borde del mismo color que el fondo para el botón activo */
}

/* Estilo para el corazón en el botón Mensual */
.donation-button-active:after {
  content: " ♥"; /* Agrega un corazón después del texto */
  color: #ffffff; /* Color del corazón blanco */
}

.checkbox-container {
    display: flex;
    align-items: center;
}
.checkbox-container svg {
    margin-right: 10px;
}

/* Espaciado entre el checkbox y el texto */
.checkbox-container label {
    font-size: 14px;
    margin-left: 8px;
    font-weight:900;
}

/*----------------------------------------------------------------------*/
@keyframes slideDown {
    0% {
        transform: translateY(-100%);
    }
    100% {
        transform: translateY(0);
    }
}

</style>

<noscript>
   <iframe style="width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;" src="https://maf.pagosonline.net/ws/fp/tags.js?id=<?php echo $option_monthly_5_deviceSessionId; ?>80200"></iframe>
</noscript>

<script>
// Convertir el JSON a un objeto de JavaScript
var option_monthly_5_values = <?php echo $option_monthly_5_values_json; ?>;

var option_monthly_5_payment_button_selected = 0;

var option_monthly_5_payment_method_brand_card_error = document.getElementById("option_monthly_5_payment_method_brand_card_error");
var option_monthly_5_payment_method_type_card_error = document.getElementById("option_monthly_5_payment_method_type_card_error");

var option_monthly_5_payment_method_type_card = document.getElementById("option_monthly_5_payment_method_type_card");
var option_monthly_5_payment_method_brand_card = document.getElementById("option_monthly_5_payment_method_brand_card");

var option_monthly_5_button1 = document.getElementById("option_monthly_5_button1");
var option_monthly_5_button2 = document.getElementById("option_monthly_5_button2");
var option_monthly_5_button3 = document.getElementById("option_monthly_5_button3");

var option_monthly_5_buttonSelected = 1;
var option_monthly_5_buttonSelected_1 = 1;

var option_monthly_5_monthly_payu = document.getElementById('option_monthly_5_monthly_payu');
var option_monthly_5_monthly_bank = document.getElementById('option_monthly_5_monthly_bank');

var option_monthly_5_gift_email_bank = document.getElementById('option_monthly_5_gift_email_bank');
var option_monthly_5_gift_name_bank = document.getElementById('option_monthly_5_gift_name_bank');
var option_monthly_5_gift_message_bank = document.getElementById('option_monthly_5_gift_message_bank');
var option_monthly_5_is_gift_bank = document.getElementById('option_monthly_5_is_gift_bank');

var option_monthly_5_gift_email_payu = document.getElementById('option_monthly_5_gift_email_payu');
var option_monthly_5_gift_name_payu = document.getElementById('option_monthly_5_gift_name_payu');
var option_monthly_5_gift_message_payu = document.getElementById('option_monthly_5_gift_message_payu');
var option_monthly_5_is_gift_payu = document.getElementById('option_monthly_5_is_gift_payu');
var option_monthly_5_is_gift_payu_pse = document.getElementById('option_monthly_5_is_gift_payu_pse');

var option_monthly_5_checkbox = document.getElementById('option_monthly_5_giftCheck');
var option_monthly_5_giftContainer = document.getElementById('option_monthly_5_gift_container');
var containerVideo = document.getElementById('video-form');
var option_monthly_5_giftEmail = document.getElementById('option_monthly_5_giftEmail');
var option_monthly_5_whoName = document.getElementById('option_monthly_5_whoName');
var option_monthly_5_message = document.getElementById('option_monthly_5_message');

var option_monthly_5_monto_form_1 = document.getElementById('option_monthly_5_monto_form_1');
var option_monthly_5_monto_form = document.getElementById('option_monthly_5_monto_form');
var option_monthly_5_montoInput = document.getElementById('option_monthly_5_monto');
var option_monthly_5_montoInputPayu = document.getElementById('option_monthly_5_amount_payu');
var option_monthly_5_taxReturnBase =  document.getElementById('option_monthly_5_taxReturnBase');

var option_monthly_5_nombre_1 = document.getElementById('option_monthly_5_nombre_1');
var option_monthly_5_apellido_1 = document.getElementById('option_monthly_5_apellido_1');
var option_monthly_5_tipoIdentificacion_1 = document.getElementById('option_monthly_5_tipoIdentificacion_1');
var option_monthly_5_numeroIdentificacion_1 = document.getElementById('option_monthly_5_numeroIdentificacion_1');
var option_monthly_5_numeroTelefono_1 = document.getElementById('option_monthly_5_numeroTelefono_1');
var option_monthly_5_correoElectronico_1 = document.getElementById('option_monthly_5_correoElectronico_1');

var option_monthly_5_name_form = document.getElementById('option_monthly_5_nombre');
var option_monthly_5_apellido = document.getElementById('option_monthly_5_apellido');
var option_monthly_5_nameInputPayu = document.getElementById('option_monthly_5_payerFullName');
var option_monthly_5_lastNameInputPayu = document.getElementById('option_monthly_5_payerLastName');
var option_monthly_5_valorDonacion = document.getElementById('option_monthly_5_valorDonacion');
var option_monthly_5_valorDonacion_bank = document.getElementById('option_monthly_5_valorDonacion_bank');

var option_monthly_5_email_form = document.getElementById('option_monthly_5_correoElectronico');
var option_monthly_5_emailInputPayu = document.getElementById('option_monthly_5_email');

var option_monthly_5_phone_form = document.getElementById('option_monthly_5_numeroTelefono');
var option_monthly_5_phoneInputPayu = document.getElementById('option_monthly_5_payerPhone');

var option_monthly_5_payerPhone_pse = document.getElementById('option_monthly_5_payerPhone_pse');
var option_monthly_5_email_pse = document.getElementById('option_monthly_5_email_pse');
var option_monthly_5_error_person_type = document.getElementById('option_monthly_5_error_person_type');

var option_monthly_5_referenceCode = document.getElementById('option_monthly_5_referenceCode');
var option_monthly_5_amount_payu = document.getElementById('option_monthly_5_amount_payu');
var option_monthly_5_currency = document.getElementById('option_monthly_5_currency');
var option_monthly_5_description = document.getElementById('option_monthly_5_description');
var option_monthly_5_description_bank = document.getElementById('option_monthly_5_description_bank');

var option_monthly_5_values_container = document.getElementById('option_monthly_5_values_container');

var option_monthly_5_data_user = document.getElementById('option_monthly_5_data_user');

var option_monthly_5_payment_method = document.getElementById('option_monthly_5_payment_method');
var option_monthly_5_payment_method_1 = document.getElementById('option_monthly_5_payment_method_1');
var option_monthly_5_next_step = document.getElementById('option_monthly_5_next_step');
var option_monthly_5_next_step_1 = document.getElementById('option_monthly_5_next_step_1');
var option_monthly_5_cvv = document.getElementById('option_monthly_5_cvv');
/* nuevas variables para titulos de pasos */
var customTitle_opm1 = document.getElementById('customTitle_opm1');
var pasosContainer_optionmonthly5 = document.getElementById('pasosContainer_optionmonthly5');
var paso_text1_opm1 = document.getElementById('paso-text1_opm1');
var paso_text2_opm1 = document.getElementById('paso-text2_opm1');
/**/

var option_monthly_5_amount_payu_pse = document.getElementById('option_monthly_5_amount_payu_pse');

var option_monthly_5_gift_name_payu_pse = document.getElementById('option_monthly_5_gift_name_payu_pse');

var option_monthly_5_payerFullName_pse = document.getElementById('option_monthly_5_payerFullName_pse');
var option_monthly_5_payerLastName_pse = document.getElementById('option_monthly_5_payerLastName_pse');

var option_monthly_5_form2 = document.getElementById('option_monthly_5_form2');
var option_monthly_5_form3 = document.getElementById('option_monthly_5_form3');
var option_monthly_5_form4 = document.getElementById('option_monthly_5_form4');

var option_monthly_5_person_type = document.getElementById('option_monthly_5_person_type');
var option_monthly_5_person_type_pse = document.getElementById('option_monthly_5_person_type_pse');

var option_monthly_5_info_form = document.getElementById('option_monthly_5_info_form');

var option_monthly_5_guardar = document.getElementById('option_monthly_5_guardar');
var option_monthly_5_guardar_1 = document.getElementById('option_monthly_5_guardar_1');
var option_monthly_5_guardar_2 = document.getElementById('option_monthly_5_guardar_2');
var option_monthly_5_atras = document.getElementById('option_monthly_5_atras');

var option_monthly_5_nombreBanco_pse = document.getElementById('option_monthly_5_nombreBanco_pse');

var option_monthly_5_numeroCuenta = document.getElementById('option_monthly_5_numeroCuenta');
var option_monthly_5_nombreBanco = document.getElementById('option_monthly_5_nombreBanco');
var option_monthly_5_nombreBanco_1 = document.getElementById('option_monthly_5_nombreBanco_1');
var option_monthly_5_numeroIdentificacion = document.getElementById('option_monthly_5_numeroIdentificacion');

var option_monthly_5_payu = document.getElementById('option_monthly_5_payu');
var option_monthly_5_payu_1 = document.getElementById('option_monthly_5_payu_1');
var option_monthly_5_payu_2 = document.getElementById('option_monthly_5_payu_2');
var option_monthly_5_payu_2_form = document.getElementById('option_monthly_5_payu_2_form');

var option_monthly_5_payu_pse = document.getElementById('option_monthly_5_payu_pse');

var option_monthly_5_numeroIdentificacionPayu = document.getElementById('option_monthly_5_numeroIdentificacionPayu');

var option_monthly_5_numeroIdentificacionPayu_pse = document.getElementById('option_monthly_5_numeroIdentificacionPayu_pse');

var option_monthly_5_responseUrl = document.getElementById('option_monthly_5_responseUrl');
var option_monthly_5_responseUrl_pse = document.getElementById('option_monthly_5_responseUrl_pse');
var option_monthly_5_confirmationUrl = document.getElementById('option_monthly_5_confirmationUrl');

var option_monthly_5_card_number = document.getElementById('option_monthly_5_card_number');
var option_monthly_5_cvv_card = document.getElementById('option_monthly_5_cvv_card');
var option_monthly_5_expiration_month = document.getElementById('option_monthly_5_expiration_month');
var option_monthly_5_expiration_year = document.getElementById('option_monthly_5_expiration_year');
var option_monthly_5_tyc = document.getElementById('option_monthly_5_t&c');
var option_monthly_5_tyc_form = document.getElementById('option_monthly_5_t&c_form');
var option_monthly_5_tyc_bank = document.getElementById('option_monthly_5_t&c_bank');
var option_monthly_5_info_payu = document.getElementById('option_monthly_5_info_payu');
var option_monthly_5_info_bank = document.getElementById('option_monthly_5_info_bank');

var option_monthly_5_error_nombreBanco_1 = document.getElementById('option_monthly_5_error_nombreBanco_1');

var option_monthly_5_error_email_gift_1 = document.getElementById('option_monthly_5_error_email_gift_1');
var option_monthly_5_error_email_gift_2 = document.getElementById('option_monthly_5_error_email_gift_2');
var option_monthly_5_error_whoName_gift = document.getElementById('option_monthly_5_error_whoName_gift');
var option_monthly_5_error_message_gift = document.getElementById('option_monthly_5_error_message_gift');

var option_monthly_5_gift_email_payu_pse = document.getElementById('option_monthly_5_gift_email_payu_pse');

var option_monthly_5_error_monto_1 = document.getElementById('option_monthly_5_error_monto_1');
var option_monthly_5_error_monto_2 = document.getElementById('option_monthly_5_error_monto_2');
var option_monthly_5_error_monto_3 = document.getElementById('option_monthly_5_error_monto_3');
var option_monthly_5_error_monto_4 = document.getElementById('option_monthly_5_error_monto_4');

var option_monthly_5_error_nombre_1 = document.getElementById('option_monthly_5_error_nombre_1');
var option_monthly_5_error_nombre_2 = document.getElementById('option_monthly_5_error_nombre_2');

var option_monthly_5_error_numeroCuenta_1 = document.getElementById('option_monthly_5_error_numeroCuenta_1');
var option_monthly_5_error_numeroCuenta_2 = document.getElementById('option_monthly_5_error_numeroCuenta_2');

var option_monthly_5_error_numeroIdentificacion_1 = document.getElementById('option_monthly_5_error_numeroIdentificacion_1');
var option_monthly_5_error_numeroIdentificacion_2 = document.getElementById('option_monthly_5_error_numeroIdentificacion_2');

var option_monthly_5_error_numeroTelefono_1 = document.getElementById('option_monthly_5_error_numeroTelefono_1');
var option_monthly_5_error_numeroTelefono_2 = document.getElementById('option_monthly_5_error_numeroTelefono_2');
var option_monthly_5_error_numeroTelefono_3 = document.getElementById('option_monthly_5_error_numeroTelefono_3');

var option_monthly_5_error_correoElectronico_1 = document.getElementById('option_monthly_5_error_correoElectronico_1');
var option_monthly_5_error_correoElectronico_2 = document.getElementById('option_monthly_5_error_correoElectronico_2');
var option_monthly_5_error_checkbox_TyC_1 = document.getElementById('option_monthly_5_error_checkbox-T&C_1');

var option_monthly_5_error_payerFullName_1 = document.getElementById('option_monthly_5_error_payerFullName_1');
var option_monthly_5_error_payerFullName_2 = document.getElementById('option_monthly_5_error_payerFullName_2');

var option_monthly_5_error_numeroIdentificacionPayu_1 = document.getElementById('option_monthly_5_error_numeroIdentificacionPayu_1');
var option_monthly_5_error_numeroIdentificacionPayu_2 = document.getElementById('option_monthly_5_error_numeroIdentificacionPayu_2');

var option_monthly_5_error_payerPhone_1 = document.getElementById('option_monthly_5_error_payerPhone_1');
var option_monthly_5_error_payerPhone_2 = document.getElementById('option_monthly_5_error_payerPhone_2');

var option_monthly_5_error_email_1 = document.getElementById('option_monthly_5_error_email_1');
var option_monthly_5_error_email_2 = document.getElementById('option_monthly_5_error_email_2');

var option_monthly_5_error_card_number_1 = document.getElementById('option_monthly_5_error_card_number_1');
var option_monthly_5_error_card_number_2 = document.getElementById('option_monthly_5_error_card_number_2');

var option_monthly_5_error_cvv_card_1 = document.getElementById('option_monthly_5_error_cvv_card_1');
var option_monthly_5_error_cvv_card_2 = document.getElementById('option_monthly_5_error_cvv_card_2');

var option_monthly_5_error_expiration_month_1 = document.getElementById('option_monthly_5_error_expiration_month_1');
var option_monthly_5_error_expiration_month_2 = document.getElementById('option_monthly_5_error_expiration_month_2');
var option_monthly_5_error_expiration_month_3 = document.getElementById('option_monthly_5_error_expiration_month_3');
var option_monthly_5_error_expiration_month_4 = document.getElementById('option_monthly_5_error_expiration_month_4');

var option_monthly_5_tipoIdentificacionPayu_pse = document.getElementById('option_monthly_5_tipoIdentificacionPayu_pse');

var option_monthly_5_error_expiration_year_1 = document.getElementById('option_monthly_5_error_expiration_year_1');
var option_monthly_5_error_expiration_year_2 = document.getElementById('option_monthly_5_error_expiration_year_2');
var option_monthly_5_error_expiration_year_3 = document.getElementById('option_monthly_5_error_expiration_year_3');

var option_monthly_5_error_option_monthly_5_tyc = document.getElementById('option_monthly_5_error_option_monthly_5_t&c');

var option_monthly_5_error_option_monthly_5_tyc_form = document.getElementById('option_monthly_5_error_option_monthly_5_t&c_form');

var option_monthly_5_error_expired_card = document.getElementById('option_monthly_5_error_expired_card');

var option_monthly_5_error_payment_method = document.getElementById('option_monthly_5_error_payment_method');

var option_monthly_5_monthly_payu_pse = document.getElementById('option_monthly_5_monthly_payu_pse');

var option_monthly_5_tipoIdentificacionPayu = document.getElementById('option_monthly_5_tipoIdentificacionPayu');
var option_monthly_5_error_id_type_payu = document.getElementById('option_monthly_5_error_id_type_payu');

var option_monthly_5_tipoCuenta = document.getElementById('option_monthly_5_tipoCuenta');
var option_monthly_5_error_account_type = document.getElementById('option_monthly_5_error_account_type');

var option_monthly_5_error_bank_name = document.getElementById('option_monthly_5_error_bank_name');

var option_monthly_5_tipoIdentificacion = document.getElementById('option_monthly_5_tipoIdentificacion');
var option_monthly_5_error_id_type_bank = document.getElementById('option_monthly_5_error_id_type_bank');

var option_monthly_5_checkbox_TyC_form = document.getElementById('option_monthly_5_checkbox-T&C_form');

option_monthly_5_responseUrl.value = window.location.href;
option_monthly_5_responseUrl_pse.value = window.location.href;
option_monthly_5_confirmationUrl.value = window.location.href;

var option_monthly_5_currentUrl = window.location.href;
option_monthly_5_currentUrl = option_monthly_5_currentUrl.replace("https://", "");
var option_monthly_5_tokens = option_monthly_5_currentUrl.split("/");

//------------------------------------------
option_monthly_5_button1.innerHTML = '$ ' + parseInt(option_monthly_5_values[1 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES');
option_monthly_5_button2.innerHTML = '$ ' + parseInt(option_monthly_5_values[2 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES');
option_monthly_5_button3.innerHTML = '$ ' + parseInt(option_monthly_5_values[3 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES');

option_monthly_5_description.value = option_monthly_5_tokens[option_monthly_5_tokens.length - 2];
option_monthly_5_description_bank.value = option_monthly_5_tokens[option_monthly_5_tokens.length - 2];

option_monthly_5_payment_method_1.value = option_monthly_5_payment_method.value;

// Verificar si la cookie existe
var option_monthly_5_cookieExistente = getCookie("proyecto_donaciones_colombia_slug");

// Eliminar la cookie existente si hay una
if (option_monthly_5_cookieExistente) {
    document.cookie = "proyecto_donaciones_colombia_slug=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
}

// Crear la nueva cookie
document.cookie = "proyecto_donaciones_colombia_slug=" + encodeURIComponent(option_monthly_5_tokens[option_monthly_5_tokens.length - 2]) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";

var option_monthly_5_buttons = document.querySelectorAll('.option_monthly_5_myButton');
option_monthly_5_buttons[1].classList.add('active');
option_monthly_5_buttons.forEach((option_monthly_5_button) => {
    option_monthly_5_button.addEventListener('click', (event) => {
        option_monthly_5_buttons.forEach((option_monthly_5_button) => {
            option_monthly_5_button.classList.remove('active');
        });
        event.target.classList.add('active');

        option_monthly_5_montoInput.style.borderColor = "#FCBB29";
        option_monthly_5_error_monto_1.style.display = "none";
        option_monthly_5_error_monto_2.style.display = "none";
        option_monthly_5_error_monto_3.style.display = "none";
        option_monthly_5_error_monto_4.style.display = "none";

        option_monthly_5_buttonSelected = Array.from(option_monthly_5_buttons).indexOf(event.target);
        if(option_monthly_5_buttonSelected >= 0 && option_monthly_5_buttonSelected < 3){
            option_monthly_5_montoInput.value = "";
            option_monthly_5_monto_form.value = option_monthly_5_values[option_monthly_5_buttonSelected+1+option_monthly_5_payment_button_selected];
            option_monthly_5_monto_form_1.value = option_monthly_5_values[option_monthly_5_buttonSelected+1+option_monthly_5_payment_button_selected];
            option_monthly_5_montoInputPayu.value = option_monthly_5_values[option_monthly_5_buttonSelected+1+option_monthly_5_payment_button_selected];
            option_monthly_5_amount_payu_pse.value = option_monthly_5_values[option_monthly_5_buttonSelected+1+option_monthly_5_payment_button_selected];
            //option_monthly_5_taxReturnBase.value =  option_monthly_5_values[option_monthly_5_buttonSelected+1];
        }
        //------------------------------------------
    });
});
//-------------------------------------------------------------------------------
option_monthly_5_montoInput.addEventListener('click', () => {

    option_monthly_5_buttons.forEach((button) => {
        button.classList.remove('active');
    });
    option_monthly_5_buttonSelected = 3;
    option_monthly_5_monto_form.value = option_monthly_5_montoInput.value;
    option_monthly_5_monto_form_1.value = option_monthly_5_montoInput.value;
    option_monthly_5_montoInputPayu.value = option_monthly_5_montoInput.value;
    option_monthly_5_amount_payu_pse.value = option_monthly_5_montoInput.value;
    //option_monthly_5_taxReturnBase.value =  option_monthly_5_montoInput.value;

});
//-------------------------------------------------------------------------------
var option_monthly_5_buttons_1 = document.querySelectorAll('.option_monthly_5_myButton_1');

option_monthly_5_buttons_1[1].classList.add('active');
option_monthly_5_buttons_1.forEach((option_monthly_5_button) => {
    option_monthly_5_button.addEventListener('click', (event) => {
        option_monthly_5_buttons_1.forEach((option_monthly_5_button) => {
            option_monthly_5_button.classList.remove('active');
        });
        event.target.classList.add('active');
        option_monthly_5_buttonSelected_1 = Array.from(option_monthly_5_buttons_1).indexOf(event.target);
        
        if (option_monthly_5_buttonSelected_1 == 1){
            option_monthly_5_payment_button_selected = 0;

            option_monthly_5_montoInput.style.borderColor = "#FCBB29";
            option_monthly_5_error_monto_3.style.display = "none";
            option_monthly_5_error_monto_4.style.display = "none";

            option_monthly_5_nombreBanco.innerHTML = '';
            var options = [
                {text: 'BANCO DE BOGOTÁ', value: 'BANCO DE BOGOTÁ'},
                {text: 'BANCO POPULAR', value: 'BANCO POPULAR'},
                {text: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCOLOMBIA S.A.', value: 'BANCOLOMBIA S.A.'},
                {text: 'BANCO GNB SUDAMERIS S.A.', value: 'BANCO GNB SUDAMERIS S.A.'},
                {text: 'BBVA COLOMBIA', value: 'BBVA COLOMBIA'},
                {text: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCO COLPATRIA', value: 'BANCO COLPATRIA'},
                {text: 'BANCO DE OCCIDENTE', value: 'BANCO DE OCCIDENTE'},
                {text: 'BANCOLDEX', value: 'BANCOLDEX'},
                {text: 'BANCO CAJA SOCIAL - BCSC S.A.', value: 'BANCO CAJA SOCIAL - BCSC S.A.'},
                {text: 'BANCO AGRARIO DE COLOMBIA S.A.', value: 'BANCO AGRARIO DE COLOMBIA S.A.'},
                {text: 'BANCO DAVIVIENDA S.A.', value: 'BANCO DAVIVIENDA S.A.'},
                {text: 'BANCO AV VILLAS', value: 'BANCO AV VILLAS'},
                {text: 'BANCOOMEVA', value: 'BANCOOMEVA'},
                {text: 'BANCO FALABELLA S.A.', value: 'BANCO FALABELLA S.A.'},
                {text: 'BANCO MUNDO MUJER', value: 'BANCO MUNDO MUJER'},
                {text: 'BANCO MULTIBANK', value: 'BANCO MULTIBANK'},
                {text: 'BANCO SANTANDER NEGOCIOS COLOMBIA', value: 'BANCO SANTANDER NEGOCIOS COLOMBIA'},
                {text: 'BANCO COOPERATIVO COOPENTRAL', value: 'BANCO COOPERATIVO COOPENTRAL'},
                {text: 'BANCO COMPARTIR SA', value: 'BANCO COMPARTIR SA'},
                {text: 'BANCO SERFINANZA SA', value: 'BANCO SERFINANZA SA'},
                {text: 'FINANCIERA JURISCOOP', value: 'FINANCIERA JURISCOOP'},
                {text: 'COOPERATIVA FINANCIERA ANTIOQUIA', value: 'COOPERATIVA FINANCIERA ANTIOQUIA'},
                {text: 'CONTRAFA', value: 'CONTRAFA'},
                {text: 'BANCO CONFIAR', value: 'BANCO CONFIAR'},
                {text: 'COLTEFINANCIERA', value: 'COLTEFINANCIERA'},
                {text: 'Deceval S.A', value: 'Deceval S.A'},
                {text: 'DTN', value: 'DTN'},
                {text: 'DGCPTN SISTEMA GENERAL DE REGALIAS', value: 'DGCPTN SISTEMA GENERAL DE REGALIAS'},
            ];

            for (var i = 0; i < options.length; i++) {
                var option = document.createElement('option');
                option.value = options[i].value;
                option.text = options[i].text;
                option_monthly_5_nombreBanco.appendChild(option);
            }

            option_monthly_5_payment_method.innerHTML = '';

            var defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.text = "Seleccione el método de pago";
            defaultOption.disabled = true;
            defaultOption.selected = true;
            option_monthly_5_payment_method.appendChild(defaultOption);

            var options_payment = [
                {text: 'tarjeta', value: 'Tarjeta'},
                {text: 'Cuenta Bancaria', value: 'Cuenta de banco'},
            ];

            for (var i = 0; i < options_payment.length; i++) {
                var option = document.createElement('option');
                option.value = options_payment[i].value;
                option.text = options_payment[i].text;
                option_monthly_5_payment_method.appendChild(option);
            }
        }
        else
        {
            option_monthly_5_payment_button_selected = 3;

            option_monthly_5_montoInput.style.borderColor = "#FCBB29";
            option_monthly_5_error_monto_3.style.display = "none";
            option_monthly_5_error_monto_4.style.display = "none";

            option_monthly_5_nombreBanco.innerHTML = '';
            var options = [
                {text: 'BANCO DE BOGOTÁ', value: 'BANCO DE BOGOTÁ'},
                {text: 'BANCO POPULAR', value: 'BANCO POPULAR'},
                {text: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: 'BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCOLOMBIA S.A.', value: 'BANCOLOMBIA S.A.'},
                {text: 'BANCO GNB SUDAMERIS S.A.', value: 'BANCO GNB SUDAMERIS S.A.'},
                {text: 'BBVA COLOMBIA', value: 'BBVA COLOMBIA'},
                {text: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.', value: '(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.'},
                {text: 'BANCO COLPATRIA', value: 'BANCO COLPATRIA'},
                {text: 'BANCO DE OCCIDENTE', value: 'BANCO DE OCCIDENTE'},
                {text: 'BANCOLDEX', value: 'BANCOLDEX'},
                {text: 'BANCO CAJA SOCIAL - BCSC S.A.', value: 'BANCO CAJA SOCIAL - BCSC S.A.'},
                {text: 'BANCO AGRARIO DE COLOMBIA S.A.', value: 'BANCO AGRARIO DE COLOMBIA S.A.'},
                {text: 'BANCO DAVIVIENDA S.A.', value: 'BANCO DAVIVIENDA S.A.'},
                {text: 'BANCO AV VILLAS', value: 'BANCO AV VILLAS'},
                {text: 'BANCOOMEVA', value: 'BANCOOMEVA'},
                {text: 'BANCO FALABELLA S.A.', value: 'BANCO FALABELLA S.A.'},
                {text: 'BANCO MUNDO MUJER', value: 'BANCO MUNDO MUJER'},
                {text: 'BANCO MULTIBANK', value: 'BANCO MULTIBANK'},
                {text: 'BANCO SANTANDER NEGOCIOS COLOMBIA', value: 'BANCO SANTANDER NEGOCIOS COLOMBIA'},
                {text: 'BANCO COOPERATIVO COOPENTRAL', value: 'BANCO COOPERATIVO COOPENTRAL'},
                {text: 'BANCO COMPARTIR SA', value: 'BANCO COMPARTIR SA'},
                {text: 'BANCO SERFINANZA SA', value: 'BANCO SERFINANZA SA'},
                {text: 'FINANCIERA JURISCOOP', value: 'FINANCIERA JURISCOOP'},
                {text: 'RAPPIPAY', value: 'RAPPIPAY'},
                {text: 'COOPERATIVA FINANCIERA ANTIOQUIA', value: 'COOPERATIVA FINANCIERA ANTIOQUIA'},
                {text: 'CONTRAFA', value: 'CONTRAFA'},
                {text: 'BANCO CONFIAR', value: 'BANCO CONFIAR'},
                {text: 'COLTEFINANCIERA', value: 'COLTEFINANCIERA'},
                {text: 'NEQUI BANCOLOMBIA', value: 'NEQUI BANCOLOMBIA'},
                {text: 'Deceval S.A', value: 'Deceval S.A'},
                {text: 'DAVIPLATA', value: 'DAVIPLATA'},
                {text: 'DTN', value: 'DTN'},
                {text: 'DGCPTN SISTEMA GENERAL DE REGALIAS', value: 'DGCPTN SISTEMA GENERAL DE REGALIAS'},
            ];

            for (var i = 0; i < options.length; i++) {
                var option = document.createElement('option');
                option.value = options[i].value;
                option.text = options[i].text;
                option_monthly_5_nombreBanco.appendChild(option);
            }

            option_monthly_5_payment_method.innerHTML = '';

            var defaultOption = document.createElement('option');
            defaultOption.value = "";
            defaultOption.text = "Seleccione el método de pago";
            defaultOption.disabled = true;
            defaultOption.selected = true;
            option_monthly_5_payment_method.appendChild(defaultOption);

            var options_payment = [
                {text: 'tarjeta', value: 'Tarjeta'},
                {text: 'Cuenta Bancaria', value: 'Cuenta de banco'},
                {text: 'PSE', value: 'PSE'},
            ];

            for (var i = 0; i < options_payment.length; i++) {
                var option = document.createElement('option');
                option.value = options_payment[i].value;
                option.text = options_payment[i].text;
                option_monthly_5_payment_method.appendChild(option);
            }
        }

        option_monthly_5_button1.innerHTML = '$ ' + parseInt(option_monthly_5_values[1 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES');
        option_monthly_5_button2.innerHTML = '$ ' + parseInt(option_monthly_5_values[2 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES');
        option_monthly_5_button3.innerHTML = '$ ' + parseInt(option_monthly_5_values[3 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES');

        option_monthly_5_monthly_payu.value = option_monthly_5_buttonSelected_1.toString();

        option_monthly_5_monthly_bank.value = option_monthly_5_buttonSelected_1.toString();

    });
});
//-------------------------------------------------------------------------------
option_monthly_5_checkbox.addEventListener('change', function() {
    // Verificar si el option_monthly_5_checkbox está marcado
    if (option_monthly_5_checkbox.checked) {
        // Mostrar el contenedor del regalo
        option_monthly_5_giftContainer.style.display = 'block';
        containerVideo.style.display = 'none';
        option_monthly_5_is_gift_bank.value = "1";
        option_monthly_5_is_gift_payu.value = "1";
        option_monthly_5_is_gift_payu_pse.value = "1";
    } else {
        // Ocultar el contenedor del regalo
        option_monthly_5_giftContainer.style.display = 'none';
        containerVideo.style.display = 'block';
        option_monthly_5_is_gift_bank.value = "0";
        option_monthly_5_is_gift_payu.value = "0";
        option_monthly_5_is_gift_payu_pse.value = "0";
    }
});
//-------------------------------------------------------------------------------
option_monthly_5_buttons.forEach((option_monthly_5_button, index) => {
    option_monthly_5_button.addEventListener('click', (event) => {
        option_monthly_5_buttons.forEach((option_monthly_5_button) => {
            option_monthly_5_button.classList.remove('active');
        });
        event.target.classList.add('active');

        option_monthly_5_buttonSelected = index;  // Aseguramos que option_monthly_5_buttonSelected refleje el índice del botón general seleccionado
    });
});
//-------------------------------------------------------------------------------
option_monthly_5_montoInput.addEventListener("input", function() {
    if (option_monthly_5_buttonSelected === 3){

        option_monthly_5_montoInput.style.borderColor = "#FCBB29";
        option_monthly_5_error_monto_1.style.display = "none";
        option_monthly_5_error_monto_2.style.display = "none";
        option_monthly_5_error_monto_3.style.display = "none";
        option_monthly_5_error_monto_4.style.display = "none";

        var value = option_monthly_5_montoInput.value;

        // Remover caracteres que no sean números o punto
        value = value.replace(/[^0-9]/g, '');

        // Formatear el número con puntos de miles
        value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');

        // Añadir el signo de pesos al principio
        option_monthly_5_montoInput.value = '$' + value;

        option_monthly_5_monto_form.value = option_monthly_5_montoInput.value.replace(/\$|\./g, '');
        option_monthly_5_montoInputPayu.value = option_monthly_5_montoInput.value.replace(/\$|\./g, '');
        option_monthly_5_amount_payu_pse.value = option_monthly_5_montoInput.value.replace(/\$|\./g, '');
        //option_monthly_5_taxReturnBase.value =  option_monthly_5_montoInput.value;

        option_monthly_5_montoInput.focus()
        option_monthly_5_montoInput.setSelectionRange(option_monthly_5_montoInput.value.length, option_monthly_5_montoInput.value.length);

    }
    //------------------------------------------
});
//-------------------------------------------------------------------------------
option_monthly_5_nombre_1.addEventListener("input", function() {
    // Verificar si la cookie existe
    var option_monthly_5_cookieExistente = getCookie("proyecto_donaciones_colombia_nombre");

    // Eliminar la cookie existente si hay una
    if (option_monthly_5_cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_nombre=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_nombre=" + encodeURIComponent(option_monthly_5_nombre_1.value + " " + option_monthly_5_apellido_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
});
//-------------------------------------------------------------------------------
option_monthly_5_apellido_1.addEventListener("input", function() {
    // Verificar si la cookie existe
    var option_monthly_5_cookieExistente = getCookie("proyecto_donaciones_colombia_nombre");

    // Eliminar la cookie existente si hay una
    if (option_monthly_5_cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_nombre=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_nombre=" + encodeURIComponent(option_monthly_5_nombre_1.value + " " + option_monthly_5_apellido_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
});
//-------------------------------------------------------------------------------
option_monthly_5_correoElectronico_1.addEventListener("input", function() {

    // Verificar si la cookie existe
    var option_monthly_5_cookieExistente = getCookie("proyecto_donaciones_colombia_correo");

    // Eliminar la cookie existente si hay una
    if (option_monthly_5_cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_correo=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_correo=" + encodeURIComponent(option_monthly_5_correoElectronico_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";

});
//-------------------------------------------------------------------------------
option_monthly_5_correoElectronico_1.addEventListener("input", function() {

    // Verificar si la cookie existe
    var option_monthly_5_cookieExistente = getCookie("proyecto_donaciones_colombia_correo");

    // Eliminar la cookie existente si hay una
    if (option_monthly_5_cookieExistente) {
        document.cookie = "proyecto_donaciones_colombia_correo=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
    }

    // Crear la nueva cookie
    document.cookie = "proyecto_donaciones_colombia_correo=" + encodeURIComponent(option_monthly_5_correoElectronico_1.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";

});
//-------------------------------------------------------------------------------
option_monthly_5_next_step.addEventListener('click', () => {
    
    if (option_monthly_5_checkbox.checked) {
        if(option_monthly_5_giftEmail.value === ""){
            option_monthly_5_giftEmail.style.borderColor = "red";
            option_monthly_5_error_email_gift_1.style.display = "block";
            return;
        }
        else{
            option_monthly_5_giftEmail.style.borderColor = "#cfcfcf";
            option_monthly_5_error_email_gift_1.style.display = "none";
        }

        var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (patronEmail.test(option_monthly_5_giftEmail.value) === false){
            option_monthly_5_giftEmail.style.borderColor = "red";
            option_monthly_5_error_email_gift_2.style.display = "block";
            return;
        }
        else{
            option_monthly_5_giftEmail.style.borderColor = "#cfcfcf";
            option_monthly_5_error_email_gift_2.style.display = "none";
        }

        if(option_monthly_5_whoName.value === ""){
            option_monthly_5_whoName.style.borderColor = "red";
            option_monthly_5_error_whoName_gift.style.display = "block";
            return;
        }
        else{
            option_monthly_5_whoName.style.borderColor = "#cfcfcf";
            option_monthly_5_error_whoName_gift.style.display = "none";
        }

        /*
        if(option_monthly_5_message.value === ""){
            option_monthly_5_message.style.borderColor = "red";
            option_monthly_5_error_message_gift.style.display = "block";
            return;
        }
        else{
            option_monthly_5_message.style.borderColor = "#cfcfcf";
            option_monthly_5_error_message_gift.style.display = "none";
        }
        */
    }

    if(option_monthly_5_buttonSelected === 3){
        if (option_monthly_5_montoInput.value === ""){
            option_monthly_5_montoInput.style.borderColor = "red";
            option_monthly_5_error_monto_1.style.display = "block";
            return;
        }
        else{
            option_monthly_5_montoInput.style.borderColor = "#FCBB29";
            option_monthly_5_error_monto_1.style.display = "none";
        }

        var regex = /^\$\d{1,3}(?:\.\d{3})*$/;

        if (!regex.test(option_monthly_5_montoInput.value)) {
            option_monthly_5_montoInput.style.borderColor = "red";
            option_monthly_5_error_monto_2.style.display = "block";
            return;
        }
        else{
            option_monthly_5_montoInput.style.borderColor = "#FCBB29";
            option_monthly_5_error_monto_2.style.display = "none";
        }

        if (parseInt(option_monthly_5_montoInput.value.replace(/\$|\./g, ''), 10) < option_monthly_5_values[1 + option_monthly_5_payment_button_selected] && option_monthly_5_buttonSelected_1 == 1){
            option_monthly_5_montoInput.style.borderColor = "red";
            option_monthly_5_error_monto_3.textContent = "El monto a donar debe ser mayor a " + parseInt(option_monthly_5_values[1 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES') + " COP";

            option_monthly_5_error_monto_3.style.display = "block";
            return;
        }
        if (parseInt(option_monthly_5_montoInput.value.replace(/\$|\./g, ''), 10) < option_monthly_5_values[1 + option_monthly_5_payment_button_selected] && option_monthly_5_buttonSelected_1 == 0){
            option_monthly_5_montoInput.style.borderColor = "red";
            option_monthly_5_error_monto_4.textContent = "El monto a donar debe ser mayor a " + parseInt(option_monthly_5_values[1 + option_monthly_5_payment_button_selected], 10).toLocaleString('es-ES') + " COP";
            option_monthly_5_error_monto_4.style.display = "block";
            return;
        }
        else{
            option_monthly_5_montoInput.style.borderColor = "#FCBB29";
            option_monthly_5_error_monto_3.style.display = "none";
            option_monthly_5_error_monto_4.style.display = "none";
        }
    }

    var string_1 = '';
    if(option_monthly_5_buttonSelected >= 0 && option_monthly_5_buttonSelected < 3){
        var number_1 = parseInt(option_monthly_5_values[option_monthly_5_buttonSelected+1+option_monthly_5_payment_button_selected])
        string_1 = number_1.toLocaleString('es-ES') + ' COP';
    }
    else{
        var number_1 = parseInt(option_monthly_5_montoInput.value.replace(/\$|\./g, ''));
        string_1 = number_1.toLocaleString('es-ES') + ' COP';
    }

    if (option_monthly_5_buttonSelected_1 == 0){
        option_monthly_5_info_payu.innerHTML = 'Estas donando: <span id="option_monthly_5_valorDonacion">'+string_1+'</span>';
        option_monthly_5_info_bank.innerHTML = 'Estas donando: <span id="option_monthly_5_valorDonacion_bank">'+string_1+'</span>';
        option_monthly_5_info_form.innerHTML = 'Estas donando: <span id="option_monthly_5_valorDonacion_form">'+string_1+'</span>';
        
    }
    else{
        option_monthly_5_info_payu.innerHTML = 'Estas donando mensualmente: <span id="option_monthly_5_valorDonacion">'+string_1+'</span>';
        option_monthly_5_info_bank.innerHTML = 'Estas donando mensualmente: <span id="option_monthly_5_valorDonacion_bank">'+string_1+'</span>';
        option_monthly_5_info_form.innerHTML = 'Estas donando mensualmente: <span id="option_monthly_5_valorDonacion_form">'+string_1+'</span>';
    }

    option_monthly_5_values_container.style.display = 'none';
    option_monthly_5_form4.style.display = 'block';
    pasosContainer_optionmonthly5.style.display = 'block';
    customTitle_opm1.style.display='none';
    paso_text1_opm1.style.display='block'; 


});
//-------------------------------------------------------------------------------
option_monthly_5_atras.addEventListener('click', () => {
    if(option_monthly_5_form2.style.display == 'block' || option_monthly_5_form3.style.display == 'block'){
        option_monthly_5_form4.style.display = 'block';
        paso_text1_opm1.style.display = 'block';
        option_monthly_5_form2.style.display = 'none';
        option_monthly_5_form3.style.display = 'none';
        paso_text2_opm1.style.display = 'none';
    }
    else{
        option_monthly_5_values_container.style.display = 'block';
        customTitle_opm1.style.display='block'
        option_monthly_5_form4.style.display = 'none';        
        pasosContainer_optionmonthly5.style.display = 'none';
    }
});
//-------------------------------------------------------------------------------

//-------------------------------------------------------------------------------
option_monthly_5_payu_1.addEventListener('click', () => {

    if (option_monthly_5_nameInputPayu.value === ""){
        option_monthly_5_nameInputPayu.style.borderColor = "red";
        option_monthly_5_error_payerFullName_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_nameInputPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_payerFullName_1.style.display = "none";
    }

    if (option_monthly_5_lastNameInputPayu.value === ""){
        option_monthly_5_lastNameInputPayu.style.borderColor = "red";
        option_monthly_5_error_payerFullName_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_lastNameInputPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_payerFullName_2.style.display = "none";
    }

    if (option_monthly_5_tipoIdentificacionPayu.value === ""){
        option_monthly_5_tipoIdentificacionPayu.style.borderColor = "red";
        option_monthly_5_error_id_type_payu.style.display = "block";
        return;
    }
    else{
        option_monthly_5_tipoIdentificacionPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_id_type_payu.style.display = "none";
    }

    if(option_monthly_5_numeroIdentificacionPayu.value === ""){
        option_monthly_5_numeroIdentificacionPayu.style.borderColor = "red";
        option_monthly_5_error_numeroIdentificacionPayu_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_numeroIdentificacionPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroIdentificacionPayu_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_numeroIdentificacionPayu.value) && option_monthly_5_tipoIdentificacionPayu.value != "Pasaporte"){
        option_monthly_5_numeroIdentificacionPayu.style.borderColor = "red";
        option_monthly_5_error_numeroIdentificacionPayu_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_numeroIdentificacionPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroIdentificacionPayu_2.style.display = "none";
    }

    if(option_monthly_5_phoneInputPayu.value === ""){
        option_monthly_5_phoneInputPayu.style.borderColor = "red";
        option_monthly_5_error_payerPhone_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_phoneInputPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_payerPhone_1.style.display = "none";
    }

    var patronTelefono = /^3\d{9}$/;
    if (patronTelefono.test(option_monthly_5_phoneInputPayu.value) === false){
        option_monthly_5_phoneInputPayu.style.borderColor = "red";
        option_monthly_5_error_payerPhone_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_phoneInputPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_payerPhone_2.style.display = "none";
    }

    if(option_monthly_5_emailInputPayu.value === ""){
        option_monthly_5_emailInputPayu.style.borderColor = "red";
        option_monthly_5_error_email_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_emailInputPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_email_1.style.display = "none";
    }

    var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (patronEmail.test(option_monthly_5_emailInputPayu.value) === false){
        option_monthly_5_emailInputPayu.style.borderColor = "red";
        option_monthly_5_error_email_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_emailInputPayu.style.borderColor = "#cfcfcf";
        option_monthly_5_error_email_2.style.display = "none";
    }

    if (option_monthly_5_payment_method_type_card.value === ""){
        option_monthly_5_payment_method_type_card.style.borderColor = "red";
        option_monthly_5_payment_method_type_card_error.style.display = "block";
        return;
    }
    else{
        option_monthly_5_payment_method_type_card.style.borderColor = "#cfcfcf";
        option_monthly_5_payment_method_type_card_error.style.display = "none";
    }

    if (option_monthly_5_payment_method_brand_card.value === ""){
        option_monthly_5_payment_method_brand_card.style.borderColor = "red";
        option_monthly_5_payment_method_brand_card_error.style.display = "block";
        return;
    }
    else{
        option_monthly_5_payment_method_brand_card.style.borderColor = "#cfcfcf";
        option_monthly_5_payment_method_brand_card_error.style.display = "none";
    }

    if (option_monthly_5_card_number.value === ""){
        option_monthly_5_card_number.style.borderColor = "red";
        option_monthly_5_error_card_number_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_card_number.style.borderColor = "#cfcfcf";
        option_monthly_5_error_card_number_1.style.display = "none";
    }

    var numeroLimpiado = option_monthly_5_card_number.value.replace(/[\s-]/g, '');
    if (/^\d{16}$/.test(numeroLimpiado) === false || isNaN(numeroLimpiado) ) {
        option_monthly_5_card_number.style.borderColor = "red";
        option_monthly_5_error_card_number_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_card_number.style.borderColor = "#cfcfcf";
        option_monthly_5_error_card_number_2.style.display = "none";
    }

    if (option_monthly_5_cvv_card.value === ""){
        option_monthly_5_cvv_card.style.borderColor = "red";
        option_monthly_5_error_cvv_card_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_cvv_card.style.borderColor = "#cfcfcf";
        option_monthly_5_error_cvv_card_1.style.display = "none";
    }

    if (option_monthly_5_cvv_card.value.length != 3 || isNaN(option_monthly_5_cvv_card.value) ) {
        option_monthly_5_cvv_card.style.borderColor = "red";
        option_monthly_5_error_cvv_card_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_cvv_card.style.borderColor = "#cfcfcf";
        option_monthly_5_error_cvv_card_2.style.display = "none";
    }

    if (option_monthly_5_expiration_month.value === ""){
        option_monthly_5_expiration_month.style.borderColor = "red";
        option_monthly_5_error_expiration_month_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_month.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_month_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_expiration_month.value)){
        option_monthly_5_expiration_month.style.borderColor = "red";
        option_monthly_5_error_expiration_month_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_month.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_month_2.style.display = "none";
    }

    if (option_monthly_5_expiration_month.value.length != 2){
        option_monthly_5_expiration_month.style.borderColor = "red";
        option_monthly_5_error_expiration_month_3.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_month.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_month_3.style.display = "none";
    }

    if (parseInt(option_monthly_5_expiration_month.value, 10) > 12 || parseInt(option_monthly_5_expiration_month.value, 10) < 1){
        option_monthly_5_expiration_month.style.borderColor = "red";
        option_monthly_5_error_expiration_month_4.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_month.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_month_4.style.display = "none";
    }

    if (option_monthly_5_expiration_year.value === ""){
        option_monthly_5_expiration_year.style.borderColor = "red";
        option_monthly_5_error_expiration_year_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_year.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_year_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_expiration_year.value)){
        option_monthly_5_expiration_year.style.borderColor = "red";
        option_monthly_5_error_expiration_year_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_year.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_year_2.style.display = "none";
    }

    if (option_monthly_5_expiration_year.value.length != 4){
        option_monthly_5_expiration_year.style.borderColor = "red";
        option_monthly_5_error_expiration_year_3.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_year.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expiration_year_3.style.display = "none";
    }

    if(!option_monthly_5_tyc.checked){
        option_monthly_5_tyc.style.borderColor = "red";
        option_monthly_5_error_option_monthly_5_tyc.style.display = "block";
        return;
    }
    else{
        option_monthly_5_tyc.style.borderColor = "#cfcfcf";
        option_monthly_5_error_option_monthly_5_tyc.style.display = "none";
    }

    var option_monthly_5_fechaActual = new Date();

    var option_monthly_5_fechaPropuesta = new Date(parseInt(option_monthly_5_expiration_year.value, 10), parseInt(option_monthly_5_expiration_month.value, 10) - 1);

    if (option_monthly_5_fechaPropuesta < option_monthly_5_fechaActual) {
        option_monthly_5_expiration_month.style.borderColor = "red";
        option_monthly_5_expiration_year.style.borderColor = "red";
        option_monthly_5_error_expired_card.style.display = "block";
        return;
    }
    else{
        option_monthly_5_expiration_month.style.borderColor = "#cfcfcf";
        option_monthly_5_expiration_year.style.borderColor = "#cfcfcf";
        option_monthly_5_error_expired_card.style.display = "none";
    }

    option_monthly_5_payu_1.style.display = "none";
    option_monthly_5_payu_2.style.display = "block";

    option_monthly_5_payu.click();
});
//-------------------------------------------------------------------------------
option_monthly_5_payment_method.addEventListener('change', () => {
    if(option_monthly_5_payment_method.value == "PSE"){
        option_monthly_5_nombreBanco_1.style.display = 'block';
        option_monthly_5_checkbox_TyC_form.style.display = 'flex';
        option_monthly_5_info_form.style.display = 'block';
        option_monthly_5_next_step_1.innerText = '¡Confirmar donación! 🤍';
    }
    else{
        option_monthly_5_nombreBanco_1.style.display = 'none';
        option_monthly_5_checkbox_TyC_form.style.display = 'none';
        option_monthly_5_info_form.style.display = 'none';
        option_monthly_5_next_step_1.innerText = 'Siguiente';
    }
    //option_monthly_5_payment_method_1.value = option_monthly_5_payment_method.value;
    option_monthly_5_payment_method.style.borderColor = "#cfcfcf";
    option_monthly_5_tyc.style.borderColor = "#cfcfcf";
    option_monthly_5_error_option_monthly_5_tyc.style.display = "none";
    option_monthly_5_error_payment_method.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_guardar_1.addEventListener('click', () => {
    var option_monthly_5_error_guardar = false;

    if(option_monthly_5_name_form.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_name_form.style.borderColor = "red";
        option_monthly_5_error_nombre_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_name_form.style.borderColor = "#cfcfcf";
        option_monthly_5_error_nombre_1.style.display = "none";
    }

    if(option_monthly_5_apellido.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_apellido.style.borderColor = "red";
        option_monthly_5_error_nombre_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_apellido.style.borderColor = "#cfcfcf";
        option_monthly_5_error_nombre_2.style.display = "none";
    }

    if(option_monthly_5_tipoCuenta.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_tipoCuenta.style.borderColor = "red";
        option_monthly_5_error_account_type.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_tipoCuenta.style.borderColor = "#cfcfcf";
        option_monthly_5_error_account_type.style.display = "none";
    }

    if(option_monthly_5_numeroCuenta.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroCuenta.style.borderColor = "red";
        option_monthly_5_error_numeroCuenta_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroCuenta.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroCuenta_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_numeroCuenta.value)){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroCuenta.style.borderColor = "red";
        option_monthly_5_error_numeroCuenta_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroCuenta.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroCuenta_2.style.display = "none";
    }

    if(option_monthly_5_nombreBanco.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_nombreBanco.style.borderColor = "red";
        option_monthly_5_error_bank_name.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_nombreBanco.style.borderColor = "#cfcfcf";
        option_monthly_5_error_bank_name.style.display = "none";
    }

    if(option_monthly_5_tipoIdentificacion.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_tipoIdentificacion.style.borderColor = "red";
        option_monthly_5_error_id_type_bank.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_tipoIdentificacion.style.borderColor = "#cfcfcf";
        option_monthly_5_error_id_type_bank.style.display = "none";
    }

    if(option_monthly_5_numeroIdentificacion.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroIdentificacion.style.borderColor = "red";
        option_monthly_5_error_numeroIdentificacion_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroIdentificacion.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroIdentificacion_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_numeroIdentificacion.value) && option_monthly_5_tipoIdentificacion.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroIdentificacion.style.borderColor = "red";
        option_monthly_5_error_numeroIdentificacion_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroIdentificacion.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroIdentificacion_2.style.display = "none";
    }

    if(option_monthly_5_cvv.value !== "" && isNaN(parseFloat(option_monthly_5_cvv.value)) && isFinite(option_monthly_5_cvv.value)){
        option_monthly_5_error_guardar = true;
        alert('El campo "CVV" solo puede contener números');
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
    }

    if(option_monthly_5_phone_form.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_phone_form.style.borderColor = "red";
        option_monthly_5_error_numeroTelefono_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_phone_form.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroTelefono_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_phone_form.value)){
        option_monthly_5_error_guardar = true;
        option_monthly_5_phone_form.style.borderColor = "red";
        option_monthly_5_error_numeroTelefono_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_phone_form.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroTelefono_2.style.display = "none";
    }

    var patronTelefono = /^3\d{9}$/;
    if (patronTelefono.test(option_monthly_5_phone_form.value) === false){
        option_monthly_5_error_guardar = true;
        option_monthly_5_phone_form.style.borderColor = "red";
        option_monthly_5_error_numeroTelefono_3.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_phone_form.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroTelefono_3.style.display = "none";
    }

    if(option_monthly_5_email_form.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_email_form.style.borderColor = "red";
        option_monthly_5_error_correoElectronico_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_email_form.style.borderColor = "#cfcfcf";
        option_monthly_5_error_correoElectronico_1.style.display = "none";
    }

    var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (patronEmail.test(option_monthly_5_email_form.value) === false){
        option_monthly_5_error_guardar = true;
        option_monthly_5_email_form.style.borderColor = "red";
        option_monthly_5_error_correoElectronico_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_email_form.style.borderColor = "#cfcfcf";
        option_monthly_5_error_correoElectronico_2.style.display = "none";
    }

    if(!option_monthly_5_tyc_bank.checked){
        option_monthly_5_error_guardar = true;
        option_monthly_5_tyc_bank.style.borderColor = "red";
        option_monthly_5_error_checkbox_TyC_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_tyc_bank.style.borderColor = "#cfcfcf";
        option_monthly_5_error_checkbox_TyC_1.style.display = "none";
    }

    if (option_monthly_5_error_guardar === false){
        option_monthly_5_guardar_1.style.display = "none";
        option_monthly_5_guardar_2.style.display = "block";
        option_monthly_5_guardar.click();
    }
});
//-------------------------------------------------------------------------------
option_monthly_5_next_step_1.addEventListener('click', () => {
    var option_monthly_5_error_guardar = false;

    if(option_monthly_5_nombre_1.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_nombre_1.style.borderColor = "red";
        option_monthly_5_error_nombre_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_nombre_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_nombre_1.style.display = "none";
    }

    if(option_monthly_5_apellido_1.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_apellido_1.style.borderColor = "red";
        option_monthly_5_error_nombre_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_apellido_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_nombre_2.style.display = "none";
    }

    if(option_monthly_5_person_type.value === ""){
        option_monthly_5_person_type.style.borderColor = "red";
        option_monthly_5_error_person_type.style.display = "block";
        return;
    }
    else{
        option_monthly_5_person_type.style.borderColor = "#cfcfcf";
        option_monthly_5_error_person_type.style.display = "none";
    }

    if(option_monthly_5_tipoIdentificacion_1.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_tipoIdentificacion_1.style.borderColor = "red";
        option_monthly_5_error_id_type_bank.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_tipoIdentificacion_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_id_type_bank.style.display = "none";
    }

    if(option_monthly_5_numeroIdentificacion_1.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroIdentificacion_1.style.borderColor = "red";
        option_monthly_5_error_numeroIdentificacion_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroIdentificacion_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroIdentificacion_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_numeroIdentificacion_1.value) && option_monthly_5_tipoIdentificacion_1.value != "Pasaporte"){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroIdentificacion_1.style.borderColor = "red";
        option_monthly_5_error_numeroIdentificacion_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroIdentificacion_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroIdentificacion_2.style.display = "none";
    }

    if(option_monthly_5_numeroTelefono_1.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroTelefono_1.style.borderColor = "red";
        option_monthly_5_error_numeroTelefono_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroTelefono_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroTelefono_1.style.display = "none";
    }

    if(isNaN(option_monthly_5_numeroTelefono_1.value)){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroTelefono_1.style.borderColor = "red";
        option_monthly_5_error_numeroTelefono_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroTelefono_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroTelefono_2.style.display = "none";
    }

    var patronTelefono = /^3\d{9}$/;
    if (patronTelefono.test(option_monthly_5_numeroTelefono_1.value) === false){
        option_monthly_5_error_guardar = true;
        option_monthly_5_numeroTelefono_1.style.borderColor = "red";
        option_monthly_5_error_numeroTelefono_3.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_numeroTelefono_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_numeroTelefono_3.style.display = "none";
    }

    if(option_monthly_5_correoElectronico_1.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_correoElectronico_1.style.borderColor = "red";
        option_monthly_5_error_correoElectronico_1.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_correoElectronico_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_correoElectronico_1.style.display = "none";
    }

    var patronEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (patronEmail.test(option_monthly_5_correoElectronico_1.value) === false){
        option_monthly_5_error_guardar = true;
        option_monthly_5_correoElectronico_1.style.borderColor = "red";
        option_monthly_5_error_correoElectronico_2.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_correoElectronico_1.style.borderColor = "#cfcfcf";
        option_monthly_5_error_correoElectronico_2.style.display = "none";
    }

    if (option_monthly_5_payment_method.value === ""){
        option_monthly_5_error_guardar = true;
        option_monthly_5_payment_method.style.borderColor = "red";
        option_monthly_5_error_payment_method.style.display = "block";
        return;
    }
    else{
        option_monthly_5_error_guardar = false;
        option_monthly_5_payment_method.style.borderColor = "#cfcfcf";
        option_monthly_5_error_payment_method.style.display = "none";
    }

    if (option_monthly_5_payment_method.value === "Cuenta de banco"){
        option_monthly_5_form4.style.display = 'none';
        paso_text1_opm1.style.display = 'none';
        option_monthly_5_form2.style.display = 'block';
        paso_text2_opm1.style.display = 'block';
        
    }
    else if(option_monthly_5_payment_method.value === "PSE"){

        if (option_monthly_5_nombreBanco_1.value === "0"){
            option_monthly_5_nombreBanco_1.style.borderColor = "red";
            option_monthly_5_error_nombreBanco_1.style.display = "block";
            return;
        }
        else{
            option_monthly_5_nombreBanco_1.style.borderColor = "#cfcfcf";
            option_monthly_5_error_nombreBanco_1.style.display = "none";
        }

        if(!option_monthly_5_tyc_form.checked){
            option_monthly_5_tyc_form.style.borderColor = "red";
            option_monthly_5_error_option_monthly_5_tyc_form.style.display = "block";
            return;
        }
        else{
            option_monthly_5_tyc_form.style.borderColor = "#cfcfcf";
            option_monthly_5_error_option_monthly_5_tyc_form.style.display = "none";
            option_monthly_5_next_step_1.style.display = "none";
            option_monthly_5_payu_2_form.style.display = "block";
            var option_monthly_5_cookieExistente;
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_monthly_payu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_monthly_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_monthly_payu_pse=" + encodeURIComponent(option_monthly_5_monthly_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_amount_payu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_amount_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_amount_payu_pse=" + encodeURIComponent(option_monthly_5_amount_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_tipoIdentificacionPayu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_tipoIdentificacionPayu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_tipoIdentificacionPayu_pse=" + encodeURIComponent(option_monthly_5_tipoIdentificacionPayu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_numeroIdentificacionPayu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_numeroIdentificacionPayu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_numeroIdentificacionPayu_pse=" + encodeURIComponent(option_monthly_5_numeroIdentificacionPayu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_gift_email_payu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_gift_email_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_gift_email_payu_pse=" + encodeURIComponent(option_monthly_5_gift_email_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_gift_name_payu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_gift_name_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_gift_name_payu_pse=" + encodeURIComponent(option_monthly_5_gift_name_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_gift_message_payu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_gift_message_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_gift_message_payu_pse=" + encodeURIComponent(option_monthly_5_gift_message_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_is_gift_payu_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_is_gift_payu_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_is_gift_payu_pse=" + encodeURIComponent(option_monthly_5_is_gift_payu_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            // Verificar si la cookie existe
            option_monthly_5_cookieExistente = getCookie("option_monthly_5_payerPhone_pse");

            // Eliminar la cookie existente si hay una
            if (option_monthly_5_cookieExistente) {
                document.cookie = "option_monthly_5_payerPhone_pse=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/";
            }

            // Crear la nueva cookie
            document.cookie = "option_monthly_5_payerPhone_pse=" + encodeURIComponent(option_monthly_5_payerPhone_pse.value) + "; expires=" + new Date(new Date().getTime() + 3600 * 1000).toUTCString() + "; path=/";
            //-------------------------------------------------------------
            
            option_monthly_5_payu_pse.click();
        }

    }
    else{
        option_monthly_5_values_container.style.display = 'none';
        option_monthly_5_form4.style.display = 'none';
        paso_text1_opm1.style.display = 'none';
        option_monthly_5_form3.style.display = 'block';
        paso_text2_opm1.style.display = 'block';
    }

});
//-------------------------------------------------------------------------------
option_monthly_5_giftEmail.addEventListener("input", function() {
    option_monthly_5_gift_email_bank.value = option_monthly_5_giftEmail.value;
    option_monthly_5_gift_email_payu.value = option_monthly_5_giftEmail.value;
    option_monthly_5_gift_email_payu_pse.value = option_monthly_5_giftEmail.value;
    option_monthly_5_giftEmail.style.borderColor = "#cfcfcf";
    option_monthly_5_error_email_gift_1.style.display = "none";
    option_monthly_5_error_email_gift_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_whoName.addEventListener("input", function() {
    option_monthly_5_gift_name_bank.value = option_monthly_5_whoName.value;
    option_monthly_5_gift_name_payu.value = option_monthly_5_whoName.value;
    option_monthly_5_gift_name_payu_pse.value = option_monthly_5_whoName.value;
    option_monthly_5_whoName.style.borderColor = "#cfcfcf";
    option_monthly_5_error_whoName_gift.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_message.addEventListener("input", function() {
    option_monthly_5_gift_message_bank.value = option_monthly_5_message.value;
    option_monthly_5_gift_message_payu.value = option_monthly_5_message.value;
    option_monthly_5_gift_message_payu_pse.value = option_monthly_5_message.value;
    option_monthly_5_message.style.borderColor = "#cfcfcf";
    option_monthly_5_error_message_gift.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_nombre_1.addEventListener("input", function() {
    option_monthly_5_name_form.value = option_monthly_5_nombre_1.value;
    option_monthly_5_nameInputPayu.value = option_monthly_5_nombre_1.value;
    option_monthly_5_payerFullName_pse.value = option_monthly_5_nombre_1.value;
    option_monthly_5_nombre_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_nombre_1.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_apellido_1.addEventListener("input", function() {
    option_monthly_5_apellido.value = option_monthly_5_apellido_1.value;
    option_monthly_5_lastNameInputPayu.value = option_monthly_5_apellido_1.value;
    option_monthly_5_payerLastName_pse.value  = option_monthly_5_apellido_1.value;
    option_monthly_5_apellido_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_nombre_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_tipoIdentificacion_1.addEventListener('change', () => {
    option_monthly_5_tipoIdentificacion.value = option_monthly_5_tipoIdentificacion_1.value;
    option_monthly_5_tipoIdentificacionPayu.value = option_monthly_5_tipoIdentificacion_1.value;
    option_monthly_5_tipoIdentificacionPayu_pse.value = option_monthly_5_tipoIdentificacion_1.value;
    option_monthly_5_tipoIdentificacion_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_id_type_bank.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_person_type.addEventListener('change', () => {
    option_monthly_5_person_type_pse.value = option_monthly_5_person_type.value;
    option_monthly_5_person_type.style.borderColor = "#cfcfcf";
    option_monthly_5_error_person_type.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_nombreBanco_1.addEventListener('change', () => {
    option_monthly_5_nombreBanco_pse.value = option_monthly_5_nombreBanco_1.value;
    option_monthly_5_nombreBanco_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_person_type.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_numeroIdentificacion_1.addEventListener("input", function() {
    option_monthly_5_numeroIdentificacion.value = option_monthly_5_numeroIdentificacion_1.value;
    option_monthly_5_numeroIdentificacionPayu.value = option_monthly_5_numeroIdentificacion_1.value;
    option_monthly_5_numeroIdentificacionPayu_pse.value = option_monthly_5_numeroIdentificacion_1.value;
    option_monthly_5_numeroIdentificacion_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_numeroIdentificacion_1.style.display = "none";
    option_monthly_5_error_numeroIdentificacion_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_numeroTelefono_1.addEventListener("input", function() {
    option_monthly_5_phone_form.value = option_monthly_5_numeroTelefono_1.value;
    option_monthly_5_phoneInputPayu.value = option_monthly_5_numeroTelefono_1.value;
    option_monthly_5_payerPhone_pse.value = option_monthly_5_numeroTelefono_1.value;
    option_monthly_5_numeroTelefono_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_numeroTelefono_1.style.display = "none";
    option_monthly_5_error_numeroTelefono_2.style.display = "none";
    option_monthly_5_error_numeroTelefono_3.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_correoElectronico_1.addEventListener("input", function() {
    option_monthly_5_email_form.value = option_monthly_5_correoElectronico_1.value;
    option_monthly_5_emailInputPayu.value = option_monthly_5_correoElectronico_1.value;
    option_monthly_5_email_pse.value = option_monthly_5_correoElectronico_1.value;
    option_monthly_5_correoElectronico_1.style.borderColor = "#cfcfcf";
    option_monthly_5_error_correoElectronico_1.style.display = "none";
    option_monthly_5_error_correoElectronico_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_card_number.addEventListener("input", function() {
    option_monthly_5_card_number.style.borderColor = "#cfcfcf";
    option_monthly_5_error_card_number_1.style.display = "none";
    option_monthly_5_error_card_number_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_cvv_card.addEventListener("input", function() {
    option_monthly_5_cvv_card.style.borderColor = "#cfcfcf";
    option_monthly_5_error_cvv_card_1.style.display = "none";
    option_monthly_5_error_cvv_card_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_expiration_month.addEventListener("input", function() {
    option_monthly_5_expiration_month.style.borderColor = "#cfcfcf";
    option_monthly_5_error_expiration_month_1.style.display = "none";
    option_monthly_5_error_expiration_month_2.style.display = "none";
    option_monthly_5_error_expiration_month_3.style.display = "none";
    option_monthly_5_error_expiration_month_4.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_expiration_year.addEventListener("input", function() {
    option_monthly_5_expiration_year.style.borderColor = "#cfcfcf";
    option_monthly_5_error_expiration_year_1.style.display = "none";
    option_monthly_5_error_expiration_year_2.style.display = "none";
    option_monthly_5_error_expiration_year_3.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_tipoCuenta.addEventListener("input", function() {
    option_monthly_5_tipoCuenta.style.borderColor = "#cfcfcf";
    option_monthly_5_error_account_type.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_numeroCuenta.addEventListener("input", function() {
    option_monthly_5_numeroCuenta.style.borderColor = "#cfcfcf";
    option_monthly_5_error_numeroCuenta_1.style.display = "none";
    option_monthly_5_error_numeroCuenta_2.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_nombreBanco.addEventListener("input", function() {
    option_monthly_5_nombreBanco.style.borderColor = "#cfcfcf";
    option_monthly_5_error_bank_name.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_tyc_bank.addEventListener("change", function() {
    option_monthly_5_tyc_bank.style.borderColor = "#cfcfcf";
    option_monthly_5_error_checkbox_TyC_1.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_tyc.addEventListener("change", function() {
    option_monthly_5_tyc.style.borderColor = "#cfcfcf";
    option_monthly_5_error_option_monthly_5_tyc.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_tyc_form.addEventListener("change", function() {
    option_monthly_5_tyc_form.style.borderColor = "#cfcfcf";
    option_monthly_5_error_option_monthly_5_tyc_form.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_montoInput.addEventListener("change", function() {
    option_monthly_5_montoInput.style.borderColor = "#FCBB29";
    option_monthly_5_error_monto_3.style.display = "none";
    option_monthly_5_error_monto_4.style.display = "none";
});
//-------------------------------------------------------------------------------
option_monthly_5_payment_method_type_card.addEventListener("change", function() {
    
    option_monthly_5_payment_method_type_card.style.borderColor = "#cfcfcf";
    option_monthly_5_payment_method_type_card_error.style.display = "none";

    if(option_monthly_5_payment_method_type_card.value == "credito"){
        option_monthly_5_payment_method_brand_card.innerHTML = '';

        var defaultOption = document.createElement('option');
        defaultOption.value = "";
        defaultOption.text = "Seleccione tarjeta";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        option_monthly_5_payment_method_brand_card.appendChild(defaultOption);

        var options_payment = [
            {text: 'Tarjeta Crédito Mastercard', value: 'MASTERCARD'},
            {text: 'Tarjeta Crédito VISA', value: 'VISA'},
            {text: 'Tarjeta Crédito American Express', value: 'AMEX'},
            {text: 'Tarjeta Crédito Diners', value: 'DINERS'},
            {text: 'Tarjeta Crédito Argencard', value: 'ARGENCARD'},
            {text: 'BTarjeta Crédito CABAL', value: 'CABAL'},
            {text: 'Tarjeta Crédito Cencosud', value: 'CENCOSUD'},
            {text: 'Tarjeta Crédito Naranja', value: 'NARANJA'},
            {text: 'Tarjeta Crédito Shopping', value: 'SHOPPING'},
        ];

        for (var i = 0; i < options_payment.length; i++) {
            var option = document.createElement('option');
            option.value = options_payment[i].value;
            option.text = options_payment[i].text;
            option_monthly_5_payment_method_brand_card.appendChild(option);
        }
    }
    else{
        option_monthly_5_payment_method_brand_card.innerHTML = '';

        var defaultOption = document.createElement('option');
        defaultOption.value = "";
        defaultOption.text = "Seleccione tarjeta";
        defaultOption.disabled = true;
        defaultOption.selected = true;
        option_monthly_5_payment_method_brand_card.appendChild(defaultOption);

        var options_payment = [
            {text: 'Tarjeta Débito VISA', value: 'VISA_DEBIT'},
            {text: 'Tarjeta Débito Mastercard', value: 'MASTERCARD_DEBIT'}
        ];

        for (var i = 0; i < options_payment.length; i++) {
            var option = document.createElement('option');
            option.value = options_payment[i].value;
            option.text = options_payment[i].text;
            option_monthly_5_payment_method_brand_card.appendChild(option);
        }
    }
});
//-------------------------------------------------------------------------------
option_monthly_5_payment_method_brand_card.addEventListener("change", function() {
    option_monthly_5_payment_method_brand_card.style.borderColor = "#cfcfcf";
    option_monthly_5_payment_method_brand_card_error.style.display = "none";
    option_monthly_5_payment_method_1.value = option_monthly_5_payment_method_brand_card.value;
});
//-------------------------------------------------------------------------------
function getCookie(nombre) {
    var option_monthly_5_nombreEQ = nombre + "=";
    var option_monthly_5_cookies = document.cookie.split(';');
    for(var i = 0; i < option_monthly_5_cookies.length; i++) {
        var option_monthly_5_cookie = option_monthly_5_cookies[i];
        while (option_monthly_5_cookie.charAt(0) == ' ') option_monthly_5_cookie = option_monthly_5_cookie.substring(1, option_monthly_5_cookie.length);
        if (option_monthly_5_cookie.indexOf(option_monthly_5_nombreEQ) == 0) return option_monthly_5_cookie.substring(option_monthly_5_nombreEQ.length, option_monthly_5_cookie.length);
    }
    return null;
}

var option_monthly_5_mensual = document.querySelector('div#mensual .arrow')
var option_monthly_5_unica = document.querySelector('div#unica .arrow')

function activarArrow(option_monthly_5_btnId){
    let option_monthly_5_btn = document.getElementById(option_monthly_5_btnId)
        if(btn === "button1"){
            option_monthly_5_mensual.classList.remove('activeArrow');
            option_monthly_5_unica.classList.add('activeArrow');
        }else{
            option_monthly_5_unica.classList.remove('activeArrow');
            option_monthly_5_mensual.classList.add('activeArrow');
        }
}


</script>
