<div id="pasosContainer_option1" style="display: none;">
    <div class="container-steps">
        <div class="botones">
            <a role="button" id="option_1_atras" class="btn-atras">
                <i aria-hidden="true" class="fas fa-chevron-left"></i>
            </a>
        </div>
        <div class="text-pasos">
            <h3 id="paso-text1_op1" style="display: none;">Completa tu información personal</h3>
            <h3 id="paso-text2_op1" style="display: none;">Llena los datos de tu tarjeta para contribuir a esta causa importante</h3>
        </div>
    </div>
</div>

<div id="option_1_values_container">
    <!-- ------------ -->
    <div class="buttonContainer tabs">
        <div class="content-tab ">
            <span class="arrow" id="unica"></span>
            <button id="button1" class="option_1_myButton_1">Única vez</button>
        </div>
        <div class="content-tab">
            <span class="arrow" id="mensual"></span>
            <button id="button2" class="option_1_myButton_1 active">Mensual 🤍</button>
        </div>
    </div>
    <div class="divisor"></div>
    <div class="buttonContainer">
        <button id="option_1_button1" class="option_1_myButton"><?php echo $option_1_values[1]; ?></button>
        <div class="fav">
            <span>Donación favorita</span>
            <button id="option_1_button2" class="option_1_myButton active"><?php echo $option_1_values[2]; ?></button>
        </div>
        <button id="option_1_button3" class="option_1_myButton"><?php echo $option_1_values[3]; ?></button>
    </div>
    <div>
        <input placeholder="Ingrese un valor" type="text" id="option_1_monto" name="option_1_monto" inputmode="numeric" pattern="[0-9]*">
        <p id="option_1_error_monto_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un monto</p>
        <p id="option_1_error_monto_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Ingrese un valor" solo acepta números</p>
        <p id="option_1_error_monto_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El monto a donar debe ser mayor a 40.000 COP </p>
        <p id="option_1_error_monto_4" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El monto a donar debe ser mayor a 85.000 COP </p>
    </div>
    <!-- ------------ -->

    <div id="option_1_data_user" class="formContainer">
        <input id="option_1_monto_form_1" name="option_1_monto_form" id="option_1_monto_form" type="hidden" value='<?php echo $option_1_values[2]; ?>'>

        <!-- ------------ -->
        <div class="divisor"></div>
        <div id="video-form">
            <video controls muted poster="https://donacion.wwf.org.co/wp-content/uploads/2024/01/cover-video.png">
                <source src="https://donacion.wwf.org.co/videos/video.mp4" type="video/mp4">
                Tu navegador no soporta el elemento de video.
            </video>
        </div>
        <div class="checkbox-container">
            <svg width="21" height="24" viewBox="0 0 21 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7.32906 6.34211H13.6712C15.4197 6.34211 16.8422 4.91954 16.8422 3.17105C16.6828 -1.03026 10.6587 -1.02862 10.5001 3.17105C10.5001 1.4225 9.07754 0 7.32906 0C3.12781 0.159408 3.12939 6.18349 7.32906 6.34211Z" fill="#FF73AE" />
                <path d="M2.04373 23.114H18.956C19.501 23.114 19.9428 22.6722 19.9428 22.1272V14.5176H1.05688V22.1272C1.05688 22.6722 1.49873 23.114 2.04373 23.114Z" fill="#FF73AE" />
                <path d="M21 11.5572V9.30276C21 8.75776 20.5582 8.31592 20.0132 8.31592H0.986842C0.441842 8.31592 0 8.75776 0 9.30276V11.5572C0 12.1022 0.441842 12.544 0.986842 12.544H20.0132C20.5582 12.544 21 12.1022 21 11.5572Z" fill="#FF73AE" />
            </svg>
            <div style="padding-bottom: 4px;">
                <input type="checkbox" id="option_1_giftCheck" style="min-height: 0px;">
            </div>
            <label for="giftCheck">para un regalo</label>
        </div>
        <div id="option_1_gift_container" style="display: none;">
            <input placeholder="Correo de dedicatoria" id="option_1_giftEmail" name="option_1_giftEmail" type="text" value="">
            <p id="option_1_error_email_gift_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_1_error_email_gift_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
            <input placeholder="¿A quién va la dedicatoria?" id="option_1_whoName" name="option_1_whoName" type="text" value="">
            <p id="option_1_error_whoName_gift" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un nombre para la dedicatoria</p>
            <textarea id="option_1_message" name="option_1_message" rows="4" cols="50" placeholder="Escribe dedicatoria" style="border-radius: 15px;"></textarea>
            <p id="option_1_error_message_gift" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un mensaje</p>
        </div>
    </div>
    <!-- ------------ -->
    <div class="formButtonContainer">
        <button id="option_1_next_step" class="formButton payuButton">¡Donar! 🤍</button>
    </div>
</div>
<!-- Por Pay U -->
<div id="option_1_form3" class="formContainer" style="display: none;">
    <!-- ------------ -->
    <!-- inicio form de Payu NO MODIFICAR -->
    <form id="option_1_form_payu" method="post" action="">
        <input id="option_1_monthly_payu" name="option_1_monthly_payu" type="hidden" value="1">
        <input id="option_1_gift_email_payu" name="option_1_gift_email_payu" type="hidden" value="">
        <input id="option_1_gift_name_payu" name="option_1_gift_name_payu" type="hidden" value="">
        <input id="option_1_gift_message_payu" name="option_1_gift_message_payu" type="hidden" value="">
        <input id="option_1_is_gift_payu" name="option_1_is_gift_payu" type="hidden" value="0">

        <input id="option_1_description" name="option_1_description" type="hidden" value="">
        <input id="option_1_referenceCode" name="option_1_referenceCode" type="hidden" value="<?php echo $option_1_reference; ?>">
        <input id="option_1_amount_payu" name="option_1_amount" type="hidden" value="<?php echo $option_1_values[2]; ?>">
        <input name="option_1_tax" type="hidden" value="0">
        <input id="option_1_taxReturnBase" name="option_1_taxReturnBase" type="hidden" value="0">
        <input id="option_1_currency" name="option_1_currency" type="hidden" value="COP">
        <input id="option_1_signature" name="option_1_signature" type="hidden" value="">
        <input name="option_1_algorithmSignature" type="hidden" value="SHA256">

        <!-- Codigo nuevo de nombre y apellido -->
        <div style="display: none;">
            <div style="width: 100%;">
                <input placeholder="Nombre" id="option_1_payerFullName" name="option_1_payerFullName" type="text" value="">
                <p id="option_1_error_payerFullName_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe ingresar un nombre</p>
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_1_payerLastName" name="option_1_payerLastName" type="text" value="">
                <p id="option_1_error_payerFullName_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe ingresar un apellido</p>
            </div>
        </div>

        <!-- ------------ -->
        <select id="option_1_tipoIdentificacionPayu" name="option_1_tipoIdentificacionPayu" placeholder="Tipo de documento" style="display: none;">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="Cédula de ciudadanía">Cédula de ciudadanía</option>
            <option value="Cédula de extranjería">Cédula de extranjería</option>
            <option value="Pasaporte">Pasaporte</option>
            <option value="Nit">NIT</option>
        </select>
        <p id="option_1_error_id_type_payu" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de documento</p>
        <input placeholder="Número de identificación" type="text" id="option_1_numeroIdentificacionPayu" name="option_1_numeroIdentificacionPayu" style="display: none;">
        <div>
            <p id="option_1_error_numeroIdentificacionPayu_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de identificación</p>
            <p id="option_1_error_numeroIdentificacionPayu_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de identificación" solo puede contener números</p>
        </div>
        <input placeholder="Número de teléfono" id="option_1_payerPhone" name="option_1_payerPhone" type="text" value="" style="display: none;">
        <div>
            <p id="option_1_error_payerPhone_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de teléfono</p>
            <p id="option_1_error_payerPhone_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de teléfono ingresado no es válido</p>
        </div>
        <input placeholder="Correo electrónico" id="option_1_email" name="option_1_buyerEmail" type="text" value="" style="display: none;">
        <div>
            <p id="option_1_error_email_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_1_error_email_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
        </div>
        <input id="option_1_responseUrl" name="option_1_responseUrl" type="hidden" value="">
        <input id="option_1_confirmationUrl" name="option_1_confirmationUrl" type="hidden" value="">
        <input id="option_1_payment_method_1" name="option_1_payment_method_1" type="hidden" value="MASTERCARD">
        <input placeholder="Número de la tarjeta" type="text" id="option_1_card_number" name="option_1_card_number">
        <div>
            <p id="option_1_error_card_number_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de tarjeta</p>
            <p id="option_1_error_card_number_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de tarjeta ingresado no es válido</p>
        </div>

        <!------ Codigo de datos de tarjeta -->

        <div class="contForm-tarjerta">
            <input placeholder="CVV" type="password" id="option_1_cvv_card" name="option_1_cvv_card" inputmode="numeric" pattern="[0-9]*">
            <input placeholder="Mes" type="text" id="option_1_expiration_month" name="option_1_expiration_month">
            <input placeholder="Año" type="text" id="option_1_expiration_year" name="option_1_expiration_year">
        </div>
        <div>
            <p id="option_1_error_cvv_card_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un CVV</p>
            <p id="option_1_error_cvv_card_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">CVV no es válido</p>

            <p id="option_1_error_expiration_month_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un mes de expiración</p>
            <p id="option_1_error_expiration_month_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración solo puede contener números</p>
            <p id="option_1_error_expiration_month_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración debe contener 2 dígitos, ejemplo: 02</p>
            <p id="option_1_error_expiration_month_4" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Mes de expiración debe debe estar entre 01 y 12</p>

            <p id="option_1_error_expiration_year_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un año de expiración</p>
            <p id="option_1_error_expiration_year_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Año de expiración solo puede contener números</p>
            <p id="option_1_error_expiration_year_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Año de expiración debe contener 4 dígitos, ejemplo: 2030</p>

            <p id="option_1_error_expired_card" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Tarjeta vencida</p>

        </div>
        <!-- ------------ -->
        <button id="option_1_payu" name="option_1_payu" style="display: none;"></button>
    </form>
    <!-- fin form de Payu NO MODIFICAR -->

    <!-- Codigo aGregado -->
    <div class="checkbox-T&C">
        <div style="padding-bottom: 4px;">
            <input type="checkbox" id="option_1_t&c" style="min-height: 0px;" requerid>
        </div>
        <label class="politicas" for="option_1_t&c">Acepto <a href="https://donacion.wwf.org.co/politicas-de-privacidad/" target="_blank">políticas de privacidad</a></label>
    </div>

    <div>
        <p id="option_1_error_option_1_t&c" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes aceptar las políticas de privacidad</p>
    </div>

    <h5 class="info" id="option_1_info_payu">Estas donando mensualmente: <span id="option_1_valorDonacion"><?php echo $option_1_values[2]; ?></span></h5>

    <button id="option_1_payu_1" name="option_1_payu_1"  class="saveButton">¡Donar! 🤍</button>
    <div style="display: flex; justify-content: center; align-items: center; height: 100%;">
        <img id="option_1_payu_2" src="https://donacion.wwf.org.co/wp-content/uploads/2024/01/loading.gif" alt="loading" style='display: none; width: 30px;'>
    </div>
</div>

<!-- ------informacion del usuario------ -->
<div id="option_1_form4" class="formContainer" style="display: none; ">
    <form id="option_1_form_user_data" method="post" action="">
        <div class="contForm-nombre">
            <div style="width: 100%;">
                <input id="option_1_nombre_1" placeholder="Nombre" name="option_1_nombre_1" type="text" value="">
                <p id="option_1_error_nombre_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un nombre</p>
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_1_apellido_1" name="option_1_apellido_1" type="text" value="">
                <p id="option_1_error_nombre_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un apellido</p>
            </div>
        </div>

        <select id="option_1_tipoIdentificacion_1" name="option_1_tipoIdentificacion_1">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="Cédula de ciudadanía">Cédula de ciudadanía</option>
            <option value="Cédula de extranjería">Cédula de extranjería</option>
            <option value="Pasaporte">Pasaporte</option>
            <option value="Nit">NIT</option>
        </select>
        <p id="option_1_error_id_type_bank" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de identificación</p>
        <input placeholder="Número de identificación" type="text" id="option_1_numeroIdentificacion_1" name="option_1_numeroIdentificacion_1">

        <div>
            <p id="option_1_error_numeroIdentificacion_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un número de identificacion</p>
            <p id="option_1_error_numeroIdentificacion_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de identificación" solo puede contener números</p>
        </div>

        <input placeholder="Número de teléfono" type="text" id="option_1_numeroTelefono_1" name="option_1_numeroTelefono_1" inputmode="numeric" pattern="[0-9]*">
        <div>
            <p id="option_1_error_numeroTelefono_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un número de teléfono</p>
            <p id="option_1_error_numeroTelefono_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de teléfono" solo puede contener números</p>
            <p id="option_1_error_numeroTelefono_3" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El número de teléfono ingresado no es válido</p>
        </div>

        <input placeholder="Correo electrónico" type="text" id="option_1_correoElectronico_1" name="option_1_correoElectronico_1">

        <div>
            <p id="option_1_error_correoElectronico_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes ingresar un correo electrónico</p>
            <p id="option_1_error_correoElectronico_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El correo electrónico no es válido</p>
        </div>

        <select id="option_1_payment_method" name="option_1_payment_method">
            <option value="" disabled selected>Seleccione el método de pago</option>
            <option value="MASTERCARD">Tarjeta Crédito Mastercard</option>
            <option value="VISA">Tarjeta Crédito VISA</option>
            <option value="VISA_DEBIT">Tarjeta Débito VISA</option>
            <option value="AMEX">Tarjeta Crédito American Express</option>
            <option value="DINERS">Tarjeta Crédito Diners</option>
            <option value="ARGENCARD">Tarjeta Crédito Argencard</option>
            <option value="CABAL">Tarjeta Crédito CABAL</option>
            <option value="CENCOSUD">Tarjeta Crédito Cencosud</option>
            <option value="NARANJA">Tarjeta Crédito Naranja</option>
            <option value="SHOPPING">Tarjeta Crédito Shopping</option>
            <option value="Cuenta de banco">Cuenta Bancaria</option>
        </select>
        <p id="option_1_error_payment_method" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar un método de pago</p>
        
        <button id="option_1_next_step_1" type="submit" name="option_1_next_step_1" class="saveButton">¡Donar! 🤍</button>
    </form>


</div>
<!-- ------script evita la recarga luego de enviar el form------ -->
<script>
    document.getElementById('option_1_form_user_data').addEventListener('submit', function(e) {
        e.preventDefault();
    });
</script>

<!-- informacion del banco -->
<div id="option_1_form2" class="formContainer" style="display: none; ">
    <form id="option_1_form_bank" method="post" action="">
        <input id="option_1_monthly_bank" name="option_1_monthly_bank" type="hidden" value="1">
        <input id="option_1_gift_email_bank" name="option_1_gift_email_bank" type="hidden" value="">
        <input id="option_1_gift_name_bank" name="option_1_gift_name_bank" type="hidden" value="">
        <input id="option_1_gift_message_bank" name="option_1_gift_message_bank" type="hidden" value="">
        <input id="option_1_is_gift_bank" name="option_1_is_gift_bank" type="hidden" value="0">

        <input id="option_1_monto_form" name="option_1_monto_form" type="hidden" style="border-radius: 30px;" value='<?php echo $option_1_values[2]; ?>'>
        <!-- Codigo nuevo de nombre y apellido -->
        <div style="display: none;">
            <div style="width: 100%;">
                <input id="option_1_nombre" placeholder="Nombre" name="option_1_nombre" type="text" value="">
            </div>
            <div style="width: 100%;">
                <input placeholder="Apellido" id="option_1_apellido" name="option_1_apellido" type="text" value="">
            </div>
        </div>

        <!-- ------------ -->
        <select id="option_1_tipoCuenta" name="option_1_tipoCuenta">
            <option value="" disabled selected>Tipo de Cuenta</option>
            <option value="Ahorros">Ahorros</option>
            <option value="Corriente">Corriente</option>
        </select>
        <p id="option_1_error_account_type" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el tipo de cuenta</p>
        <input placeholder="Número de cuenta" type="text" id="option_1_numeroCuenta" name="option_1_numeroCuenta" inputmode="numeric" pattern="[0-9]*">
        <div>
            <p id="option_1_error_numeroCuenta_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debe indicar un número de cuenta</p>
            <p id="option_1_error_numeroCuenta_2" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">El campo "Número de cuenta" solo puede contener números</p>
        </div>

        <select id="option_1_nombreBanco" name="option_1_nombreBanco">
            <option value="" disabled selected>Seleccione el banco</option>
            <option value="BANCO DE BOGOTÁ">BANCO DE BOGOTÁ</option>
            <option value="BANCO POPULAR">BANCO POPULAR</option>
            <option value="BANCO ITAÚ CORPBANCA COLOMBIA S.A.">BANCO ITAÚ CORPBANCA COLOMBIA S.A.</option>
            <option value="BANCOLOMBIA S.A.">BANCOLOMBIA S.A.</option>
            <option value="BANCO GNB SUDAMERIS S.A.">BANCO GNB SUDAMERIS S.A.</option>
            <option value="BBVA COLOMBIA">BBVA COLOMBIA</option>
            <option value="(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.">(HELM) BANCO ITAÚ CORPBANCA COLOMBIA S.A.</option>
            <option value="BANCO COLPATRIA">BANCO COLPATRIA</option>
            <option value="BANCO DE OCCIDENTE">BANCO DE OCCIDENTE</option>
            <option value="BANCOLDEX">BANCOLDEX</option>
            <option value="BANCO CAJA SOCIAL - BCSC S.A.">BANCO CAJA SOCIAL - BCSC S.A.</option>
            <option value="BANCO AGRARIO DE COLOMBIA S.A.">BANCO AGRARIO DE COLOMBIA S.A.</option>
            <option value="BANCO DAVIVIENDA S.A.">BANCO DAVIVIENDA S.A.</option>
            <option value="BANCO AV VILLAS">BANCO AV VILLAS</option>
            <option value="BANCOOMEVA">BANCOOMEVA</option>
            <option value="BANCO FALABELLA S.A.">BANCO FALABELLA S.A.</option>
            <option value="BANCO MUNDO MUJER">BANCO MUNDO MUJER</option>
            <option value="BANCO MULTIBANK">BANCO MULTIBANK</option>
            <option value="BANCO SANTANDER NEGOCIOS COLOMBIA">BANCO SANTANDER NEGOCIOS COLOMBIA</option>
            <option value="BANCO COOPERATIVO COOPENTRAL">BANCO COOPERATIVO COOPENTRAL</option>
            <option value="BANCO COMPARTIR SA">BANCO COMPARTIR SA</option>
            <option value="BANCO SERFINANZA SA">BANCO SERFINANZA SA</option>
            <option value="FINANCIERA JURISCOOP">FINANCIERA JURISCOOP</option>
            <option value="COOPERATIVA FINANCIERA ANTIOQUIA">COOPERATIVA FINANCIERA ANTIOQUIA</option>
            <option value="CONTRAFA">CONTRAFA</option>
            <option value="BANCO CONFIAR">BANCO CONFIAR</option>
            <option value="COLTEFINANCIERA">COLTEFINANCIERA</option>
            <option value="Deceval S.A">Deceval S.A</option>
            <option value="DTN">DTN</option>
            <option value="DGCPTN SISTEMA GENERAL DE REGALIAS">DGCPTN SISTEMA GENERAL DE REGALIAS</option>
        </select>
        <p id="option_1_error_bank_name" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes seleccionar el método de pago</p>
        <input type="hidden" placeholder="CVV (Opcional)" id="option_1_cvv" name="option_1_cvv" inputmode="numeric" pattern="[0-9]*">

        <select id="option_1_tipoIdentificacion" name="option_1_tipoIdentificacion" style="display: none;">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="Cédula de ciudadanía">Cédula de ciudadanía</option>
            <option value="Cédula de extranjería">Cédula de extranjería</option>
            <option value="Pasaporte">Pasaporte</option>
            <option value="Nit">NIT</option>
        </select>
        <input placeholder="Número de identificación" type="text" id="option_1_numeroIdentificacion" name="option_1_numeroIdentificacion" style="display: none;">

        <input placeholder="Número de teléfono" type="text" id="option_1_numeroTelefono" name="option_1_numeroTelefono" inputmode="numeric" pattern="[0-9]*" style="display: none;">

        <input placeholder="Correo electrónico" type="text" id="option_1_correoElectronico" name="option_1_correoElectronico" style="display: none;">

        <input type="hidden" id="option_1_description_bank" name="option_1_description_bank">

        <button id="option_1_guardar" name="option_1_guardar" style="display: none;"></button>
    </form>
    <!-- Codigo aGregado -->
    <div class="checkbox-T&C">
        <div style="padding-bottom: 4px;">
            <input type="checkbox" id="option_1_t&c_bank" style="min-height: 0px;" requerid>
        </div>
        <label class="politicas" for="option_1_t&c">Acepto <a href="https://donacion.wwf.org.co/politicas-de-privacidad/" target="_blank">políticas de privacidad</a></label>
    </div>
    <div>
        <p id="option_1_error_checkbox-T&C_1" style="font-weight: bold; font-size: 15px; color: red; text-align: center; display: none;">Debes aceptar las políticas de privacidad</p>
    </div>
    <h5 class="info" id="option_1_info_bank">Estas donando mensualmente: <span id="option_1_valorDonacion_bank"><?php echo $option_1_values[2]; ?></span></h5>
    <!-- ------------ -->
    <button id="option_1_guardar_1" name="option_1_guardar" class="saveButton">¡Donar! 🤍</button>
    <div style="display: flex; justify-content: center; align-items: center; height: 100%;">
        <img id="option_1_guardar_2" src="https://donacion.wwf.org.co/wp-content/uploads/2024/01/loading.gif" alt="loading" style='display: none; width: 30px;'>
    </div>
</div>