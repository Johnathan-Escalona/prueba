<?php
global $wpdb;

// Crea la tabla "values"
$table_name_values = $wpdb->prefix . 'values';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_values'") != $table_name_values) {
    $sql = "CREATE TABLE $table_name_values (
        id INT(11) NOT NULL AUTO_INCREMENT,
        value INT(11) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Inserta las filas 1, 2, 3
    $wpdb->insert($table_name_values, array('id' => 1, 'value' => 0));
    $wpdb->insert($table_name_values, array('id' => 2, 'value' => 0));
    $wpdb->insert($table_name_values, array('id' => 3, 'value' => 0));
    $wpdb->insert($table_name_values, array('id' => 4, 'value' => 0));
    $wpdb->insert($table_name_values, array('id' => 5, 'value' => 0));
    $wpdb->insert($table_name_values, array('id' => 6, 'value' => 0));
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "bank_accounts"
$table_name_bank_accounts = $wpdb->prefix . 'bank_accounts';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_bank_accounts'") != $table_name_bank_accounts) {
    $sql = "CREATE TABLE $table_name_bank_accounts (
        id INT(11) NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        account_type VARCHAR(255) NOT NULL,
        account_number VARCHAR(255) NOT NULL,
        bank_name VARCHAR(255) NOT NULL,
        id_type VARCHAR(255) NOT NULL,
        id_number VARCHAR(255) NOT NULL,
        phone_number VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        amount VARCHAR(255) NOT NULL,
        payment_description VARCHAR(255) NOT NULL,
        date_in DATE NOT NULL,
        monthly VARCHAR(255) NOT NULL,
        payment_made TINYINT(1) NOT NULL DEFAULT 0,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "payu_settings"
$table_name_payu_settings = $wpdb->prefix . 'payu_settings';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_payu_settings'") != $table_name_payu_settings) {
    $sql = "CREATE TABLE $table_name_payu_settings (
        id INT(11) NOT NULL AUTO_INCREMENT,
        merchantId VARCHAR(50) NOT NULL,
        accountId VARCHAR(50) NOT NULL,
        apiKey VARCHAR(255) NOT NULL,
        apiLogin VARCHAR(255) NOT NULL,
        testMode BOOLEAN,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $wpdb->insert($table_name_payu_settings, array('id' => 1, 'merchantId' => "", 'accountId' => "", 'apiKey' => "", 'testMode' => false));
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "urls"
$table_name_payu_settings = $wpdb->prefix . 'urls';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_payu_settings'") != $table_name_payu_settings) {
    $sql = "CREATE TABLE $table_name_payu_settings (
        id INT(11) NOT NULL AUTO_INCREMENT,
        aproved VARCHAR(255) NOT NULL,
        error VARCHAR(255) NOT NULL,
        pending VARCHAR(255) NOT NULL,
        expired VARCHAR(255) NOT NULL,
        delfin_de_rio VARCHAR(255) NOT NULL,
        elefante VARCHAR(255) NOT NULL,
        jaguar VARCHAR(255) NOT NULL,
        oso VARCHAR(255) NOT NULL,
        oso_panda VARCHAR(255) NOT NULL,
        tortuga VARCHAR(255) NOT NULL,
        apoya_la_causa_wwf VARCHAR(255) NOT NULL,
        fondo_incendios VARCHAR(255) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $wpdb->insert($table_name_payu_settings, array('id' => 1, 'aproved' => "", 'error' => "", 'pending' => "", 'expired' => ""));
}
//-----------------------------------------------------------------------------------------------
$table_name = $wpdb->prefix . 'tokensCards';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
    $sql = "CREATE TABLE $table_name (
        id INT(11) NOT NULL AUTO_INCREMENT,
        document VARCHAR(255) NOT NULL,
        token_card VARCHAR(255) NOT NULL,
        amount_to_discount VARCHAR(255) NOT NULL,
        discount_day VARCHAR(255) NOT NULL,
        payer_name VARCHAR(255) NOT NULL,
        phone_number VARCHAR(255) NOT NULL,
        payer_email VARCHAR(255) NOT NULL,
        cvv_card VARCHAR(255) NOT NULL,
        paymentMethod VARCHAR(255) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "log"
$table_name_bank_accounts_logs = $wpdb->prefix . 'bank_accounts_logs';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_bank_accounts_logs'") != $table_name_bank_accounts_logs) {
    $sql = "CREATE TABLE $table_name_bank_accounts_logs (
        id INT(11) NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        payment_method VARCHAR(255) NOT NULL,
        id_type VARCHAR(255) NOT NULL,
        id_number VARCHAR(255) NOT NULL,
        phone_number VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        amount VARCHAR(255) NOT NULL,
        payment_description VARCHAR(255) NOT NULL,
        date_in DATE NOT NULL,
        monthly VARCHAR(255) NOT NULL,
        final_result VARCHAR(255) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "values_monthly"
$table_name_values_monthly = $wpdb->prefix . 'values_monthly';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_values_monthly'") != $table_name_values_monthly) {
    $sql = "CREATE TABLE $table_name_values_monthly (
        id INT(11) NOT NULL AUTO_INCREMENT,
        value_1 INT(11) NOT NULL,
        value_2 INT(11) NOT NULL,
        value_3 INT(11) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Inserta las filas 1, 2, 3
    $wpdb->insert($table_name_values_monthly, array('id' => 1, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 2, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 3, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 4, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 5, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 6, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 7, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 8, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 9, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_monthly, array('id' => 10, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "values_unique"
$table_name_values_unique = $wpdb->prefix . 'values_unique';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_values_unique'") != $table_name_values_unique) {
    $sql = "CREATE TABLE $table_name_values_unique (
        id INT(11) NOT NULL AUTO_INCREMENT,
        value_1 INT(11) NOT NULL,
        value_2 INT(11) NOT NULL,
        value_3 INT(11) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Inserta las filas 1, 2, 3
    $wpdb->insert($table_name_values_unique, array('id' => 1, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 2, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 3, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 4, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 5, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 6, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 7, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 8, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 9, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
    $wpdb->insert($table_name_values_unique, array('id' => 10, 'value_1' => 0, 'value_2' => 0, 'value_3' => 0));
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "orders_data"
$table_name_orders_data = $wpdb->prefix . 'orders_data';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_orders_data'") != $table_name_orders_data) {
    $sql = "CREATE TABLE $table_name_orders_data (
        id INT(11) NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        who_receive VARCHAR(255),
        payment_method VARCHAR(255) NOT NULL,
        id_type VARCHAR(255) NOT NULL,
        id_number VARCHAR(255) NOT NULL,
        phone_number VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        amount VARCHAR(255) NOT NULL,
        payment_description VARCHAR(255) NOT NULL,
        date_in DATE NOT NULL,
        department VARCHAR(255) NOT NULL,
        city VARCHAR(255) NOT NULL,
        address_1 VARCHAR(255) NOT NULL,
        address_2 VARCHAR(255),
        payment_made BOOLEAN,
        order_shipped BOOLEAN,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $wpdb->query("ALTER TABLE $table_name_orders_data AUTO_INCREMENT = 2000;");
}
//-----------------------------------------------------------------------------------------------
// Crea la tabla "urls"
$table_name_urls_store = $wpdb->prefix . 'urls_store';
if($wpdb->get_var("SHOW TABLES LIKE '$table_name_urls_store'") != $table_name_urls_store) {
    $sql = "CREATE TABLE $table_name_urls_store (
        id INT(11) NOT NULL AUTO_INCREMENT,
        aproved VARCHAR(255) NOT NULL,
        error VARCHAR(255) NOT NULL,
        PRIMARY KEY  (id)
    );";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    $wpdb->insert($table_name_urls_store, array('id' => 1, 'aproved' => "", 'error' => ""));
}
//-----------------------------------------------------------------------------------------------
?>
