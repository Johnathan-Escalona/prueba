<?php
// functions.php

function enviar_correo_store($to, $slug, $name, $gift_name, $gift_message, $gift_email, $isGift, $payment_type, $payment_data) {
    $message = "";
    $strToConvert = $name . ',' . $slug;
    $codeToSend = urlencode($strToConvert);
    $linkToSend = "https://donacion.wwf.org.co/certificado/?code=".$codeToSend;
    $pathToHtmlFile = plugin_dir_path(__FILE__) . '../store_template_html/enviado.html';

    $message = file_get_contents($pathToHtmlFile);

    $donation_name = $slug;
    $message = str_replace('{{link}}', $linkToSend, $message);
    $message = str_replace('{{name_1}}', $name, $message);
    $message = str_replace('{{name}}', 'Nombre: ' . $name, $message);
    $message = str_replace('{{nombre_donacion}}', $donation_name, $message);

    $message = str_replace('{{id_producto}}', $payment_data[2], $message);
    $message = str_replace('{{monto_donacion}}', $formatoMoneda = '$' . number_format($payment_data[1], 0, ',', '.'), $message);
    $message = str_replace('{{fecha_donacion}}', 'Fecha de la donación: ' . $payment_data[3], $message);
    $message = str_replace('{{identificacion}}', $payment_data[4], $message);

    $message = str_replace('{{telefono}}', 'Teléfono: ' . $payment_data[5], $message);
    $message = str_replace('{{departamento}}', 'Departamento: ' . $payment_data[6], $message);
    $message = str_replace('{{ciudad}}', 'Ciudad: ' . $payment_data[7], $message);
    $message = str_replace('{{direccion}}', 'Dirección: ' . $payment_data[8], $message);

    $headers = array('Content-Type: text/html; charset=UTF-8');

    $subject = 'Tu producto ha sido enviado 🐼💚 ';

    // Envía el correo
    $result = wp_mail($to, $subject, $message, $headers);
}

function sha256($str) {
    $buffer = utf8_encode($str);
    $hashArray = hash('sha256', $buffer, true);
    $hashHex = bin2hex($hashArray);
    return $hashHex;
}

function encriptar($cadena, $clave) {
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $cifrado = openssl_encrypt($cadena, 'aes-256-cbc', $clave, 0, $iv);
    return base64_encode($iv . $cifrado);
}

?>
