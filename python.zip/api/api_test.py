import requests

url = 'http://localhost:5000/imprimir'
data = {'token': 'Hola, mundo!'}
response = requests.post(url, json=data)
print(response.text)
