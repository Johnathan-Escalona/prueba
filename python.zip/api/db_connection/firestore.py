
import firebase_admin
from firebase_admin import credentials

cred = credentials.Certificate("./db_connection/api_key.json")
firebase_admin.initialize_app(cred)

#def prueba(fecha, tipoPferencia):
#    data = {"fecha": fecha, "tipoPreferencia": tipoPferencia}
#    doc_ref=db.collection("preferencias").add(data)

#prueba("08/4/2023", "OFERTAS")