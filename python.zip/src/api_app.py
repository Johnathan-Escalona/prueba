import db_connection.firestore
from firebase_admin import firestore
from firebase_admin import messaging
from flask import Flask, request
from flask import jsonify
import pandas as pd

app = Flask(__name__)

@app.route('/token', methods=['POST'])
def token():
    data = request.get_json()
    cadena = data['token']
    #------------------------------------
    db = firestore.client()
    #------------------------------------
    getTokens = db.collection(u'tokens').stream()
    getToken_list = []
    for token in getTokens:
        getTokens_dict = token.to_dict()
        getTokens_dict['id'] = token.id # Agregar el ID del documento como una columna
        getToken_list.append(getTokens_dict)

    df_getToken = pd.DataFrame(getToken_list)
    exist_token = False
    for index, row in df_getToken.iterrows():
        if(row['token'] == cadena):
            exist_token = True
    if(exist_token == False):
        print('No existe este token')
        new_data = {"token": cadena}
        new_token = db.collection(u'tokens').add(new_data)
    else:
        print("Este token ya existe")
    response_data = {'message': 'Cadena recibida'}
    exist_token = False
    return jsonify(response_data)
#---------------------------------------------------------
@app.route('/dataPref', methods=['POST'])
def dataPref():
    data = request.get_json()
    print("---------------------")
    print(data)
    print("---------------------")
    #------------------------------------
    db = firestore.client()
    #------------------------------------
    New_send = db.collection(u'preferencias').add(data)
    #------------------------------------
    print(data)
    response_data = {'message': 'Cadena recibida'}
    print(response_data)
    return jsonify(response_data)
#-------------------------------------------------------------------
@app.route('/sendData', methods=['POST'])
def sendData():
    data = request.get_json()
    print("---------------------")
    print(data)
    print("---------------------")
    cadena = data['opcion']
    #------------------------------------
    db = firestore.client()
    #------------------------------------
    new_data = {"tipoProducto": data['tipoProducto'], "marca": data['marca'], "precio": data['precio'], "fecha": data['fecha']}
    new_token = db.collection(cadena).add(new_data)
    #------------------------------------
    print(new_data)
    response_data = {'message': 'Cadena recibida'}
    print(response_data)
    return jsonify(response_data)
#-------------------------------------------------------------------
@app.route("/member/")
def menbers():
    return {"members": ["Member1", "Member2", "Member3"]}

if __name__ == '__main__':
    app.run(debug=True, host='93.188.165.216', port=5000)