import pandas as pd
import db_connection.firestore
from firebase_admin import firestore
from datetime import datetime
import pickle
import time
from firebase_admin import messaging

def sendPush(title, msg, registration_token, dataObject=None):
    # See documentation on defining a message payload.
    message = messaging.MulticastMessage(
        notification=messaging.Notification(
            title=title,
            body=msg
        ),
        data=dataObject,
        tokens=registration_token,
    )

    # Send a message to the device corresponding to the provided
    # registration token.
    response = messaging.send_multicast(message)
    # Response is a message ID string.
    print('Successfully sent message:', response)

while True:
    #tokens = ["emwIWUb1TnCVZSoxHq3WRE:APA91bE9b-WX08jCSLOLOHfXV8wGcheFvq5eX_LP860fktG_HIgzPL-vkf6IXPfTkNv-Qn0kMm5VDDhB4xt7u__nLAt6_HQYmwP6y31rKsdfB_1xrPtcgOfQkki1ntPhIf7p1DkCEqJ4"]
    date_module = datetime.now()
    day = date_module.day
    month = date_module.month
    year = date_module.year
    date = str(day)+'/'+str(month)+'/'+str(year)
    #date = '19/4/2023'

    db = firestore.client()
    #----------------------------------------
    get_tokens = db.collection(u'tokens').stream()
    get_tokens_list = []

    for get_token in get_tokens:
        get_tokens_dict = get_token.to_dict()
        get_tokens_dict['id'] = get_token.id # Agregar el ID del documento como una columna
        get_tokens_list.append(get_tokens_dict)    

    if not get_tokens_list:
        print('No hay documentos en la colección')
    else:
        df_get_tokens = pd.DataFrame(get_tokens_list)
        
    #----------------------------------------

    preference = db.collection(u'preferencias').where('fecha', '==', date).stream()

    preference_list = []
    new_count_preference = pd.DataFrame({'producto': [1, 2, 3, 4,5,6,7,8,9,10,11,12], 'Cantidad Preferencias': [0, 0, 0,0,0,0,0,0,0,0,0,0]})

    # Recorrer los documentos y convertirlos en un diccionario
    for prefer in preference:
        preference_dict = prefer.to_dict()
        preference_dict['id'] = prefer.id # Agregar el ID del documento como una columna
        preference_list.append(preference_dict)

    if not preference_list:
        print('No hay documentos en la colección')
    else:
        df_preference = pd.DataFrame(preference_list)

        grupo_preference = df_preference.groupby(['tipoPreferencia'])

        count_preference = grupo_preference.size().reset_index(name='Cantidad Preferencias')

        count_preference['producto'] = [0] * len(count_preference)

        for index, row in count_preference.iterrows():
            if row['tipoPreferencia'] == 'NOVEDADES':
                count_preference.at[index, 'producto'] = 1
            elif row['tipoPreferencia'] == 'OFERTAS':
                count_preference.at[index, 'producto'] = 7
            elif row['tipoPreferencia'] == 'CALIDAD':
                count_preference.at[index, 'producto'] = 1
            elif row['tipoPreferencia'] == 'RECOMENDACIONES':
                count_preference.at[index, 'producto'] = 9

        for index, row in count_preference.iterrows():
            temp_array =[1,7,9]
            for i in range(3):
                if row['producto'] == temp_array[i]:
                    for index_1, row_1 in new_count_preference.iterrows():
                        if row_1['producto'] == temp_array[i]:
                            new_count_preference.at[index_1, 'Cantidad Preferencias'] = count_preference.at[index, 'Cantidad Preferencias']   
    #------------------------------------------------

    searchesSuggestions = db.collection(u'busquedaSugerencia').where('fecha', '==', date).stream()

    searchesSuggestions_list = []
    new_count_searchesSuggestions = pd.DataFrame({'producto': [1, 2, 3, 4,5,6,7,8,9,10,11,12], 'Cantidad Busquedas': [0, 0, 0,0,0,0,0,0,0,0,0,0]})

    # Recorrer los documentos y convertirlos en un diccionario
    for searchsuggestion in searchesSuggestions:
        searchesSuggestions_dict = searchsuggestion.to_dict()
        searchesSuggestions_dict['id'] = searchsuggestion.id # Agregar el ID del documento como una columna
        searchesSuggestions_list.append(searchesSuggestions_dict)

    if not searchesSuggestions_list:
        print('No hay documentos en la colección')
    else:
        df_searchesSuggestions = pd.DataFrame(searchesSuggestions_list)

        grupo_searchesSuggestions = df_searchesSuggestions.groupby(['precio', 'tipoProducto', 'marca'])

        count_searchesSuggestions = grupo_searchesSuggestions.size().reset_index(name='Cantidad Busquedas')

        count_searchesSuggestions['producto'] = [0] * len(count_searchesSuggestions)
        
        new_precio = ['1350','1000','1250','900','1550','1100','1250','800','1550','1100','650','430']
        new_tipoProducto = ['Camara','Camara','Camara','Camara','Alarma','Alarma','Alarma','Alarma','Biometrico','Biometrico','Biometrico','Biometrico']
        new_marca = ['Dahua','Dahua','Hikvision','Hikvision','Dahua','Dahua','Paradox','Paradox','Dahua','Dahua','Hikvision','Hikvision']

        for index, row in count_searchesSuggestions.iterrows():
            for i in range(12):
                if row['precio'] == new_precio[i] and row['tipoProducto'] == new_tipoProducto[i] and row['marca'] == new_marca[i]:
                    count_searchesSuggestions.at[index, 'producto'] = i+1

        for index, row in count_searchesSuggestions.iterrows():
            for i in range(12):
                if row['producto'] == i:
                    for index_1, row_1 in new_count_searchesSuggestions.iterrows():
                        if row_1['producto'] == i:
                            new_count_searchesSuggestions.at[index_1, 'Cantidad Busquedas'] = count_searchesSuggestions.at[index, 'Cantidad Busquedas']
                            break

    df_to_predic = pd.merge(new_count_preference[['producto','Cantidad Preferencias']], new_count_searchesSuggestions[['producto', 'Cantidad Busquedas']],on='producto')
    print(df_to_predic)
#--------------------------------------------------------
    bayes_clasif_producto = [None]*12

    for i in range(12):
        with open('fit_model/producto' + str(i+1) + '.pkl', 'rb') as file:
            bayes_clasif_producto[i] = pickle.load(file) 
    
    predicciones_producto = [""] * 12
    for i in range(12):
        predicciones_producto[i] = bayes_clasif_producto[i].predict([[df_to_predic.loc[i,'Cantidad Preferencias'],df_to_predic.loc[i,'Cantidad Busquedas']]])[0]

    print('--------------------------------------')
    for i in range(12):
        print('Se estima vender ' + str(predicciones_producto[i]) + ' unidades del producto '+str(i+1))
    print('--------------------------------------')

    db_predictions = db.collection(u'prediccionesVentas').where('fecha', '==', date).stream()

    db_predictions_list = []

    # Recorrer los documentos y convertirlos en un diccionario
    for db_prediction in db_predictions:
        db_predictions_dict = db_prediction.to_dict()
        db_predictions_dict['id'] = db_prediction.id # Agregar el ID del documento como una columna
        db_predictions_list.append(db_predictions_dict)

    df_db_predictions = pd.DataFrame(db_predictions_list)

    send_prediccion_productos = ['','','','','','','','','','','','']
    send_prediccion_cantidad = ['','','','','','','','','','','','']

    for index, row in df_db_predictions.iterrows():
        # Acceder al valor de la columna 'nombre'
        for i in range(12):
        # Acceder al valor de la columna 'nombre'
            if(row['producto'] == 'producto' + str(i+1)):
                send_prediccion_productos[i] = row['id']
                send_prediccion_cantidad[i] = row['cantidad']

    bool_new_prediction = False
    for i in range(12):
        if(send_prediccion_productos[i] != ""):
            if(int(send_prediccion_cantidad[i]) != predicciones_producto[i]):
                send_prediction = db.collection(u'prediccionesVentas').document(send_prediccion_productos[i])
                send_prediction.update({u'cantidad': str(predicciones_producto[i])})
                bool_new_prediction = True
        elif(send_prediccion_productos[i] == "" and predicciones_producto[i] == 0):
            new_data = {"cantidad": "0", "fecha": date, "producto": "producto" + str(i+1)}
            new_document = db.collection(u'prediccionesVentas').add(new_data)
        else:
            new_data = {"cantidad": str(predicciones_producto[i]), "fecha": date, "producto": "producto" + str(i+1)}
            new_document = db.collection(u'prediccionesVentas').add(new_data)
            bool_new_prediction = True
    if(bool_new_prediction == True):
        for index, row in df_get_tokens.iterrows():
            tokens = [row['token']]
            sendPush("Alerta", "Nueva predicción disponible", tokens)
        bool_new_prediction = False
    time.sleep(5)