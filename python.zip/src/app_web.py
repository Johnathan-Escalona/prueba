import pandas as pd
import db_connection.firestore
from firebase_admin import firestore
import streamlit as st
import time
from datetime import datetime

def main():
    #date = '8/4/2023'
    #date = '20/4/2023'
    date_module = datetime.now()
    day = date_module.day
    month = date_module.month
    year = date_module.year
    date = str(day)+'/'+str(month)+'/'+str(year)

    db = firestore.client()
    #----------------------------------------
    preference = db.collection(u'preferencias').where('fecha', '==', date).stream()

    preference_list = []
    new_count_preference = pd.DataFrame({'producto': [1, 2, 3, 4,5,6,7,8,9,10,11,12], 'Cantidad Preferencias': [0, 0, 0,0,0,0,0,0,0,0,0,0]})

    # Recorrer los documentos y convertirlos en un diccionario
    for prefer in preference:
        preference_dict = prefer.to_dict()
        preference_dict['id'] = prefer.id # Agregar el ID del documento como una columna
        preference_list.append(preference_dict)

    if not preference_list:
        print('No hay documentos en la colecci  n')
    else:
        df_preference = pd.DataFrame(preference_list)

        grupo_preference = df_preference.groupby(['tipoPreferencia'])

        count_preference = grupo_preference.size().reset_index(name='Cantidad Preferencias')

        count_preference['producto'] = [0] * len(count_preference)

        for index, row in count_preference.iterrows():
            if row['tipoPreferencia'] == 'NOVEDADES':
                count_preference.at[index, 'producto'] = 1
            elif row['tipoPreferencia'] == 'OFERTAS':
                count_preference.at[index, 'producto'] = 7
            elif row['tipoPreferencia'] == 'CALIDAD':
                count_preference.at[index, 'producto'] = 1
            elif row['tipoPreferencia'] == 'RECOMENDACIONES':
                count_preference.at[index, 'producto'] = 9

        for index, row in count_preference.iterrows():
            temp_array =[1,7,9]
            for i in range(3):
                if row['producto'] == temp_array[i]:
                    for index_1, row_1 in new_count_preference.iterrows():
                        if row_1['producto'] == temp_array[i]:
                            new_count_preference.at[index_1, 'Cantidad Preferencias'] = count_preference.at[index, 'Cantidad Preferencias']
    #----------------------------------------
    searchesSuggestions = db.collection(u'busquedaSugerencia').where('fecha', '==', date).stream()

    searchesSuggestions_list = []
    new_count_searchesSuggestions = pd.DataFrame({'producto': [1, 2, 3, 4,5,6,7,8,9,10,11,12], 'Cantidad Busquedas': [0, 0, 0,0,0,0,0,0,0,0,0,0]})

    # Recorrer los documentos y convertirlos en un diccionario
    for searchsuggestion in searchesSuggestions:
        searchesSuggestions_dict = searchsuggestion.to_dict()
        searchesSuggestions_dict['id'] = searchsuggestion.id # Agregar el ID del documento como una columna
        searchesSuggestions_list.append(searchesSuggestions_dict)

    if not searchesSuggestions_list:
        print('No hay documentos en la colecci  n')
    else:
        df_searchesSuggestions = pd.DataFrame(searchesSuggestions_list)

        grupo_searchesSuggestions = df_searchesSuggestions.groupby(['precio', 'tipoProducto', 'marca'])

        count_searchesSuggestions = grupo_searchesSuggestions.size().reset_index(name='Cantidad Busquedas')

        count_searchesSuggestions['producto'] = [0] * len(count_searchesSuggestions)

        new_precio = ['1350','1000','1250','900','1550','1100','1250','800','1550','1100','650','430']
        new_tipoProducto = ['Camara','Camara','Camara','Camara','Alarma','Alarma','Alarma','Alarma','Biometrico','Biometrico','Biometrico','Biometrico']
        new_marca = ['Dahua','Dahua','Hikvision','Hikvision','Dahua','Dahua','Paradox','Paradox','Dahua','Dahua','Hikvision','Hikvision']

        for index, row in count_searchesSuggestions.iterrows():
            for i in range(12):
                if row['precio'] == new_precio[i] and row['tipoProducto'] == new_tipoProducto[i] and row['marca'] == new_marca[i]:
                    count_searchesSuggestions.at[index, 'producto'] = i+1

        for index, row in count_searchesSuggestions.iterrows():
            for i in range(12):
                if row['producto'] == i:
                    for index_1, row_1 in new_count_searchesSuggestions.iterrows():
                        if row_1['producto'] == i:
                            new_count_searchesSuggestions.at[index_1, 'Cantidad Busquedas'] = count_searchesSuggestions.at[index, 'Cantidad Busquedas']
                            break

    df_to_predic = pd.merge(new_count_preference[['producto','Cantidad Preferencias']], new_count_searchesSuggestions[['producto', 'Cantidad Busquedas']],on='producto')
    #----------------------------------------

    predictions = db.collection(u'prediccionesVentas').where('fecha', '==', date).stream()

    predictions_list = []

    # Recorrer los documentos y convertirlos en un diccionario
    for predict in predictions:
        predictions_dict = predict.to_dict()
        predictions_dict['id'] = predict.id # Agregar el ID del documento como una columna
        predictions_list.append(predictions_dict)

    df_predictions = None

    if not predictions_list:
        print('No hay documentos en la colecci  n')
    else:
        df_predictions = pd.DataFrame(predictions_list)

    df = pd.DataFrame({
        'Tipo de Producto': ['Camara', 'Camara', 'Camara', 'Camara', 'Alarma','Alarma','Alarma','Alarma', 'Biometrico', 'Biometrico', 'Biometrico', 'Biometrico'],
        'Marca': ['Dahua', 'Dahua', 'Hikvision', 'Hikvision', 'Dahua', 'Dahua', 'Paradox', 'Paradox', 'Dahua', 'Dahua', 'Hikvision', 'Hikvision'],
        'Precio': ['1350', '1000', '1250', '900', '1550', '1100', '1250', '800', '1550', '1100', '650', '430'],
        'Cantidad Preferencias': ['0','0','0','0','0','0','0','0','0','0','0','0'],
        'Cantidad Busquedas': ['0','0','0','0','0','0','0','0','0','0','0','0'],
        'Cantidad Vetas': ['0','0','0','0','0','0','0','0','0','0','0','0'],
    })

    string_productos = ['producto1', 'producto2', 'producto3', 'producto4', 'producto5', 'producto6', 'producto7', 'producto8', 'producto9', 'producto10', 'producto11', 'producto12']

    for index, row in df_predictions.iterrows():
        for i in range(12):
            if row['producto'] == string_productos[i]:
                df.at[i, 'Cantidad Vetas'] = row['cantidad']

    string_productos_1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    for index, row in df_to_predic.iterrows():
        for i in range(12):
            if row['producto'] == string_productos_1[i]:
                df.at[i, 'Cantidad Preferencias'] = row['Cantidad Preferencias']
                df.at[i, 'Cantidad Busquedas'] = row['Cantidad Busquedas']

    # T  tulo de la p  gina
    st.title("Predicciones de ventas")

    # Subt  tulo
    st.header(date)
    st.dataframe(df, height=455, width=1000)

if __name__ == '__main__':
    main()