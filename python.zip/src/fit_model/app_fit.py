import pandas as pd
import numpy as np
import seaborn as sns
from sklearn.feature_selection import SelectKBest
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import pickle

# Lee el archivo CSV y conviértelo en un DataFrame
df = pd.read_csv('datos_producto12.csv')
stringfilename = 'producto12.pkl'

df = df.drop(['producto'],axis=1)

# Imprime las primeras filas del DataFrame

X = df.drop(['Cantidad Compras'], axis=1)
y = df['Cantidad Compras']

best = SelectKBest(k = 2)
X_new = best.fit_transform(X,y)
X_new.shape
selected = best.get_support(indices=True)

used_features = X.columns[selected]

X_train, X_test = train_test_split(df, test_size=0.2, random_state=6)
y_train = X_train['Cantidad Compras']
y_test = X_test['Cantidad Compras']

bayes_naive=GaussianNB()
bayes_clasif = bayes_naive.fit(X_train[used_features].values, y_train)
y_pred = bayes_naive.predict(X_test[used_features])

#print (confusion_matrix(y_test, y_pred))
#print (classification_report(y_test, y_pred))
print('--------------------------------------')
print ('Precisión del ' + str(accuracy_score(y_test, y_pred)*100) + '%')
print('--------------------------------------')
#print('Se estima vender ' + str(bayes_naive.predict([[5,50]])[0]) + ' unidades del producto 1')

with open(stringfilename, 'wb') as file:
    pickle.dump(bayes_clasif, file)