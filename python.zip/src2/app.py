import db_connection.firestore
from firebase_admin import messaging

def sendPush(title, msg, registration_token, dataObject=None):
    # See documentation on defining a message payload.
    message = messaging.MulticastMessage(
        notification=messaging.Notification(
            title=title,
            body=msg
        ),
        data=dataObject,
        tokens=registration_token,
    )

    # Send a message to the device corresponding to the provided
    # registration token.
    response = messaging.send_multicast(message)
    # Response is a message ID string.
    print('Successfully sent message:', response)

tokens = ["c_aUmiCYT5OIrEspyXlGYR:APA91bHRhy0_hdFpeojqcOQ3RLWGo0zsa_dcEMlMbzNDmXbFI-UfVYQSE-Jnl3CDfvoxPdb8BL40ZeIX4ZK59sGk8PU-JCH73mqPZFHyzWD1Tfy8oq19FwpQ7jJ4bTnO86wtUsKnmFA-"]

sendPush("Hi", "This is my next msg", tokens)