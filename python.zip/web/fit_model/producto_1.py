import pickle

with open('modelo_bayesiano.pkl', 'rb') as file:
    bayes_clasif = pickle.load(file)

nuevas_predicciones = bayes_clasif.predict([[5,50]])[0]

print('--------------------------------------')
print('Se estima vender ' + str(nuevas_predicciones) + ' unidades del producto 1')
print('--------------------------------------')